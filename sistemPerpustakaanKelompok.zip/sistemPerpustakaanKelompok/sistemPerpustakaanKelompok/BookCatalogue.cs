﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class BookCatalogue : Form
    {
        string usernameMember;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string SearchBook
        {
            get => txtSearchBar.Text;
            set => txtSearchBar.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Category
        {
            get => cbKategori.Text;
            set => cbKategori.Text = value;
        }
        public BookCatalogue(string username)
        {
            InitializeComponent();

            usernameMember = username;
        }

        private void BookCatalogue_Load(object sender, EventArgs e)
        {
            lblNamaMember.Text = usernameMember;
            dtpTahunRelease.Format = DateTimePickerFormat.Custom;
            dtpTahunRelease.CustomFormat = "yyyy";
            dtpTahunRelease.ShowUpDown = true;

            layoutPanelBuku.AutoScroll = true;
            LoadData();
            LoadKategori();
        }

        private void lblPageDashboard_Click(object sender, EventArgs e)
        {
            DashboardMember dashboardMember = new DashboardMember(usernameMember);
            dashboardMember.Show();
            this.Hide();
        }

        private void lblBookCatalogue_Click(object sender, EventArgs e)
        {
            BookCatalogue bookCatalogue = new BookCatalogue(usernameMember);
            bookCatalogue.Show();
            this.Hide();
        }

        private void lblMyBook_Click(object sender, EventArgs e)
        {
            MyBook myBook = new MyBook(usernameMember);
            myBook.Show();
            this.Hide();
        }

        private void lblHistory_Click(object sender, EventArgs e)
        {
            History history = new History(usernameMember);
            history.Show();
            this.Hide();
        }

        private void lblProfile_Click(object sender, EventArgs e)
        {
            Profile profile = new Profile(usernameMember);
            profile.Show();
            this.Hide();
        }

        private void lblLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void LoadData(string search = "", string kategori = "", string tahun = "")
        {
            layoutPanelBuku.Controls.Clear();

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"SELECT b.*, j.jenis, p.nama_penulis, pb.nama_penerbit
                        FROM tblbuku b
                        JOIN tbljenisbuku j ON b.jenisbuku_id = j.id_jenis
                        JOIN tblpenulis p ON b.penulis_id = p.id_penulis
                        JOIN tblpenerbit pb ON b.penerbit_id = pb.id_penerbit
                        WHERE 1=1";

                if (!string.IsNullOrEmpty(search))
                    query += " AND LOWER(b.judul) LIKE @search";

                if (!string.IsNullOrEmpty(kategori))
                    query += " AND j.jenis = @kategori";

                if (!string.IsNullOrEmpty(tahun))
                    query += " AND b.tahun_terbit = @tahun";

                SqlCommand cmd = new SqlCommand(query, conn);

                if (!string.IsNullOrEmpty(search))
                    cmd.Parameters.AddWithValue("@search", "%" + search.Trim().ToLower() + "%");

                if (!string.IsNullOrEmpty(kategori))
                    cmd.Parameters.AddWithValue("@kategori", kategori);

                if (!string.IsNullOrEmpty(tahun))
                    cmd.Parameters.AddWithValue("@tahun", tahun);

                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    int idBuku = Convert.ToInt32(rd["id_buku"]);
                    string judul = rd["judul"].ToString();
                    string penulis = rd["nama_penulis"].ToString();
                    string jenis = rd["jenis"].ToString();
                    string penerbit = rd["nama_penerbit"].ToString();
                    string tahunTerbit = rd["tahun_terbit"].ToString();
                    string deskripsi = rd["deskripsi_buku"].ToString();
                    string stok = rd["stok"].ToString();

                    Image img = null;
                    if (rd["gambar"] != DBNull.Value)
                    {
                        byte[] imgBytes = (byte[])rd["gambar"];
                        using (MemoryStream ms = new MemoryStream(imgBytes))
                        {
                            img = Image.FromStream(ms);
                        }
                    }

                    templateBook item = new templateBook();
                    item.BookName = judul;
                    item.Writer = penulis;
                    item.BookGenre = jenis;
                    item.PublishYear = Convert.ToInt32(tahunTerbit);

                    if (img != null)
                        item.BookImage = img;

                    item.BtnDetail.Click += (s, e) =>
                    {
                        BookDetail detail = new BookDetail();

                        detail.BookName = judul;
                        detail.Writer = penulis;
                        detail.BookGenre = jenis;
                        detail.PublisherName = penerbit;
                        detail.PublishYear = tahunTerbit;
                        detail.Description = deskripsi;
                        detail.Stock = stok;

                        if (img != null)
                            detail.BookImage = img;

                        detail.SetData(idBuku, usernameMember);

                        detail.Show();
                    };

                    layoutPanelBuku.Controls.Add(item);
                }
            }
        }

        private void LoadKategori()
        {
            cbKategori.Items.Clear();
            cbKategori.Items.Add("");

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = "SELECT jenis FROM tbljenisbuku";
                SqlCommand cmd = new SqlCommand(query, conn);

                SqlDataReader rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    cbKategori.Items.Add(rd["jenis"].ToString());
                }
            }
        }

        private void txtSearchBar_TextChanged(object sender, EventArgs e)
        {
            string tahun = dtpTahunRelease.Checked ? dtpTahunRelease.Value.Year.ToString() : "";
            LoadData(SearchBook, "", "");
        }

        private void cbKategori_SelectedIndexChanged(object sender, EventArgs e)
        {
            string tahun = dtpTahunRelease.Checked ? dtpTahunRelease.Value.Year.ToString() : "";
            LoadData("", Category, "");
        }

        private void dtpTahunRelease_ValueChanged(object sender, EventArgs e)
        {
            string tahun = dtpTahunRelease.Checked ? dtpTahunRelease.Value.Year.ToString() : "";
            LoadData("", "", tahun);
        }
    }
}
