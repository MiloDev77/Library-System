﻿namespace SistemPerpustakaanKelompok
{
    partial class BookDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BookDetail));
            gambarBuku = new PictureBox();
            lblJudulBuku = new Label();
            lblPenulis = new Label();
            lblJenisBuku = new Label();
            lblNamaPublisher = new Label();
            lblTahunTerbit = new Label();
            deskripsiFlowPanel = new FlowLayoutPanel();
            lblStok = new Label();
            btnClose = new Button();
            btnPinjam = new Button();
            ((System.ComponentModel.ISupportInitialize)gambarBuku).BeginInit();
            SuspendLayout();
            // 
            // gambarBuku
            // 
            gambarBuku.BackColor = Color.Transparent;
            gambarBuku.Location = new Point(12, 7);
            gambarBuku.Name = "gambarBuku";
            gambarBuku.Size = new Size(99, 160);
            gambarBuku.TabIndex = 0;
            gambarBuku.TabStop = false;
            // 
            // lblJudulBuku
            // 
            lblJudulBuku.BackColor = Color.Transparent;
            lblJudulBuku.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblJudulBuku.ForeColor = SystemColors.ControlLightLight;
            lblJudulBuku.Location = new Point(117, 7);
            lblJudulBuku.Name = "lblJudulBuku";
            lblJudulBuku.Size = new Size(412, 56);
            lblJudulBuku.TabIndex = 1;
            lblJudulBuku.Text = "N/A";
            // 
            // lblPenulis
            // 
            lblPenulis.BackColor = Color.Transparent;
            lblPenulis.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPenulis.ForeColor = SystemColors.ControlLightLight;
            lblPenulis.Location = new Point(117, 48);
            lblPenulis.Name = "lblPenulis";
            lblPenulis.Size = new Size(412, 23);
            lblPenulis.TabIndex = 1;
            lblPenulis.Text = "N/A";
            // 
            // lblJenisBuku
            // 
            lblJenisBuku.BackColor = Color.Transparent;
            lblJenisBuku.Font = new Font("Segoe UI", 12F);
            lblJenisBuku.ForeColor = SystemColors.ControlLightLight;
            lblJenisBuku.Location = new Point(117, 81);
            lblJenisBuku.Name = "lblJenisBuku";
            lblJenisBuku.Size = new Size(412, 24);
            lblJenisBuku.TabIndex = 1;
            lblJenisBuku.Text = "N/A";
            // 
            // lblNamaPublisher
            // 
            lblNamaPublisher.BackColor = Color.Transparent;
            lblNamaPublisher.Font = new Font("Segoe UI", 12F);
            lblNamaPublisher.ForeColor = SystemColors.ControlLightLight;
            lblNamaPublisher.Location = new Point(117, 118);
            lblNamaPublisher.Name = "lblNamaPublisher";
            lblNamaPublisher.Size = new Size(412, 23);
            lblNamaPublisher.TabIndex = 1;
            lblNamaPublisher.Text = "N/A";
            // 
            // lblTahunTerbit
            // 
            lblTahunTerbit.BackColor = Color.Transparent;
            lblTahunTerbit.Font = new Font("Segoe UI", 12F);
            lblTahunTerbit.ForeColor = SystemColors.ControlLightLight;
            lblTahunTerbit.Location = new Point(117, 151);
            lblTahunTerbit.Name = "lblTahunTerbit";
            lblTahunTerbit.Size = new Size(412, 26);
            lblTahunTerbit.TabIndex = 1;
            lblTahunTerbit.Text = "N/A";
            // 
            // deskripsiFlowPanel
            // 
            deskripsiFlowPanel.BackColor = Color.Transparent;
            deskripsiFlowPanel.Location = new Point(8, 173);
            deskripsiFlowPanel.Name = "deskripsiFlowPanel";
            deskripsiFlowPanel.Size = new Size(524, 88);
            deskripsiFlowPanel.TabIndex = 2;
            // 
            // lblStok
            // 
            lblStok.BackColor = Color.Transparent;
            lblStok.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblStok.ForeColor = SystemColors.ControlLightLight;
            lblStok.Location = new Point(8, 273);
            lblStok.Name = "lblStok";
            lblStok.Size = new Size(207, 26);
            lblStok.TabIndex = 1;
            lblStok.Text = "N/A";
            // 
            // btnClose
            // 
            btnClose.BackColor = Color.Red;
            btnClose.Cursor = Cursors.Hand;
            btnClose.FlatStyle = FlatStyle.Flat;
            btnClose.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnClose.ForeColor = SystemColors.ControlText;
            btnClose.Location = new Point(273, 269);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(87, 35);
            btnClose.TabIndex = 3;
            btnClose.Text = "Close";
            btnClose.UseVisualStyleBackColor = false;
            btnClose.Click += btnClose_Click;
            // 
            // btnPinjam
            // 
            btnPinjam.BackColor = Color.Lime;
            btnPinjam.Cursor = Cursors.Hand;
            btnPinjam.FlatStyle = FlatStyle.Flat;
            btnPinjam.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPinjam.ForeColor = SystemColors.ControlText;
            btnPinjam.Location = new Point(375, 269);
            btnPinjam.Name = "btnPinjam";
            btnPinjam.Size = new Size(158, 35);
            btnPinjam.TabIndex = 3;
            btnPinjam.Text = "Reserved";
            btnPinjam.UseVisualStyleBackColor = false;
            btnPinjam.Click += btnPinjam_Click;
            // 
            // BookDetail
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(541, 311);
            Controls.Add(btnPinjam);
            Controls.Add(btnClose);
            Controls.Add(deskripsiFlowPanel);
            Controls.Add(lblStok);
            Controls.Add(lblTahunTerbit);
            Controls.Add(lblNamaPublisher);
            Controls.Add(lblJenisBuku);
            Controls.Add(lblPenulis);
            Controls.Add(lblJudulBuku);
            Controls.Add(gambarBuku);
            DoubleBuffered = true;
            Name = "BookDetail";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "BookDetail";
            ((System.ComponentModel.ISupportInitialize)gambarBuku).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox gambarBuku;
        private Label lblJudulBuku;
        private Label lblPenulis;
        private Label lblJenisBuku;
        private Label lblNamaPublisher;
        private Label lblTahunTerbit;
        private FlowLayoutPanel deskripsiFlowPanel;
        private Label lblStok;
        private Button btnClose;
        private Button btnPinjam;
    }
}