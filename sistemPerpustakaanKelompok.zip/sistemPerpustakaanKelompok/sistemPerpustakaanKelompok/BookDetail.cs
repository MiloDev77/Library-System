﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class BookDetail : Form
    {
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Image BookImage
        {
            set
            {
                gambarBuku.Image = value;
                gambarBuku.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string BookName
        {
            get => lblJudulBuku.Text;
            set => lblJudulBuku.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Writer
        {
            get => lblPenulis.Text;
            set => lblPenulis.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string BookGenre
        {
            get => lblJenisBuku.Text;
            set => lblJenisBuku.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PublisherName
        {
            get => lblNamaPublisher.Text;
            set => lblNamaPublisher.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PublishYear
        {
            get => lblTahunTerbit.Text;
            set => lblTahunTerbit.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Description
        {
            set
            {
                deskripsiFlowPanel.Controls.Clear();

                Label lbl = new Label();
                lbl.Text = value;
                lbl.AutoSize = true;
                lbl.MaximumSize = new Size(deskripsiFlowPanel.Width - 20, 0); 
                lbl.ForeColor = Color.White;

                deskripsiFlowPanel.Controls.Add(lbl);
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Stock
        {
            get => lblStok.Text;
            set => lblStok.Text = value;
        }

        private int idBuku;
        private string usernameMember;
        public BookDetail()
        {
            InitializeComponent();
        }

        public void SetData(int id, string user)
        {
            idBuku = id;
            usernameMember = user;
            CheckReserved();
        }

        private void btnPinjam_Click(object sender, EventArgs e)
        {
            if (int.Parse(Stock) <= 0)
            {
                MessageBox.Show("There is no book available to be borrowed!");
                return;
            }

            Reserve r = new Reserve();

            r.BookImageReserve = gambarBuku.Image;
            r.BookName = BookName;
            r.Writer = Writer;
            r.BookGenre = BookGenre;
            r.PublishYear = PublishYear;
            r.ReserveName = usernameMember;

            r.Tag = idBuku;
            r.SetData(idBuku, usernameMember);

            r.Show();

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CheckReserved()
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"SELECT 
                                (SELECT COUNT(*) FROM tblpeminjaman 
                                WHERE id_member = (SELECT id_member FROM tblmember WHERE username=@u)
                                AND id_buku=@b AND status_peminjaman='Active') AS IsBorrowed,

                                (SELECT COUNT(*) FROM tblrequest_pinjam
                                WHERE id_member = (SELECT id_member FROM tblmember WHERE username=@u)
                                AND id_buku=@b AND status_request='Pending') AS IsPending
                                ";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@u", usernameMember);
                cmd.Parameters.AddWithValue("@b", idBuku);

                SqlDataReader rd = cmd.ExecuteReader();

                if (rd.Read())
                {
                    int isBorrowed = Convert.ToInt32(rd["IsBorrowed"]);
                    int isPending = Convert.ToInt32(rd["IsPending"]);

                    if (isBorrowed > 0)
                    {
                        btnPinjam.Enabled = false;
                        btnPinjam.Text = "Already Borrowed";
                        btnPinjam.BackColor = Color.Yellow;
                        btnPinjam.ForeColor = Color.Black;
                    }

                    else if (isPending > 0)
                    {
                        btnPinjam.Enabled = false;
                        btnPinjam.Text = "Waiting Approval";
                        btnPinjam.BackColor = Color.Cyan;
                        btnPinjam.ForeColor = Color.Black;
                    }
                }

                rd.Close();
            }
        }
    }
}