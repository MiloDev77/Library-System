﻿namespace SistemPerpustakaanKelompok
{
    partial class Booked
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Booked));
            layoutPanelBooked = new FlowLayoutPanel();
            lblTotalBooked = new Label();
            lblBukuKembali = new Label();
            lblTelat = new Label();
            bookedBook = new Label();
            borrowRequest = new Label();
            returnRequest = new Label();
            lblLogout = new Label();
            lblMonthReport = new Label();
            lblBooked = new Label();
            lblManageMember = new Label();
            lblManageBook = new Label();
            lblPageDashboard = new Label();
            layoutPanelBR = new FlowLayoutPanel();
            layoutPanelRR = new FlowLayoutPanel();
            lblNamaAdmin = new Label();
            SuspendLayout();
            // 
            // layoutPanelBooked
            // 
            layoutPanelBooked.BackColor = Color.Transparent;
            layoutPanelBooked.Location = new Point(234, 209);
            layoutPanelBooked.Name = "layoutPanelBooked";
            layoutPanelBooked.Size = new Size(945, 358);
            layoutPanelBooked.TabIndex = 14;
            // 
            // lblTotalBooked
            // 
            lblTotalBooked.AutoSize = true;
            lblTotalBooked.BackColor = Color.Transparent;
            lblTotalBooked.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblTotalBooked.ForeColor = SystemColors.ControlLightLight;
            lblTotalBooked.Location = new Point(277, 108);
            lblTotalBooked.Name = "lblTotalBooked";
            lblTotalBooked.Size = new Size(51, 28);
            lblTotalBooked.TabIndex = 16;
            lblTotalBooked.Text = "N/A";
            // 
            // lblBukuKembali
            // 
            lblBukuKembali.AutoSize = true;
            lblBukuKembali.BackColor = Color.Transparent;
            lblBukuKembali.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblBukuKembali.ForeColor = SystemColors.ControlLightLight;
            lblBukuKembali.Location = new Point(591, 108);
            lblBukuKembali.Name = "lblBukuKembali";
            lblBukuKembali.Size = new Size(51, 28);
            lblBukuKembali.TabIndex = 16;
            lblBukuKembali.Text = "N/A";
            // 
            // lblTelat
            // 
            lblTelat.AutoSize = true;
            lblTelat.BackColor = Color.Transparent;
            lblTelat.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblTelat.ForeColor = SystemColors.ControlLightLight;
            lblTelat.Location = new Point(905, 108);
            lblTelat.Name = "lblTelat";
            lblTelat.Size = new Size(51, 28);
            lblTelat.TabIndex = 16;
            lblTelat.Text = "N/A";
            // 
            // bookedBook
            // 
            bookedBook.AutoSize = true;
            bookedBook.BackColor = Color.Transparent;
            bookedBook.Cursor = Cursors.Hand;
            bookedBook.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            bookedBook.ForeColor = SystemColors.ControlLightLight;
            bookedBook.Location = new Point(309, 174);
            bookedBook.Name = "bookedBook";
            bookedBook.Size = new Size(137, 28);
            bookedBook.TabIndex = 16;
            bookedBook.Text = "Booked Book";
            bookedBook.Click += bookedBook_Click;
            // 
            // borrowRequest
            // 
            borrowRequest.AutoSize = true;
            borrowRequest.BackColor = Color.Transparent;
            borrowRequest.Cursor = Cursors.Hand;
            borrowRequest.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            borrowRequest.ForeColor = SystemColors.ControlLightLight;
            borrowRequest.Location = new Point(628, 174);
            borrowRequest.Name = "borrowRequest";
            borrowRequest.Size = new Size(163, 28);
            borrowRequest.TabIndex = 16;
            borrowRequest.Text = "Borrow Request";
            borrowRequest.Click += borrowRequest_Click;
            // 
            // returnRequest
            // 
            returnRequest.AutoSize = true;
            returnRequest.BackColor = Color.Transparent;
            returnRequest.Cursor = Cursors.Hand;
            returnRequest.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            returnRequest.ForeColor = SystemColors.ControlLightLight;
            returnRequest.Location = new Point(962, 174);
            returnRequest.Name = "returnRequest";
            returnRequest.Size = new Size(158, 28);
            returnRequest.TabIndex = 16;
            returnRequest.Text = "Return Request";
            returnRequest.Click += returnRequest_Click;
            // 
            // lblLogout
            // 
            lblLogout.AutoSize = true;
            lblLogout.BackColor = Color.Transparent;
            lblLogout.Cursor = Cursors.Hand;
            lblLogout.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblLogout.ForeColor = SystemColors.ControlLightLight;
            lblLogout.Location = new Point(63, 553);
            lblLogout.Name = "lblLogout";
            lblLogout.Size = new Size(43, 13);
            lblLogout.TabIndex = 38;
            lblLogout.Text = "Logout";
            lblLogout.Click += lblLogout_Click;
            // 
            // lblMonthReport
            // 
            lblMonthReport.AutoSize = true;
            lblMonthReport.BackColor = Color.Transparent;
            lblMonthReport.Cursor = Cursors.Hand;
            lblMonthReport.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblMonthReport.ForeColor = SystemColors.ControlLightLight;
            lblMonthReport.Location = new Point(63, 302);
            lblMonthReport.Name = "lblMonthReport";
            lblMonthReport.Size = new Size(87, 13);
            lblMonthReport.TabIndex = 37;
            lblMonthReport.Text = "Monthly Report";
            lblMonthReport.Click += lblMonthReport_Click_1;
            // 
            // lblBooked
            // 
            lblBooked.AutoSize = true;
            lblBooked.BackColor = Color.Transparent;
            lblBooked.Cursor = Cursors.Hand;
            lblBooked.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblBooked.ForeColor = SystemColors.ControlLightLight;
            lblBooked.Location = new Point(63, 255);
            lblBooked.Name = "lblBooked";
            lblBooked.Size = new Size(47, 13);
            lblBooked.TabIndex = 36;
            lblBooked.Text = "Booked";
            lblBooked.Click += lblBooked_Click_1;
            // 
            // lblManageMember
            // 
            lblManageMember.AutoSize = true;
            lblManageMember.BackColor = Color.Transparent;
            lblManageMember.Cursor = Cursors.Hand;
            lblManageMember.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblManageMember.ForeColor = SystemColors.ControlLightLight;
            lblManageMember.Location = new Point(63, 208);
            lblManageMember.Name = "lblManageMember";
            lblManageMember.Size = new Size(94, 13);
            lblManageMember.TabIndex = 35;
            lblManageMember.Text = "Manage Member";
            lblManageMember.Click += lblManageMember_Click_1;
            // 
            // lblManageBook
            // 
            lblManageBook.AutoSize = true;
            lblManageBook.BackColor = Color.Transparent;
            lblManageBook.Cursor = Cursors.Hand;
            lblManageBook.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblManageBook.ForeColor = SystemColors.ControlLightLight;
            lblManageBook.Location = new Point(63, 161);
            lblManageBook.Name = "lblManageBook";
            lblManageBook.Size = new Size(78, 13);
            lblManageBook.TabIndex = 34;
            lblManageBook.Text = "Manage Book";
            lblManageBook.Click += lblManageBook_Click_1;
            // 
            // lblPageDashboard
            // 
            lblPageDashboard.AutoSize = true;
            lblPageDashboard.BackColor = Color.Transparent;
            lblPageDashboard.Cursor = Cursors.Hand;
            lblPageDashboard.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblPageDashboard.ForeColor = SystemColors.ControlLightLight;
            lblPageDashboard.Location = new Point(63, 119);
            lblPageDashboard.Name = "lblPageDashboard";
            lblPageDashboard.Size = new Size(63, 13);
            lblPageDashboard.TabIndex = 33;
            lblPageDashboard.Text = "Dashboard";
            lblPageDashboard.Click += lblPageDashboard_Click_1;
            // 
            // layoutPanelBR
            // 
            layoutPanelBR.BackColor = Color.Transparent;
            layoutPanelBR.Location = new Point(234, 208);
            layoutPanelBR.Name = "layoutPanelBR";
            layoutPanelBR.Size = new Size(945, 358);
            layoutPanelBR.TabIndex = 14;
            // 
            // layoutPanelRR
            // 
            layoutPanelRR.BackColor = Color.Transparent;
            layoutPanelRR.Location = new Point(234, 208);
            layoutPanelRR.Name = "layoutPanelRR";
            layoutPanelRR.Size = new Size(945, 358);
            layoutPanelRR.TabIndex = 14;
            // 
            // lblNamaAdmin
            // 
            lblNamaAdmin.BackColor = Color.Transparent;
            lblNamaAdmin.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNamaAdmin.ForeColor = SystemColors.ControlLightLight;
            lblNamaAdmin.Location = new Point(1048, 25);
            lblNamaAdmin.Name = "lblNamaAdmin";
            lblNamaAdmin.Size = new Size(131, 20);
            lblNamaAdmin.TabIndex = 39;
            lblNamaAdmin.Text = "N/A";
            lblNamaAdmin.TextAlign = ContentAlignment.MiddleRight;
            // 
            // Booked
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1216, 588);
            Controls.Add(lblNamaAdmin);
            Controls.Add(lblLogout);
            Controls.Add(lblMonthReport);
            Controls.Add(lblBooked);
            Controls.Add(lblManageMember);
            Controls.Add(lblManageBook);
            Controls.Add(lblPageDashboard);
            Controls.Add(lblTelat);
            Controls.Add(lblBukuKembali);
            Controls.Add(returnRequest);
            Controls.Add(borrowRequest);
            Controls.Add(bookedBook);
            Controls.Add(lblTotalBooked);
            Controls.Add(layoutPanelRR);
            Controls.Add(layoutPanelBR);
            Controls.Add(layoutPanelBooked);
            DoubleBuffered = true;
            Margin = new Padding(3, 2, 3, 2);
            Name = "Booked";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Booked";
            Load += Booked_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private FlowLayoutPanel layoutPanelBooked;
        private Label lblTotalBooked;
        private Label lblBukuKembali;
        private Label lblTelat;
        private Label bookedBook;
        private Label borrowRequest;
        private Label returnRequest;
        private Label lblLogout;
        private Label lblMonthReport;
        private Label lblBooked;
        private Label lblManageMember;
        private Label lblManageBook;
        private Label lblPageDashboard;
        private FlowLayoutPanel layoutPanelBR;
        private FlowLayoutPanel layoutPanelRR;
        private Label lblNamaAdmin;
    }
}