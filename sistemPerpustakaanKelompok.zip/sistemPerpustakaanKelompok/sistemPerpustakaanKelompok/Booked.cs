﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.IO;

namespace SistemPerpustakaanKelompok
{
    public partial class Booked : Form
    {
        string usernameAdmin;
        public Booked(string username)
        {
            InitializeComponent();
            usernameAdmin = username;
        }

        private void lblPageDashboard_Click(object sender, EventArgs e)
        {
            DashboardAdmin dashboard = new DashboardAdmin(usernameAdmin);
            dashboard.Show();
            this.Hide();
        }

        private void lblBooked_Click(object sender, EventArgs e)
        {
            Booked pinjam = new Booked(usernameAdmin);
            pinjam.Show();
            this.Hide();
        }

        private void Booked_Load(object sender, EventArgs e)
        {
            lblNamaAdmin.Text = usernameAdmin;

            layoutPanelBooked.AutoScroll = true;
            layoutPanelBooked.Controls.Clear();

            bookedTittle judul = new bookedTittle();
            judul.Margin = new Padding(0, 25, 0, 10);
            layoutPanelBooked.Controls.Add(judul);

            borrowRequestTitle judulBR = new borrowRequestTitle();
            judulBR.Margin = new Padding(0, 25, 0, 10);
            layoutPanelBR.Controls.Add(judulBR);

            returnRequest judulRR = new returnRequest();
            judulRR.Margin = new Padding(0, 25, 0, 10);
            layoutPanelRR.Controls.Add(judulRR);

            layoutPanelBooked.AutoScroll = true;
            layoutPanelBR.AutoScroll = true;
            layoutPanelRR.AutoScroll = true;
            LoadBorrowRequest();
            LoadReturnRequest();
            LoadBooked();
            LoadStats();
        }

        private void lblLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void lblManageBook_Click(object sender, EventArgs e)
        {
            ManageBook mb = new ManageBook(usernameAdmin);
            mb.Show();
            this.Hide();
        }

        private void lblManageMember_Click(object sender, EventArgs e)
        {
            ManageMember mbr = new ManageMember(usernameAdmin);
            mbr.Show();
            this.Hide();
        }

        private void lblMonthReport_Click(object sender, EventArgs e)
        {
            MonthlyReport report = new MonthlyReport(usernameAdmin);
            report.Show();
            this.Hide();
        }

        private void ShowPanel(FlowLayoutPanel target)
        {
            layoutPanelBooked.Visible = false;
            layoutPanelBR.Visible = false;
            layoutPanelRR.Visible = false;

            target.Visible = true;
        }

        private void bookedBook_Click(object sender, EventArgs e)
        {
            ShowPanel(layoutPanelBooked);
        }

        private void borrowRequest_Click(object sender, EventArgs e)
        {
            ShowPanel(layoutPanelBR);
        }

        private void returnRequest_Click(object sender, EventArgs e)
        {
            ShowPanel(layoutPanelRR);
        }

        private void LoadBorrowRequest()
        {
            layoutPanelBR.Controls.Clear();

            borrowRequestTitle br = new borrowRequestTitle();
            br.Margin = new Padding(0, 25, 0, 10);
            layoutPanelBR.Controls.Add(br);

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"SELECT r.*, b.judul, b.gambar, m.username
                                FROM tblrequest_pinjam r
                                JOIN tblbuku b ON r.id_buku = b.id_buku
                                JOIN tblmember m ON r.id_member = m.id_member
                                WHERE r.status_request = 'Pending'";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    borrowRequestData item = new borrowRequestData();

                    item.NamaBuku = rd["judul"].ToString();
                    item.idBuku = rd["id_buku"].ToString();
                    item.NamaPeminjam = rd["username"].ToString();
                    item.TanggalPinjam = rd["tanggal_request"] != DBNull.Value ? Convert.ToDateTime(rd["tanggal_request"]).ToString("dd-MM-yyyy") : "-";
                    item.TanggalKembali = rd["tanggal_kembali"] != DBNull.Value ? Convert.ToDateTime(rd["tanggal_kembali"]).ToString("dd-MM-yyyy") : "-";

                    int idRequest = Convert.ToInt32(rd["id_request"]);

                    if (rd["gambar"] != DBNull.Value)
                    {
                        byte[] imgBytes = (byte[])rd["gambar"];
                        using (MemoryStream ms = new MemoryStream(imgBytes))
                        {
                            item.GambarBuku = Image.FromStream(ms);
                        }
                    }

                    item.BtnApprove.Click += (s, e) =>
                    {
                        ApprovePinjam(idRequest);

                        layoutPanelBR.Controls.Remove(br);
                        item.Dispose();
                    };

                    item.BtnReject.Click += (s, e) =>
                    {
                        rejectReason form = new rejectReason(usernameAdmin);
                        form.IdRequest = idRequest;
                        form.ShowDialog();

                        LoadBorrowRequest();
                    };

                    layoutPanelBR.Controls.Add(item);
                }
            }
        }

        private void LoadBooked()
        {
            layoutPanelBooked.Controls.Clear();

            bookedTittle judul = new bookedTittle();
            judul.Margin = new Padding(0, 25, 0, 10);
            layoutPanelBooked.Controls.Add(judul);

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"SELECT p.*, b.judul, b.gambar, m.username, d.jumlah_denda
                                FROM tblpeminjaman p
                                JOIN tblbuku b ON p.id_buku = b.id_buku
                                JOIN tblmember m ON p.id_member = m.id_member
                                LEFT JOIN tbldenda d ON p.id_peminjaman = d.id_peminjaman";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    dataBookedBooks item = new dataBookedBooks();

                    item.idBuku = rd["id_buku"].ToString();
                    item.NamaBuku = rd["judul"].ToString();
                    item.NamaPeminjam = rd["username"].ToString();

                    item.TanggalPinjam = rd["tanggal_pinjam"] != DBNull.Value
                        ? Convert.ToDateTime(rd["tanggal_pinjam"]).ToString("dd-MM-yyyy")
                        : "-";

                    string status = rd["status_peminjaman"].ToString().ToLower();

                    if (status == "returned")
                    {
                        item.TanggalKembali = DateTime.Now.ToString("dd-MM-yyyy");
                    }
                    else
                    {
                        item.TanggalKembali = rd["tanggal_kembali"] != DBNull.Value
                            ? Convert.ToDateTime(rd["tanggal_kembali"]).ToString("dd-MM-yyyy")
                            : "-";
                    }

                    item.Denda = rd["jumlah_denda"] != DBNull.Value
                        ? "Rp " + rd["jumlah_denda"].ToString()
                        : "Rp 0";

                    item.Status = rd["status_peminjaman"].ToString();

                    if (rd["gambar"] != DBNull.Value)
                    {
                        byte[] imgBytes = (byte[])rd["gambar"];
                        using (MemoryStream ms = new MemoryStream(imgBytes))
                        {
                            item.GambarBuku = Image.FromStream(ms);
                        }
                    }

                    layoutPanelBooked.Controls.Add(item);
                }
            }

            LoadStats();
        }

        private void LoadReturnRequest()
        {
            layoutPanelRR.Controls.Clear();

            returnRequest rr = new returnRequest();
            rr.Margin = new Padding(0, 25, 0, 10);
            layoutPanelRR.Controls.Add(rr);

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"SELECT r.*, p.id_peminjaman, b.judul, b.gambar, m.username, d.jumlah_denda, p.tanggal_pinjam, p.tanggal_kembali
                                FROM tblrequest_kembali r
                                JOIN tblpeminjaman p ON r.id_peminjaman = p.id_peminjaman
                                JOIN tblbuku b ON p.id_buku = b.id_buku
                                JOIN tblmember m ON p.id_member = m.id_member
                                LEFT JOIN tbldenda d ON p.id_peminjaman = d.id_peminjaman
                                WHERE r.status_request = 'Pending'";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    returnRequestData item = new returnRequestData();

                    item.NamaBuku = rd["judul"].ToString();
                    item.IdBuku = rd["id_peminjaman"].ToString();
                    item.NamaPeminjam = rd["username"].ToString();
                    item.TanggalPinjam = rd["tanggal_pinjam"] != DBNull.Value ? Convert.ToDateTime(rd["tanggal_pinjam"]).ToString("dd-MM-yyyy") : "-";
                    item.TanggalKembali = rd["tanggal_requestkembali"] != DBNull.Value ? Convert.ToDateTime(rd["tanggal_requestkembali"]).ToString("dd-MM-yyyy") : "-";

                    item.Denda = rd["jumlah_denda"] != DBNull.Value ? "Rp " + rd["jumlah_denda"].ToString() : "Rp 0";

                    int idPeminjaman = Convert.ToInt32(rd["id_peminjaman"]);

                    if (rd["gambar"] != DBNull.Value)
                    {
                        byte[] imgBytes = (byte[])rd["gambar"];
                        using (MemoryStream ms = new MemoryStream(imgBytes))
                        {
                            item.GambarBuku = Image.FromStream(ms);
                        }
                    }

                    item.BtnStatus.Click += (s, e) =>
                    {
                        ApproveKembali(idPeminjaman);

                        layoutPanelRR.Controls.Remove(item);
                        item.Dispose();
                    };

                    layoutPanelRR.Controls.Add(item);
                }
            }
        }

        private void ApprovePinjam(int idRequest)
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string get = "SELECT * FROM tblrequest_pinjam WHERE id_request=@id";
                SqlCommand cmdGet = new SqlCommand(get, conn);
                cmdGet.Parameters.AddWithValue("@id", idRequest);

                SqlDataReader rd = cmdGet.ExecuteReader();
                rd.Read();

                int idMember = Convert.ToInt32(rd["id_member"]);
                int idBuku = Convert.ToInt32(rd["id_buku"]);
                DateTime tglPinjam = rd["tanggal_request"] != DBNull.Value ? Convert.ToDateTime(rd["tanggal_request"]) : DateTime.Now;

                DateTime tglKembali = rd["tanggal_kembali"] != DBNull.Value ? Convert.ToDateTime(rd["tanggal_kembali"]) : DateTime.Now;

                rd.Close();

                string insert = @"INSERT INTO tblpeminjaman
                                (id_member, id_buku, id_requestpinjam, tanggal_pinjam, tanggal_kembali, status_peminjaman)
                                VALUES (@m, @b, @req, @tglPinjam, @tglKembali, 'Active')";

                SqlCommand cmd = new SqlCommand(insert, conn);
                cmd.Parameters.AddWithValue("@m", idMember);
                cmd.Parameters.AddWithValue("@b", idBuku);
                cmd.Parameters.AddWithValue("@req", idRequest);
                cmd.Parameters.AddWithValue("@tglPinjam", tglPinjam);
                cmd.Parameters.AddWithValue("@tglKembali", tglKembali);

                cmd.ExecuteNonQuery();

                string updateStok = "UPDATE tblbuku SET stok = stok - 1 WHERE id_buku = @id";
                SqlCommand cmdStok = new SqlCommand(updateStok, conn);
                cmdStok.Parameters.AddWithValue("@id", idBuku);
                cmdStok.ExecuteNonQuery();

                string update = "UPDATE tblrequest_pinjam SET status_request='Approved' WHERE id_request=@id";
                SqlCommand cmdUp = new SqlCommand(update, conn);
                cmdUp.Parameters.AddWithValue("@id", idRequest);
                cmdUp.ExecuteNonQuery();
            }

            LoadBorrowRequest();
            LoadBooked();

            foreach (Form f in Application.OpenForms)
            {
                if (f is DashboardAdmin dash)
                {
                    dash.RefreshDashboard();
                }
            }
        }

        private void LoadStats()
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                lblTotalBooked.Text = new SqlCommand(
                    "SELECT COUNT(*) FROM tblpeminjaman WHERE status_peminjaman='active'", conn
                ).ExecuteScalar().ToString();

                lblBukuKembali.Text = new SqlCommand(
                    "SELECT COUNT(*) FROM tblpeminjaman WHERE status_peminjaman='returned'", conn
                ).ExecuteScalar().ToString();

                lblTelat.Text = new SqlCommand(
                    "SELECT COUNT(*) FROM tbldenda WHERE jumlah_hari_terlambat > 0", conn
                ).ExecuteScalar().ToString();
            }
        }

        private void ApproveKembali(int idPeminjaman)
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string get = "SELECT tanggal_kembali, id_buku FROM tblpeminjaman WHERE id_peminjaman=@id";
                SqlCommand cmd = new SqlCommand(get, conn);
                cmd.Parameters.AddWithValue("@id", idPeminjaman);

                object resultTanggal = null;
                int idBuku = 0;

                SqlDataReader rd = cmd.ExecuteReader();

                if (rd.Read())
                {
                    resultTanggal = rd["tanggal_kembali"];
                    idBuku = Convert.ToInt32(rd["id_buku"]);
                }

                rd.Close();

                DateTime now = DateTime.Now;
                int telat = 0;
                int denda = 0;

                if (resultTanggal != DBNull.Value && resultTanggal != null)
                {
                    DateTime tglKembali = Convert.ToDateTime(resultTanggal);
                    telat = (now - tglKembali).Days;
                    denda = telat > 0 ? telat * 25000 : 0;
                }

                string update = @"UPDATE tblpeminjaman 
                        SET status_peminjaman='returned', tanggal_aktual_kembali=GETDATE()
                        WHERE id_peminjaman=@id";

                SqlCommand cmdUp = new SqlCommand(update, conn);
                cmdUp.Parameters.AddWithValue("@id", idPeminjaman);
                cmdUp.ExecuteNonQuery();

                string updateReq = "UPDATE tblrequest_kembali SET status_request='Approved' WHERE id_peminjaman=@id";
                SqlCommand cmdReq = new SqlCommand(updateReq, conn);
                cmdReq.Parameters.AddWithValue("@id", idPeminjaman);
                cmdReq.ExecuteNonQuery();

                string updateStok = "UPDATE tblbuku SET stok = stok + 1 WHERE id_buku = @id";
                SqlCommand cmdStok = new SqlCommand(updateStok, conn);
                cmdStok.Parameters.AddWithValue("@id", idBuku);
                cmdStok.ExecuteNonQuery();

                if (denda > 0)
                {
                    string d = @"INSERT INTO tbldenda
                        (id_peminjaman, jumlah_hari_terlambat, jumlah_denda)
                        VALUES (@id, @hari, @denda)";

                    SqlCommand cmdD = new SqlCommand(d, conn);
                    cmdD.Parameters.AddWithValue("@id", idPeminjaman);
                    cmdD.Parameters.AddWithValue("@hari", telat);
                    cmdD.Parameters.AddWithValue("@denda", denda);

                    cmdD.ExecuteNonQuery();
                }
            }

            LoadReturnRequest();
            LoadBooked();
            LoadStats();

            foreach (Form f in Application.OpenForms)
            {
                if (f is DashboardAdmin dash)
                {
                    dash.RefreshDashboard();
                }

                if (f is ManageBook mb)
                {
                    mb.LoadData();
                }
            }
        }

        private void lblMonthReport_Click_1(object sender, EventArgs e)
        {
            MonthlyReport report = new MonthlyReport(usernameAdmin);
            report.Show();
            this.Hide();
        }

        private void lblPageDashboard_Click_1(object sender, EventArgs e)
        {
            DashboardAdmin admin = new DashboardAdmin(usernameAdmin);
            admin.Show();
            this.Show();
        }

        private void lblManageBook_Click_1(object sender, EventArgs e)
        {
            ManageBook mbook = new ManageBook(usernameAdmin);
            mbook.Show();
            this.Hide();
        }

        private void lblManageMember_Click_1(object sender, EventArgs e)
        {
            ManageMember mber = new ManageMember(usernameAdmin);
            mber.Show();
            this.Hide();
        }

        private void lblBooked_Click_1(object sender, EventArgs e)
        {
            Booked pinjam = new Booked(usernameAdmin);
            pinjam.Show();
            this.Hide();
        }
    }
}