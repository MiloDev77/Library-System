﻿namespace SistemPerpustakaanKelompok
{
    partial class DashboardAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashboardAdmin));
            lblPageDashboard = new Label();
            lblManageBook = new Label();
            lblManageMember = new Label();
            lblBooked = new Label();
            lblMonthReport = new Label();
            lblLogout = new Label();
            lblTotalBuku = new Label();
            lblTotalMember = new Label();
            lblTotalPinjam = new Label();
            lblTotalTelat = new Label();
            txtSearchBooked = new TextBox();
            lblNamaAdmin = new Label();
            btnSearch = new Label();
            layoutBookedBooks = new FlowLayoutPanel();
            SuspendLayout();
            // 
            // lblPageDashboard
            // 
            lblPageDashboard.AutoSize = true;
            lblPageDashboard.BackColor = Color.Transparent;
            lblPageDashboard.Cursor = Cursors.Hand;
            lblPageDashboard.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblPageDashboard.ForeColor = SystemColors.ControlLightLight;
            lblPageDashboard.Location = new Point(66, 119);
            lblPageDashboard.Name = "lblPageDashboard";
            lblPageDashboard.Size = new Size(63, 13);
            lblPageDashboard.TabIndex = 0;
            lblPageDashboard.Text = "Dashboard";
            lblPageDashboard.Click += lblPageDashboard_Click;
            // 
            // lblManageBook
            // 
            lblManageBook.AutoSize = true;
            lblManageBook.BackColor = Color.Transparent;
            lblManageBook.Cursor = Cursors.Hand;
            lblManageBook.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblManageBook.ForeColor = SystemColors.ControlLightLight;
            lblManageBook.Location = new Point(66, 161);
            lblManageBook.Name = "lblManageBook";
            lblManageBook.Size = new Size(78, 13);
            lblManageBook.TabIndex = 1;
            lblManageBook.Text = "Manage Book";
            lblManageBook.Click += lblManageBook_Click;
            // 
            // lblManageMember
            // 
            lblManageMember.AutoSize = true;
            lblManageMember.BackColor = Color.Transparent;
            lblManageMember.Cursor = Cursors.Hand;
            lblManageMember.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblManageMember.ForeColor = SystemColors.ControlLightLight;
            lblManageMember.Location = new Point(66, 208);
            lblManageMember.Name = "lblManageMember";
            lblManageMember.Size = new Size(94, 13);
            lblManageMember.TabIndex = 2;
            lblManageMember.Text = "Manage Member";
            lblManageMember.Click += lblManageMember_Click;
            // 
            // lblBooked
            // 
            lblBooked.AutoSize = true;
            lblBooked.BackColor = Color.Transparent;
            lblBooked.Cursor = Cursors.Hand;
            lblBooked.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblBooked.ForeColor = SystemColors.ControlLightLight;
            lblBooked.Location = new Point(66, 255);
            lblBooked.Name = "lblBooked";
            lblBooked.Size = new Size(47, 13);
            lblBooked.TabIndex = 3;
            lblBooked.Text = "Booked";
            lblBooked.Click += lblBooked_Click;
            // 
            // lblMonthReport
            // 
            lblMonthReport.AutoSize = true;
            lblMonthReport.BackColor = Color.Transparent;
            lblMonthReport.Cursor = Cursors.Hand;
            lblMonthReport.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblMonthReport.ForeColor = SystemColors.ControlLightLight;
            lblMonthReport.Location = new Point(66, 302);
            lblMonthReport.Name = "lblMonthReport";
            lblMonthReport.Size = new Size(87, 13);
            lblMonthReport.TabIndex = 4;
            lblMonthReport.Text = "Monthly Report";
            lblMonthReport.Click += lblMonthReport_Click;
            // 
            // lblLogout
            // 
            lblLogout.AutoSize = true;
            lblLogout.BackColor = Color.Transparent;
            lblLogout.Cursor = Cursors.Hand;
            lblLogout.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblLogout.ForeColor = SystemColors.ControlLightLight;
            lblLogout.Location = new Point(66, 553);
            lblLogout.Name = "lblLogout";
            lblLogout.Size = new Size(43, 13);
            lblLogout.TabIndex = 5;
            lblLogout.Text = "Logout";
            lblLogout.Click += lblLogout_Click;
            // 
            // lblTotalBuku
            // 
            lblTotalBuku.AutoSize = true;
            lblTotalBuku.BackColor = Color.Transparent;
            lblTotalBuku.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblTotalBuku.ForeColor = SystemColors.ControlLightLight;
            lblTotalBuku.Location = new Point(247, 174);
            lblTotalBuku.Name = "lblTotalBuku";
            lblTotalBuku.Size = new Size(51, 28);
            lblTotalBuku.TabIndex = 6;
            lblTotalBuku.Text = "N/A";
            // 
            // lblTotalMember
            // 
            lblTotalMember.AutoSize = true;
            lblTotalMember.BackColor = Color.Transparent;
            lblTotalMember.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblTotalMember.ForeColor = SystemColors.ControlLightLight;
            lblTotalMember.Location = new Point(488, 174);
            lblTotalMember.Name = "lblTotalMember";
            lblTotalMember.Size = new Size(51, 28);
            lblTotalMember.TabIndex = 7;
            lblTotalMember.Text = "N/A";
            // 
            // lblTotalPinjam
            // 
            lblTotalPinjam.AutoSize = true;
            lblTotalPinjam.BackColor = Color.Transparent;
            lblTotalPinjam.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblTotalPinjam.ForeColor = SystemColors.ControlLightLight;
            lblTotalPinjam.Location = new Point(733, 174);
            lblTotalPinjam.Name = "lblTotalPinjam";
            lblTotalPinjam.Size = new Size(51, 28);
            lblTotalPinjam.TabIndex = 8;
            lblTotalPinjam.Text = "N/A";
            // 
            // lblTotalTelat
            // 
            lblTotalTelat.AutoSize = true;
            lblTotalTelat.BackColor = Color.Transparent;
            lblTotalTelat.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblTotalTelat.ForeColor = SystemColors.ControlLightLight;
            lblTotalTelat.Location = new Point(977, 174);
            lblTotalTelat.Name = "lblTotalTelat";
            lblTotalTelat.Size = new Size(51, 28);
            lblTotalTelat.TabIndex = 9;
            lblTotalTelat.Text = "N/A";
            // 
            // txtSearchBooked
            // 
            txtSearchBooked.BorderStyle = BorderStyle.None;
            txtSearchBooked.Location = new Point(926, 239);
            txtSearchBooked.Multiline = true;
            txtSearchBooked.Name = "txtSearchBooked";
            txtSearchBooked.PlaceholderText = "Search Latest Booked...";
            txtSearchBooked.ScrollBars = ScrollBars.Horizontal;
            txtSearchBooked.Size = new Size(208, 19);
            txtSearchBooked.TabIndex = 10;
            txtSearchBooked.TextChanged += txtSearchBooked_TextChanged;
            // 
            // lblNamaAdmin
            // 
            lblNamaAdmin.BackColor = Color.Transparent;
            lblNamaAdmin.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNamaAdmin.ForeColor = SystemColors.ControlLightLight;
            lblNamaAdmin.Location = new Point(1048, 25);
            lblNamaAdmin.Name = "lblNamaAdmin";
            lblNamaAdmin.Size = new Size(131, 20);
            lblNamaAdmin.TabIndex = 11;
            lblNamaAdmin.Text = "N/A";
            lblNamaAdmin.TextAlign = ContentAlignment.MiddleRight;
            lblNamaAdmin.Click += lblNamaAdmin_Click;
            // 
            // btnSearch
            // 
            btnSearch.AutoSize = true;
            btnSearch.BackColor = SystemColors.ControlLightLight;
            btnSearch.Location = new Point(904, 241);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(19, 15);
            btnSearch.TabIndex = 12;
            btnSearch.Text = "🔍";
            // 
            // layoutBookedBooks
            // 
            layoutBookedBooks.BackColor = Color.Transparent;
            layoutBookedBooks.Location = new Point(228, 266);
            layoutBookedBooks.Name = "layoutBookedBooks";
            layoutBookedBooks.Size = new Size(945, 300);
            layoutBookedBooks.TabIndex = 13;
            // 
            // DashboardAdmin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1216, 588);
            Controls.Add(layoutBookedBooks);
            Controls.Add(btnSearch);
            Controls.Add(lblNamaAdmin);
            Controls.Add(txtSearchBooked);
            Controls.Add(lblTotalTelat);
            Controls.Add(lblTotalPinjam);
            Controls.Add(lblTotalMember);
            Controls.Add(lblTotalBuku);
            Controls.Add(lblLogout);
            Controls.Add(lblMonthReport);
            Controls.Add(lblBooked);
            Controls.Add(lblManageMember);
            Controls.Add(lblManageBook);
            Controls.Add(lblPageDashboard);
            DoubleBuffered = true;
            Margin = new Padding(3, 2, 3, 2);
            Name = "DashboardAdmin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "DashboardAdmin";
            Load += DashboardAdmin_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPageDashboard;
        private Label lblManageBook;
        private Label lblManageMember;
        private Label lblBooked;
        private Label lblMonthReport;
        private Label lblLogout;
        private Label lblTotalBuku;
        private Label lblTotalMember;
        private Label lblTotalPinjam;
        private Label lblTotalTelat;
        private TextBox txtSearchBooked;
        private Label lblNamaAdmin;
        private Label btnSearch;
        private FlowLayoutPanel layoutBookedBooks;
    }
}