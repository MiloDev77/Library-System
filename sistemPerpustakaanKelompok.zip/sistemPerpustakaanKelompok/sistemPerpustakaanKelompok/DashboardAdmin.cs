﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class DashboardAdmin : Form
    {
        public void RefreshDashboard()
        {
            LoadDashboard();
            LoadLatestBooked();
        }

        string usernameAdmin;
        public DashboardAdmin(string username)
        {
            InitializeComponent();
            usernameAdmin = username;
        }

        private void lblLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void lblNamaAdmin_Click(object sender, EventArgs e)
        {

        }

        private void DashboardAdmin_Load(object sender, EventArgs e)
        {
            layoutBookedBooks.AutoScroll = true;
            lblNamaAdmin.Text = usernameAdmin;

            LoadDashboard();
            LoadLatestBooked();
        }

        private void lblBooked_Click(object sender, EventArgs e)
        {
            Booked pinjam = new Booked(usernameAdmin);
            pinjam.Show();
            this.Hide();
        }

        private void lblPageDashboard_Click(object sender, EventArgs e)
        {
            DashboardAdmin dashboard = new DashboardAdmin(usernameAdmin);
            dashboard.Show();
            this.Hide();
        }

        private void lblManageBook_Click(object sender, EventArgs e)
        {
            ManageBook mb = new ManageBook(usernameAdmin);
            mb.Show();
            this.Hide();
        }

        private void lblManageMember_Click(object sender, EventArgs e)
        {
            ManageMember mbr = new ManageMember(usernameAdmin);
            mbr.Show();
            this.Hide();
        }

        private void lblMonthReport_Click(object sender, EventArgs e)
        {
            MonthlyReport report = new MonthlyReport(usernameAdmin);
            report.Show();
            this.Hide();
        }

        private void LoadDashboard()
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                lblTotalBuku.Text = new SqlCommand(
                    "SELECT COUNT(*) FROM tblbuku", conn
                ).ExecuteScalar().ToString();

                lblTotalMember.Text = new SqlCommand(
                    "SELECT COUNT(*) FROM tblmember", conn
                ).ExecuteScalar().ToString();

                lblTotalPinjam.Text = new SqlCommand(
                    "SELECT COUNT(*) FROM tblpeminjaman WHERE status_peminjaman='active'", conn
                ).ExecuteScalar().ToString();

                lblTotalTelat.Text = new SqlCommand(
                    "SELECT COUNT(*) FROM tbldenda WHERE jumlah_hari_terlambat > 0", conn
                ).ExecuteScalar().ToString();
            }
        }

        private void LoadLatestBooked(string keyword = "")
        {
            layoutBookedBooks.Controls.Clear();

            bookedTittle judul = new bookedTittle();
            judul.Margin = new Padding(0, 0, 0, 10);
            layoutBookedBooks.Controls.Add(judul);

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"SELECT TOP 10 p.*, b.judul, b.gambar, m.username, d.jumlah_denda
                                FROM tblpeminjaman p
                                JOIN tblbuku b ON p.id_buku = b.id_buku
                                JOIN tblmember m ON p.id_member = m.id_member
                                LEFT JOIN tbldenda d ON p.id_peminjaman = d.id_peminjaman
                                WHERE m.username LIKE @search
                                ORDER BY p.tanggal_pinjam DESC";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@search", "%" + keyword + "%");

                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    dataBookedBooks item = new dataBookedBooks();

                    item.idBuku = rd["id_buku"].ToString();
                    item.NamaBuku = rd["judul"].ToString();
                    item.NamaPeminjam = rd["username"].ToString();

                    item.TanggalPinjam = rd["tanggal_pinjam"] != DBNull.Value
                        ? Convert.ToDateTime(rd["tanggal_pinjam"]).ToString("dd-MM-yyyy")
                        : "-";

                    string status = rd["status_peminjaman"].ToString().ToLower();

                    if (status == "returned")
                    {
                        item.TanggalKembali = DateTime.Now.ToString("dd-MM-yyyy");
                    }
                    else
                    {
                        item.TanggalKembali = rd["tanggal_kembali"] != DBNull.Value
                            ? Convert.ToDateTime(rd["tanggal_kembali"]).ToString("dd-MM-yyyy")
                            : "-";
                    }

                    item.Denda = rd["jumlah_denda"] != DBNull.Value
                        ? "Rp " + rd["jumlah_denda"].ToString()
                        : "Rp 0";

                    item.Status = rd["status_peminjaman"].ToString();

                    if (rd["gambar"] != DBNull.Value)
                    {
                        byte[] imgBytes = (byte[])rd["gambar"];
                        using (MemoryStream ms = new MemoryStream(imgBytes))
                        {
                            item.GambarBuku = Image.FromStream(ms);
                        }
                    }

                    layoutBookedBooks.Controls.Add(item);
                }
            }
        }

        private void txtSearchBooked_TextChanged(object sender, EventArgs e)
        {
            LoadLatestBooked(txtSearchBooked.Text);
        }
    }
}
