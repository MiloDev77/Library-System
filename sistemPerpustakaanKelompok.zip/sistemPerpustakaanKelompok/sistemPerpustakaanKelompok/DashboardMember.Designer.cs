﻿namespace SistemPerpustakaanKelompok
{
    partial class DashboardMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashboardMember));
            lblLogout = new Label();
            lblProfile = new Label();
            lblHistory = new Label();
            lblMyBook = new Label();
            lblBookCatalogue = new Label();
            lblPageDashboard = new Label();
            lblNamaMember = new Label();
            lblUsername = new Label();
            lblTotalBooked = new Label();
            lblDueDate = new Label();
            lblLiteracyPoint = new Label();
            changeLabel = new Label();
            layoutPanelRecom = new FlowLayoutPanel();
            lblInbox = new Label();
            SuspendLayout();
            // 
            // lblLogout
            // 
            lblLogout.AutoSize = true;
            lblLogout.BackColor = Color.Transparent;
            lblLogout.Cursor = Cursors.Hand;
            lblLogout.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblLogout.ForeColor = SystemColors.ControlLightLight;
            lblLogout.Location = new Point(63, 553);
            lblLogout.Name = "lblLogout";
            lblLogout.Size = new Size(43, 13);
            lblLogout.TabIndex = 30;
            lblLogout.Text = "Logout";
            lblLogout.Click += lblLogout_Click;
            // 
            // lblProfile
            // 
            lblProfile.AutoSize = true;
            lblProfile.BackColor = Color.Transparent;
            lblProfile.Cursor = Cursors.Hand;
            lblProfile.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblProfile.ForeColor = SystemColors.ControlLightLight;
            lblProfile.Location = new Point(63, 312);
            lblProfile.Name = "lblProfile";
            lblProfile.Size = new Size(40, 13);
            lblProfile.TabIndex = 29;
            lblProfile.Text = "Profile";
            lblProfile.Click += lblProfile_Click;
            // 
            // lblHistory
            // 
            lblHistory.AutoSize = true;
            lblHistory.BackColor = Color.Transparent;
            lblHistory.Cursor = Cursors.Hand;
            lblHistory.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblHistory.ForeColor = SystemColors.ControlLightLight;
            lblHistory.Location = new Point(63, 264);
            lblHistory.Name = "lblHistory";
            lblHistory.Size = new Size(44, 13);
            lblHistory.TabIndex = 28;
            lblHistory.Text = "History";
            lblHistory.Click += lblHistory_Click;
            // 
            // lblMyBook
            // 
            lblMyBook.AutoSize = true;
            lblMyBook.BackColor = Color.Transparent;
            lblMyBook.Cursor = Cursors.Hand;
            lblMyBook.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblMyBook.ForeColor = SystemColors.ControlLightLight;
            lblMyBook.Location = new Point(63, 218);
            lblMyBook.Name = "lblMyBook";
            lblMyBook.Size = new Size(53, 13);
            lblMyBook.TabIndex = 27;
            lblMyBook.Text = "My Book";
            lblMyBook.Click += lblMyBook_Click;
            // 
            // lblBookCatalogue
            // 
            lblBookCatalogue.AutoSize = true;
            lblBookCatalogue.BackColor = Color.Transparent;
            lblBookCatalogue.Cursor = Cursors.Hand;
            lblBookCatalogue.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblBookCatalogue.ForeColor = SystemColors.ControlLightLight;
            lblBookCatalogue.Location = new Point(63, 172);
            lblBookCatalogue.Name = "lblBookCatalogue";
            lblBookCatalogue.Size = new Size(89, 13);
            lblBookCatalogue.TabIndex = 26;
            lblBookCatalogue.Text = "Book Catalogue";
            lblBookCatalogue.Click += lblBookCatalogue_Click;
            // 
            // lblPageDashboard
            // 
            lblPageDashboard.AutoSize = true;
            lblPageDashboard.BackColor = Color.Transparent;
            lblPageDashboard.Cursor = Cursors.Hand;
            lblPageDashboard.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblPageDashboard.ForeColor = SystemColors.ControlLightLight;
            lblPageDashboard.Location = new Point(63, 124);
            lblPageDashboard.Name = "lblPageDashboard";
            lblPageDashboard.Size = new Size(63, 13);
            lblPageDashboard.TabIndex = 25;
            lblPageDashboard.Text = "Dashboard";
            lblPageDashboard.Click += lblPageDashboard_Click;
            // 
            // lblNamaMember
            // 
            lblNamaMember.BackColor = Color.Transparent;
            lblNamaMember.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNamaMember.ForeColor = SystemColors.ControlLightLight;
            lblNamaMember.Location = new Point(1048, 25);
            lblNamaMember.Name = "lblNamaMember";
            lblNamaMember.Size = new Size(131, 20);
            lblNamaMember.TabIndex = 31;
            lblNamaMember.Text = "N/A";
            lblNamaMember.TextAlign = ContentAlignment.MiddleRight;
            // 
            // lblUsername
            // 
            lblUsername.BackColor = Color.Transparent;
            lblUsername.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblUsername.ForeColor = SystemColors.ControlLightLight;
            lblUsername.Location = new Point(447, 85);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(449, 40);
            lblUsername.TabIndex = 32;
            lblUsername.Text = "N/A";
            lblUsername.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblTotalBooked
            // 
            lblTotalBooked.BackColor = Color.Transparent;
            lblTotalBooked.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTotalBooked.ForeColor = SystemColors.ControlLightLight;
            lblTotalBooked.Location = new Point(297, 211);
            lblTotalBooked.Name = "lblTotalBooked";
            lblTotalBooked.Size = new Size(171, 21);
            lblTotalBooked.TabIndex = 33;
            lblTotalBooked.Text = "N/A";
            lblTotalBooked.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblDueDate
            // 
            lblDueDate.BackColor = Color.Transparent;
            lblDueDate.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDueDate.ForeColor = SystemColors.ControlLightLight;
            lblDueDate.Location = new Point(645, 212);
            lblDueDate.Name = "lblDueDate";
            lblDueDate.Size = new Size(176, 19);
            lblDueDate.TabIndex = 33;
            lblDueDate.Text = "N/A";
            lblDueDate.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblLiteracyPoint
            // 
            lblLiteracyPoint.BackColor = Color.Transparent;
            lblLiteracyPoint.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblLiteracyPoint.ForeColor = SystemColors.ControlLightLight;
            lblLiteracyPoint.Location = new Point(1003, 212);
            lblLiteracyPoint.Name = "lblLiteracyPoint";
            lblLiteracyPoint.Size = new Size(176, 19);
            lblLiteracyPoint.TabIndex = 33;
            lblLiteracyPoint.Text = "N/A";
            lblLiteracyPoint.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // changeLabel
            // 
            changeLabel.BackColor = Color.Transparent;
            changeLabel.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            changeLabel.ForeColor = SystemColors.ControlLightLight;
            changeLabel.Location = new Point(232, 262);
            changeLabel.Name = "changeLabel";
            changeLabel.Size = new Size(947, 42);
            changeLabel.TabIndex = 33;
            changeLabel.Text = "Recommendation For You";
            changeLabel.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // layoutPanelRecom
            // 
            layoutPanelRecom.BackColor = Color.Transparent;
            layoutPanelRecom.Location = new Point(232, 312);
            layoutPanelRecom.Name = "layoutPanelRecom";
            layoutPanelRecom.Size = new Size(963, 252);
            layoutPanelRecom.TabIndex = 34;
            // 
            // lblInbox
            // 
            lblInbox.AutoSize = true;
            lblInbox.BackColor = Color.Transparent;
            lblInbox.Cursor = Cursors.Hand;
            lblInbox.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblInbox.ForeColor = SystemColors.ControlLightLight;
            lblInbox.Location = new Point(1162, 280);
            lblInbox.Name = "lblInbox";
            lblInbox.Size = new Size(33, 21);
            lblInbox.TabIndex = 35;
            lblInbox.Text = "📩";
            lblInbox.Click += lblInbox_Click;
            // 
            // DashboardMember
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1216, 588);
            Controls.Add(lblInbox);
            Controls.Add(layoutPanelRecom);
            Controls.Add(lblLiteracyPoint);
            Controls.Add(lblDueDate);
            Controls.Add(changeLabel);
            Controls.Add(lblTotalBooked);
            Controls.Add(lblUsername);
            Controls.Add(lblNamaMember);
            Controls.Add(lblLogout);
            Controls.Add(lblProfile);
            Controls.Add(lblHistory);
            Controls.Add(lblMyBook);
            Controls.Add(lblBookCatalogue);
            Controls.Add(lblPageDashboard);
            DoubleBuffered = true;
            Margin = new Padding(3, 2, 3, 2);
            Name = "DashboardMember";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "DashboardMember";
            Load += DashboardMember_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblLogout;
        private Label lblProfile;
        private Label lblHistory;
        private Label lblMyBook;
        private Label lblBookCatalogue;
        private Label lblPageDashboard;
        private Label lblNamaMember;
        private Label lblUsername;
        private Label lblTotalBooked;
        private Label lblDueDate;
        private Label lblLiteracyPoint;
        private Label changeLabel;
        private FlowLayoutPanel layoutPanelRecom;
        private Label lblInbox;
    }
}