﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class DashboardMember : Form
    {
        string usernameMember;
        int point;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string UsernameGreetings
        {
            get => lblUsername.Text;
            set => lblUsername.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TotalBookedBooks
        {
            get => lblTotalBooked.Text;
            set => lblTotalBooked.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TotalDueDates
        {
            get => lblDueDate.Text;
            set => lblDueDate.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string LiteracyPoint
        {
            get => lblLiteracyPoint.Text;
            set => lblLiteracyPoint.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string RecommendationLabel
        {
            get => changeLabel.Text;
            set => changeLabel.Text = value;
        }
        public DashboardMember(string username)
        {
            InitializeComponent();
            usernameMember = username;
        }

        private void lblPageDashboard_Click(object sender, EventArgs e)
        {
            DashboardMember dashboardMember = new DashboardMember(usernameMember);
            dashboardMember.Show();
            this.Hide();
        }

        private void DashboardMember_Load(object sender, EventArgs e)
        {
            lblNamaMember.Text = usernameMember;
            layoutPanelRecom.AutoScroll = true;

            LoadDashboard();
            LoadRecommendation();
        }
        private void LoadDashboard()
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string getId = "SELECT id_member, is_active FROM tblmember WHERE username=@u";
                SqlCommand cmdId = new SqlCommand(getId, conn);
                cmdId.Parameters.AddWithValue("@u", usernameMember);

                SqlDataReader rd = cmdId.ExecuteReader();

                int idMember = 0;
                bool isActive = true;

                if (rd.Read())
                {
                    idMember = Convert.ToInt32(rd["id_member"]);
                    isActive = Convert.ToBoolean(rd["is_active"]);
                }
                rd.Close();

                string qTotal = "SELECT COUNT(*) FROM tblpeminjaman WHERE id_member=@id";
                SqlCommand cmdTotal = new SqlCommand(qTotal, conn);
                cmdTotal.Parameters.AddWithValue("@id", idMember);
                int total = (int)cmdTotal.ExecuteScalar();

                TotalBookedBooks = total.ToString();

                string qLate = @"SELECT COUNT(*) FROM tblpeminjaman 
                         WHERE id_member=@id 
                         AND status_peminjaman='Active'
                         AND tanggal_kembali < GETDATE()";

                SqlCommand cmdLate = new SqlCommand(qLate, conn);
                cmdLate.Parameters.AddWithValue("@id", idMember);
                int late = (int)cmdLate.ExecuteScalar();

                TotalDueDates = late.ToString();

                point = 0;

                string qHistory = @"SELECT tanggal_kembali, tanggal_aktual_kembali 
                           FROM tblpeminjaman
                           WHERE id_member=@id 
                           AND status_peminjaman='Returned'";

                SqlCommand cmdHis = new SqlCommand(qHistory, conn);
                cmdHis.Parameters.AddWithValue("@id", idMember);

                SqlDataReader rdHis = cmdHis.ExecuteReader();

                while (rdHis.Read())
                {
                    DateTime due = Convert.ToDateTime(rdHis["tanggal_kembali"]);
                    DateTime actual;

                    if (rdHis["tanggal_aktual_kembali"] == DBNull.Value)
                    {
                        actual = due;
                    }
                    else
                    {
                        actual = Convert.ToDateTime(rdHis["tanggal_aktual_kembali"]);
                    }

                    if (actual.Date <= due.Date)
                        point += 10;
                    else
                        point -= 10;
                }
                rdHis.Close();

                LiteracyPoint = point.ToString();
                string updatePoint = "UPDATE tblmember SET point=@p WHERE id_member=@id";
                SqlCommand cmdPoint = new SqlCommand(updatePoint, conn);

                cmdPoint.Parameters.AddWithValue("@p", point);
                cmdPoint.Parameters.AddWithValue("@id", idMember);

                cmdPoint.ExecuteNonQuery();

                if (point < 0 && total >= 2)
                {
                    string nonaktif = "UPDATE tblmember SET is_active=0 WHERE id_member=@id";
                    SqlCommand cmdNon = new SqlCommand(nonaktif, conn);
                    cmdNon.Parameters.AddWithValue("@id", idMember);
                    cmdNon.ExecuteNonQuery();
                }

                UsernameGreetings = usernameMember;
            }
        }

        private void LoadRecommendation()
        {
            layoutPanelRecom.Controls.Clear();

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string check = @"SELECT COUNT(*) 
                         FROM tblpeminjaman p
                         JOIN tblmember m ON p.id_member=m.id_member
                         WHERE m.username=@u";

                SqlCommand cmdCheck = new SqlCommand(check, conn);
                cmdCheck.Parameters.AddWithValue("@u", usernameMember);

                int pernahPinjam = (int)cmdCheck.ExecuteScalar();

                if (pernahPinjam > 0)
                {
                    RecommendationLabel = "Find New Books To Borrow!";
                }

                string query;

                if (pernahPinjam > 0)
                {
                    query = @"SELECT b.*, p.nama_penulis, j.jenis
                      FROM tblbuku b
                      JOIN tblpenulis p ON b.penulis_id=p.id_penulis
                      JOIN tbljenisbuku j ON b.jenisbuku_id=j.id_jenis
                      WHERE b.id_buku NOT IN (
                          SELECT id_buku FROM tblpeminjaman pm
                          JOIN tblmember m ON pm.id_member=m.id_member
                          WHERE m.username=@u
                      )";
                }
                else
                {
                    query = @"SELECT b.*, p.nama_penulis, j.jenis
                      FROM tblbuku b
                      JOIN tblpenulis p ON b.penulis_id=p.id_penulis
                      JOIN tbljenisbuku j ON b.jenisbuku_id=j.id_jenis";
                }

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@u", usernameMember);

                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    templateBook item = new templateBook();

                    item.BookName = rd["judul"].ToString();
                    item.Writer = rd["nama_penulis"].ToString();
                    item.BookGenre = rd["jenis"].ToString();
                    item.PublishYear = Convert.ToInt32(rd["tahun_terbit"]);

                    if (rd["gambar"] != DBNull.Value)
                    {
                        byte[] imgBytes = (byte[])rd["gambar"];
                        using (MemoryStream ms = new MemoryStream(imgBytes))
                        {
                            item.BookImage = Image.FromStream(ms);
                        }
                    }

                    int idBuku = Convert.ToInt32(rd["id_buku"]);
                    string judul = rd["judul"].ToString();
                    string penulis = rd["nama_penulis"].ToString();
                    string genre = rd["jenis"].ToString();
                    string tahun = rd["tahun_terbit"].ToString();
                    string penerbit = rd["penerbit_id"].ToString();
                    string deskripsi = rd["deskripsi_buku"].ToString();
                    string stok = rd["stok"].ToString();

                    Image img = null;
                    if (rd["gambar"] != DBNull.Value)
                    {
                        byte[] imgBytes = (byte[])rd["gambar"];
                        using (MemoryStream ms = new MemoryStream(imgBytes))
                        {
                            img = Image.FromStream(ms);
                        }
                    }

                    item.BtnDetail.Click += (s, e) =>
                    {
                        BookDetail detail = new BookDetail();

                        detail.BookName = judul;
                        detail.Writer = penulis;
                        detail.BookGenre = genre;
                        detail.PublisherName = penerbit;
                        detail.PublishYear = tahun;
                        detail.Description = deskripsi;
                        detail.Stock = stok;

                        if (img != null)
                            detail.BookImage = img;

                        detail.SetData(idBuku, usernameMember);

                        detail.Show();
                    };

                    layoutPanelRecom.Controls.Add(item);
                }
            }
        }

        private void lblBookCatalogue_Click(object sender, EventArgs e)
        {
            BookCatalogue bookCatalogue = new BookCatalogue(usernameMember);
            bookCatalogue.Show();
            this.Hide();
        }

        private void lblMyBook_Click(object sender, EventArgs e)
        {
            MyBook myBook = new MyBook(usernameMember);
            myBook.Show();
            this.Hide();
        }

        private void lblHistory_Click(object sender, EventArgs e)
        {
            History history = new History(usernameMember);
            history.Show();
            this.Hide();
        }

        private void lblProfile_Click(object sender, EventArgs e)
        {
            Profile profile = new Profile(usernameMember);
            profile.Show();
            this.Hide();
        }

        private void lblLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void lblInbox_Click(object sender, EventArgs e)
        {
            Inbox inbox = new Inbox(usernameMember);
            inbox.Show();
            this.Hide();
        }
    }
}
