﻿namespace SistemPerpustakaanKelompok
{
    partial class EditBuku
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditBuku));
            txtStock = new TextBox();
            txtTahunTerbit = new TextBox();
            txtPenerbit = new TextBox();
            txtPenulis = new TextBox();
            txtJenisBuku = new TextBox();
            txtJudul = new TextBox();
            btnEdit = new Button();
            gambarBuku = new PictureBox();
            txtDeskripsi = new RichTextBox();
            ((System.ComponentModel.ISupportInitialize)gambarBuku).BeginInit();
            SuspendLayout();
            // 
            // txtStock
            // 
            txtStock.BorderStyle = BorderStyle.None;
            txtStock.Location = new Point(221, 137);
            txtStock.Name = "txtStock";
            txtStock.PlaceholderText = "Stock";
            txtStock.Size = new Size(414, 16);
            txtStock.TabIndex = 26;
            txtStock.TextAlign = HorizontalAlignment.Center;
            // 
            // txtTahunTerbit
            // 
            txtTahunTerbit.BorderStyle = BorderStyle.None;
            txtTahunTerbit.Location = new Point(221, 115);
            txtTahunTerbit.Name = "txtTahunTerbit";
            txtTahunTerbit.PlaceholderText = "Publication Year";
            txtTahunTerbit.Size = new Size(414, 16);
            txtTahunTerbit.TabIndex = 27;
            txtTahunTerbit.TextAlign = HorizontalAlignment.Center;
            // 
            // txtPenerbit
            // 
            txtPenerbit.BorderStyle = BorderStyle.None;
            txtPenerbit.Location = new Point(221, 93);
            txtPenerbit.Name = "txtPenerbit";
            txtPenerbit.PlaceholderText = "Publisher Name";
            txtPenerbit.Size = new Size(414, 16);
            txtPenerbit.TabIndex = 28;
            txtPenerbit.TextAlign = HorizontalAlignment.Center;
            // 
            // txtPenulis
            // 
            txtPenulis.BorderStyle = BorderStyle.None;
            txtPenulis.Location = new Point(221, 71);
            txtPenulis.Name = "txtPenulis";
            txtPenulis.PlaceholderText = "Writer Name";
            txtPenulis.Size = new Size(414, 16);
            txtPenulis.TabIndex = 29;
            txtPenulis.TextAlign = HorizontalAlignment.Center;
            // 
            // txtJenisBuku
            // 
            txtJenisBuku.BorderStyle = BorderStyle.None;
            txtJenisBuku.Location = new Point(221, 49);
            txtJenisBuku.Name = "txtJenisBuku";
            txtJenisBuku.PlaceholderText = "Book Type";
            txtJenisBuku.Size = new Size(414, 16);
            txtJenisBuku.TabIndex = 30;
            txtJenisBuku.TextAlign = HorizontalAlignment.Center;
            // 
            // txtJudul
            // 
            txtJudul.BorderStyle = BorderStyle.None;
            txtJudul.Location = new Point(221, 27);
            txtJudul.Name = "txtJudul";
            txtJudul.PlaceholderText = "Title";
            txtJudul.Size = new Size(414, 16);
            txtJudul.TabIndex = 31;
            txtJudul.TextAlign = HorizontalAlignment.Center;
            // 
            // btnEdit
            // 
            btnEdit.BackColor = Color.FromArgb(255, 128, 0);
            btnEdit.Cursor = Cursors.Hand;
            btnEdit.FlatStyle = FlatStyle.Popup;
            btnEdit.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnEdit.ForeColor = SystemColors.ControlText;
            btnEdit.Location = new Point(221, 310);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(414, 31);
            btnEdit.TabIndex = 25;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = false;
            btnEdit.Click += btnEdit_Click;
            // 
            // gambarBuku
            // 
            gambarBuku.BackColor = Color.Transparent;
            gambarBuku.Cursor = Cursors.Hand;
            gambarBuku.Location = new Point(12, 15);
            gambarBuku.Name = "gambarBuku";
            gambarBuku.Size = new Size(203, 345);
            gambarBuku.TabIndex = 24;
            gambarBuku.TabStop = false;
            gambarBuku.Click += gambarBuku_Click;
            // 
            // txtDeskripsi
            // 
            txtDeskripsi.Location = new Point(221, 160);
            txtDeskripsi.Name = "txtDeskripsi";
            txtDeskripsi.Size = new Size(414, 144);
            txtDeskripsi.TabIndex = 33;
            txtDeskripsi.Text = "";
            // 
            // EditBuku
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(668, 372);
            Controls.Add(txtDeskripsi);
            Controls.Add(txtStock);
            Controls.Add(txtTahunTerbit);
            Controls.Add(txtPenerbit);
            Controls.Add(txtPenulis);
            Controls.Add(txtJenisBuku);
            Controls.Add(txtJudul);
            Controls.Add(btnEdit);
            Controls.Add(gambarBuku);
            DoubleBuffered = true;
            Name = "EditBuku";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EditBuku";
            Load += EditBuku_Load;
            ((System.ComponentModel.ISupportInitialize)gambarBuku).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtStock;
        private TextBox txtTahunTerbit;
        private TextBox txtPenerbit;
        private TextBox txtPenulis;
        private TextBox txtJenisBuku;
        private TextBox txtJudul;
        private Button btnEdit;
        private PictureBox gambarBuku;
        private RichTextBox txtDeskripsi;
    }
}