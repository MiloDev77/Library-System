﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.IO;

namespace SistemPerpustakaanKelompok
{
    public partial class EditBuku : Form
    {
        string usernameAdmin;
        int idBuku;
        byte[] imageByte;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Judul
        {
            get => txtJudul.Text;
            set => txtJudul.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string JenisBuku
        {
            get => txtJenisBuku.Text;
            set => txtJenisBuku.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Penulis
        {
            get => txtPenulis.Text;
            set => txtPenulis.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Penerbit
        {
            get => txtPenerbit.Text;
            set => txtPenerbit.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TahunTerbit
        {
            get => txtTahunTerbit.Text;
            set => txtTahunTerbit.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Stok
        {
            get => txtStock.Text;
            set => txtStock.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Deskripsi
        {
            get => txtDeskripsi.Text;
            set => txtDeskripsi.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Image GambarBuku
        {
            set
            {
                gambarBuku.Image = value;
                gambarBuku.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }
        public EditBuku(int id, string username)
        {
            InitializeComponent();
            idBuku = id;
            usernameAdmin = username;
        }

        private void EditBuku_Load(object sender, EventArgs e)
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"SELECT 
                        b.judul,
                        j.jenis,
                        p.nama_penulis,
                        pb.nama_penerbit,
                        b.tahun_terbit,
                        b.stok,
                        b.deskripsi_buku,
                        b.gambar
                        FROM tblbuku b
                        JOIN tbljenisbuku j ON b.jenisbuku_id = j.id_jenis
                        JOIN tblpenulis p ON b.penulis_id = p.id_penulis
                        JOIN tblpenerbit pb ON b.penerbit_id = pb.id_penerbit
                        WHERE b.id_buku=@id";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", idBuku);

                SqlDataReader rd = cmd.ExecuteReader();

                if (rd.Read())
                {
                    Judul = rd["judul"].ToString();
                    JenisBuku = rd["jenis"].ToString();
                    Penulis = rd["nama_penulis"].ToString();
                    Penerbit = rd["nama_penerbit"].ToString();
                    TahunTerbit = rd["tahun_terbit"].ToString();
                    Deskripsi = rd["deskripsi_buku"].ToString();
                    Stok = rd["stok"].ToString();
                    if (rd["gambar"] != DBNull.Value)
                    {
                        byte[] image = (byte[])rd["gambar"];
                        using (MemoryStream ms = new MemoryStream(image))
                        {
                            GambarBuku = Image.FromStream(ms);
                        }

                        imageByte = image;
                    }
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (Judul== "" ||
                JenisBuku == "" ||
                Penulis == "" ||
                Penerbit == "" ||
                TahunTerbit == "" ||
                Deskripsi == "" ||
                Stok == "")
            {
                MessageBox.Show("All Fields Must Be Filled!");
                return;
            }

            long idPenulis = GetPenulisId(Penulis);
            long idJenis = GetJenisId(JenisBuku);
            long idPenerbit = GetPenerbitId(Penerbit);

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"UPDATE tblbuku SET
                        judul=@judul,
                        jenisbuku_id=@jenis,
                        penulis_id=@penulis,
                        penerbit_id=@penerbit,
                        tahun_terbit=@tahun,
                        stok=@stok,
                        deskripsi_buku=@deskripsi,
                        gambar=@gambar
                        WHERE id_buku=@id";

                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@judul", txtJudul.Text);
                cmd.Parameters.AddWithValue("@jenis", idJenis);
                cmd.Parameters.AddWithValue("@penulis", idPenulis);
                cmd.Parameters.AddWithValue("@penerbit", idPenerbit);
                cmd.Parameters.AddWithValue("@tahun", txtTahunTerbit.Text);
                cmd.Parameters.AddWithValue("@gambar", imageByte ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@stok", txtStock.Text);
                cmd.Parameters.AddWithValue("@deskripsi", txtDeskripsi.Text);
                cmd.Parameters.AddWithValue("@id", idBuku);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Data Successfully Updated!");

            ManageBook mb = new ManageBook(usernameAdmin);
            mb.Show();
            this.Close();
        }

        private void gambarBuku_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.jpg;*.png;*.jpeg";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                gambarBuku.Image = Image.FromFile(ofd.FileName);
                imageByte = File.ReadAllBytes(ofd.FileName);
            }
        }
        private long GetId(string querySelect, string queryInsert, string paramName, string value)
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(querySelect, conn);
                cmd.Parameters.AddWithValue(paramName, value);

                object result = cmd.ExecuteScalar();

                if (result != null)
                    return Convert.ToInt64(result);

                SqlCommand cmdInsert = new SqlCommand(queryInsert, conn);
                cmdInsert.Parameters.AddWithValue(paramName, value);

                return Convert.ToInt64(cmdInsert.ExecuteScalar());
            }
        }

        private long GetJenisId(string jenis)
        {
            return GetId(
                "SELECT id_jenis FROM tbljenisbuku WHERE jenis=@x",
                "INSERT INTO tbljenisbuku (jenis) OUTPUT INSERTED.id_jenis VALUES (@x)",
                "@x", jenis);
        }

        private long GetPenulisId(string nama)
        {
            return GetId(
                "SELECT id_penulis FROM tblpenulis WHERE nama_penulis=@x",
                "INSERT INTO tblpenulis (nama_penulis) OUTPUT INSERTED.id_penulis VALUES (@x)",
                "@x", nama);
        }

        private long GetPenerbitId(string nama)
        {
            return GetId(
                "SELECT id_penerbit FROM tblpenerbit WHERE nama_penerbit=@x",
                "INSERT INTO tblpenerbit (nama_penerbit) OUTPUT INSERTED.id_penerbit VALUES (@x)",
                "@x", nama);
        }
    }
}
