﻿namespace SistemPerpustakaanKelompok
{
    partial class EditProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditProfile));
            gambarBuku = new PictureBox();
            label1 = new Label();
            txtUsername = new TextBox();
            label2 = new Label();
            txtIdMember = new TextBox();
            label3 = new Label();
            txtAlamat = new TextBox();
            label4 = new Label();
            txtNoHp = new TextBox();
            btnEdit = new Button();
            label5 = new Label();
            txtPassword = new TextBox();
            ((System.ComponentModel.ISupportInitialize)gambarBuku).BeginInit();
            SuspendLayout();
            // 
            // gambarBuku
            // 
            gambarBuku.BackColor = Color.Transparent;
            gambarBuku.BackgroundImage = (Image)resources.GetObject("gambarBuku.BackgroundImage");
            gambarBuku.BackgroundImageLayout = ImageLayout.Stretch;
            gambarBuku.Location = new Point(60, 12);
            gambarBuku.Name = "gambarBuku";
            gambarBuku.Size = new Size(237, 233);
            gambarBuku.TabIndex = 0;
            gambarBuku.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(12, 259);
            label1.Name = "label1";
            label1.Size = new Size(83, 21);
            label1.TabIndex = 1;
            label1.Text = "Username";
            // 
            // txtUsername
            // 
            txtUsername.BorderStyle = BorderStyle.None;
            txtUsername.Location = new Point(12, 283);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(353, 16);
            txtUsername.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ControlLightLight;
            label2.Location = new Point(12, 310);
            label2.Name = "label2";
            label2.Size = new Size(92, 21);
            label2.TabIndex = 1;
            label2.Text = "Id Member";
            // 
            // txtIdMember
            // 
            txtIdMember.BorderStyle = BorderStyle.None;
            txtIdMember.Enabled = false;
            txtIdMember.Location = new Point(12, 334);
            txtIdMember.Name = "txtIdMember";
            txtIdMember.Size = new Size(353, 16);
            txtIdMember.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ControlLightLight;
            label3.Location = new Point(12, 356);
            label3.Name = "label3";
            label3.Size = new Size(70, 21);
            label3.TabIndex = 1;
            label3.Text = "Address";
            // 
            // txtAlamat
            // 
            txtAlamat.BorderStyle = BorderStyle.None;
            txtAlamat.Location = new Point(12, 380);
            txtAlamat.Name = "txtAlamat";
            txtAlamat.Size = new Size(353, 16);
            txtAlamat.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ControlLightLight;
            label4.Location = new Point(12, 407);
            label4.Name = "label4";
            label4.Size = new Size(160, 21);
            label4.TabIndex = 1;
            label4.Text = "Handphone Number";
            // 
            // txtNoHp
            // 
            txtNoHp.BorderStyle = BorderStyle.None;
            txtNoHp.Location = new Point(12, 431);
            txtNoHp.Name = "txtNoHp";
            txtNoHp.Size = new Size(353, 16);
            txtNoHp.TabIndex = 2;
            // 
            // btnEdit
            // 
            btnEdit.BackColor = Color.Lime;
            btnEdit.Cursor = Cursors.Hand;
            btnEdit.FlatStyle = FlatStyle.Popup;
            btnEdit.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEdit.ForeColor = SystemColors.ControlText;
            btnEdit.Location = new Point(12, 515);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(353, 43);
            btnEdit.TabIndex = 3;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = false;
            btnEdit.Click += btnEdit_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ControlLightLight;
            label5.Location = new Point(12, 456);
            label5.Name = "label5";
            label5.Size = new Size(79, 21);
            label5.TabIndex = 1;
            label5.Text = "Password";
            // 
            // txtPassword
            // 
            txtPassword.BorderStyle = BorderStyle.None;
            txtPassword.Location = new Point(12, 480);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(353, 16);
            txtPassword.TabIndex = 2;
            // 
            // EditProfile
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(377, 588);
            Controls.Add(btnEdit);
            Controls.Add(txtPassword);
            Controls.Add(label5);
            Controls.Add(txtNoHp);
            Controls.Add(label4);
            Controls.Add(txtIdMember);
            Controls.Add(txtAlamat);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(txtUsername);
            Controls.Add(label1);
            Controls.Add(gambarBuku);
            DoubleBuffered = true;
            Name = "EditProfile";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EditProfile";
            Load += EditProfile_Load;
            ((System.ComponentModel.ISupportInitialize)gambarBuku).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox gambarBuku;
        private Label label1;
        private TextBox txtUsername;
        private Label label2;
        private TextBox txtIdMember;
        private Label label3;
        private TextBox txtAlamat;
        private Label label4;
        private TextBox txtNoHp;
        private Button btnEdit;
        private Label label5;
        private TextBox txtPassword;
    }
}