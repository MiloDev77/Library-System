﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace SistemPerpustakaanKelompok
{
    public partial class EditProfile : Form
    {
        string usernameMember;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Username
        {
            get => txtUsername.Text;
            set => txtUsername.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Address
        {
            get => txtAlamat.Text;
            set => txtAlamat.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string HandphoneNumber
        {
            get => txtNoHp.Text;
            set => txtNoHp.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Password
        {
            get => txtPassword.Text;
            set => txtPassword.Text = value;
        }
        public EditProfile(string username)
        {
            InitializeComponent();
            usernameMember = username;
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder sb = new StringBuilder();

                foreach (byte b in bytes)
                    sb.Append(b.ToString("x2"));

                return sb.ToString();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query;

                if (!string.IsNullOrWhiteSpace(txtPassword.Text))
                {
                    string hashed = HashPassword(txtPassword.Text);

                    query = @"UPDATE tblmember SET 
                      username=@username,
                      password=@password,
                      alamat=@alamat,
                      no_hp=@nohp
                      WHERE id_member=@id";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@username", Username);
                    cmd.Parameters.AddWithValue("@password", hashed);
                    cmd.Parameters.AddWithValue("@alamat", Address);
                    cmd.Parameters.AddWithValue("@nohp", HandphoneNumber);
                    cmd.Parameters.AddWithValue("@id", txtIdMember.Text);

                    cmd.ExecuteNonQuery();
                }
                else
                {
                    query = @"UPDATE tblmember SET 
                      username=@username,
                      alamat=@alamat,
                      no_hp=@nohp
                      WHERE id_member=@id";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@username", Username);
                    cmd.Parameters.AddWithValue("@alamat", Address);
                    cmd.Parameters.AddWithValue("@nohp", HandphoneNumber);
                    cmd.Parameters.AddWithValue("@id", txtIdMember.Text);

                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Profile Has Been Updated");

                Profile profile = new Profile(usernameMember);
                profile.Show();
                this.Hide();
            }
        }

        private void LoadProfile()
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = "SELECT * FROM tblmember WHERE username = @user";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@user", usernameMember);

                SqlDataReader rd = cmd.ExecuteReader();

                if (rd.Read())
                {
                    txtIdMember.Text = rd["id_member"].ToString();
                    Username = rd["username"].ToString();
                    Address = rd["alamat"].ToString();
                    HandphoneNumber = rd["no_hp"].ToString();
                    Password = rd["password"].ToString();
                }
            }
        }

        private void EditProfile_Load(object sender, EventArgs e)
        {
            LoadProfile();
        }
    }
}
