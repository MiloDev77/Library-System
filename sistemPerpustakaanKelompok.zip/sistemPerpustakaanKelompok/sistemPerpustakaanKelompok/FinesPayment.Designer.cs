﻿namespace SistemPerpustakaanKelompok
{
    partial class FinesPayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FinesPayment));
            DummyQRIS = new PictureBox();
            label1 = new Label();
            lblTotalDenda = new Label();
            btnPay = new Button();
            ((System.ComponentModel.ISupportInitialize)DummyQRIS).BeginInit();
            SuspendLayout();
            // 
            // DummyQRIS
            // 
            DummyQRIS.BackColor = Color.Transparent;
            DummyQRIS.BackgroundImage = (Image)resources.GetObject("DummyQRIS.BackgroundImage");
            DummyQRIS.BackgroundImageLayout = ImageLayout.Stretch;
            DummyQRIS.Location = new Point(12, 12);
            DummyQRIS.Name = "DummyQRIS";
            DummyQRIS.Size = new Size(361, 294);
            DummyQRIS.TabIndex = 0;
            DummyQRIS.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold);
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(12, 309);
            label1.Name = "label1";
            label1.Size = new Size(107, 25);
            label1.TabIndex = 1;
            label1.Text = "Total Fines:";
            // 
            // lblTotalDenda
            // 
            lblTotalDenda.BackColor = Color.Transparent;
            lblTotalDenda.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTotalDenda.ForeColor = SystemColors.ControlLightLight;
            lblTotalDenda.Location = new Point(12, 335);
            lblTotalDenda.Name = "lblTotalDenda";
            lblTotalDenda.Size = new Size(361, 38);
            lblTotalDenda.TabIndex = 1;
            lblTotalDenda.Text = "N/A";
            // 
            // btnPay
            // 
            btnPay.BackColor = Color.Lime;
            btnPay.FlatStyle = FlatStyle.Popup;
            btnPay.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPay.Location = new Point(12, 376);
            btnPay.Name = "btnPay";
            btnPay.Size = new Size(361, 49);
            btnPay.TabIndex = 2;
            btnPay.Text = "Finish Payment";
            btnPay.UseVisualStyleBackColor = false;
            btnPay.Click += btnPay_Click;
            // 
            // FinesPayment
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(385, 450);
            Controls.Add(btnPay);
            Controls.Add(lblTotalDenda);
            Controls.Add(label1);
            Controls.Add(DummyQRIS);
            DoubleBuffered = true;
            Name = "FinesPayment";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FinesPayment";
            ((System.ComponentModel.ISupportInitialize)DummyQRIS).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox DummyQRIS;
        private Label label1;
        private Label lblTotalDenda;
        private Button btnPay;
    }
}