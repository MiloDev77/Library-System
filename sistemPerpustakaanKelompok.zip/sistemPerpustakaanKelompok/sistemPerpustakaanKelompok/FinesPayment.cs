﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class FinesPayment : Form
    {
        string usernameMember;
        public int IdPeminjaman;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TotalFines
        {
            get => lblTotalDenda.Text;
            set => lblTotalDenda.Text = value;
        }

        public FinesPayment(string username)
        {
            InitializeComponent();
            usernameMember = username;
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string insert = @"INSERT INTO tbldenda
                        (id_peminjaman, jumlah_hari_terlambat, jumlah_denda)
                        VALUES (@id, @hari, @denda)";

                int telat = 0;
                int denda = 0;

                string get = "SELECT tanggal_kembali FROM tblpeminjaman WHERE id_peminjaman=@id";
                SqlCommand cmdGet = new SqlCommand(get, conn);
                cmdGet.Parameters.AddWithValue("@id", IdPeminjaman);

                DateTime tglKembali = Convert.ToDateTime(cmdGet.ExecuteScalar());

                telat = (DateTime.Now - tglKembali).Days;
                denda = telat > 0 ? telat * 25000 : 0;

                SqlCommand cmd = new SqlCommand(insert, conn);
                cmd.Parameters.AddWithValue("@id", IdPeminjaman);
                cmd.Parameters.AddWithValue("@hari", telat);
                cmd.Parameters.AddWithValue("@denda", denda);

                cmd.ExecuteNonQuery();

                string req = @"INSERT INTO tblrequest_kembali
                       (id_peminjaman, status_request)
                       VALUES (@id, 'Pending')";

                SqlCommand cmdReq = new SqlCommand(req, conn);
                cmdReq.Parameters.AddWithValue("@id", IdPeminjaman);
                cmdReq.ExecuteNonQuery();
            }

            MessageBox.Show("Payment Success!");
            this.Close();
        }
    }
}
