﻿namespace SistemPerpustakaanKelompok
{
    partial class History
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(History));
            lblLogout = new Label();
            lblProfile = new Label();
            lblHistory = new Label();
            lblMyBook = new Label();
            lblBookCatalogue = new Label();
            lblPageDashboard = new Label();
            lblNamaMember = new Label();
            layoutPanelHistory = new FlowLayoutPanel();
            SuspendLayout();
            // 
            // lblLogout
            // 
            lblLogout.AutoSize = true;
            lblLogout.BackColor = Color.Transparent;
            lblLogout.Cursor = Cursors.Hand;
            lblLogout.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblLogout.ForeColor = SystemColors.ControlLightLight;
            lblLogout.Location = new Point(63, 553);
            lblLogout.Name = "lblLogout";
            lblLogout.Size = new Size(43, 13);
            lblLogout.TabIndex = 54;
            lblLogout.Text = "Logout";
            lblLogout.Click += lblLogout_Click;
            // 
            // lblProfile
            // 
            lblProfile.AutoSize = true;
            lblProfile.BackColor = Color.Transparent;
            lblProfile.Cursor = Cursors.Hand;
            lblProfile.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblProfile.ForeColor = SystemColors.ControlLightLight;
            lblProfile.Location = new Point(63, 312);
            lblProfile.Name = "lblProfile";
            lblProfile.Size = new Size(40, 13);
            lblProfile.TabIndex = 53;
            lblProfile.Text = "Profile";
            lblProfile.Click += lblProfile_Click;
            // 
            // lblHistory
            // 
            lblHistory.AutoSize = true;
            lblHistory.BackColor = Color.Transparent;
            lblHistory.Cursor = Cursors.Hand;
            lblHistory.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblHistory.ForeColor = SystemColors.ControlLightLight;
            lblHistory.Location = new Point(63, 264);
            lblHistory.Name = "lblHistory";
            lblHistory.Size = new Size(44, 13);
            lblHistory.TabIndex = 52;
            lblHistory.Text = "History";
            lblHistory.Click += lblHistory_Click;
            // 
            // lblMyBook
            // 
            lblMyBook.AutoSize = true;
            lblMyBook.BackColor = Color.Transparent;
            lblMyBook.Cursor = Cursors.Hand;
            lblMyBook.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblMyBook.ForeColor = SystemColors.ControlLightLight;
            lblMyBook.Location = new Point(63, 218);
            lblMyBook.Name = "lblMyBook";
            lblMyBook.Size = new Size(53, 13);
            lblMyBook.TabIndex = 51;
            lblMyBook.Text = "My Book";
            lblMyBook.Click += lblMyBook_Click;
            // 
            // lblBookCatalogue
            // 
            lblBookCatalogue.AutoSize = true;
            lblBookCatalogue.BackColor = Color.Transparent;
            lblBookCatalogue.Cursor = Cursors.Hand;
            lblBookCatalogue.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblBookCatalogue.ForeColor = SystemColors.ControlLightLight;
            lblBookCatalogue.Location = new Point(63, 172);
            lblBookCatalogue.Name = "lblBookCatalogue";
            lblBookCatalogue.Size = new Size(89, 13);
            lblBookCatalogue.TabIndex = 50;
            lblBookCatalogue.Text = "Book Catalogue";
            lblBookCatalogue.Click += lblBookCatalogue_Click;
            // 
            // lblPageDashboard
            // 
            lblPageDashboard.AutoSize = true;
            lblPageDashboard.BackColor = Color.Transparent;
            lblPageDashboard.Cursor = Cursors.Hand;
            lblPageDashboard.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblPageDashboard.ForeColor = SystemColors.ControlLightLight;
            lblPageDashboard.Location = new Point(63, 125);
            lblPageDashboard.Name = "lblPageDashboard";
            lblPageDashboard.Size = new Size(63, 13);
            lblPageDashboard.TabIndex = 49;
            lblPageDashboard.Text = "Dashboard";
            lblPageDashboard.Click += lblPageDashboard_Click;
            // 
            // lblNamaMember
            // 
            lblNamaMember.BackColor = Color.Transparent;
            lblNamaMember.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNamaMember.ForeColor = SystemColors.ControlLightLight;
            lblNamaMember.Location = new Point(1048, 25);
            lblNamaMember.Name = "lblNamaMember";
            lblNamaMember.Size = new Size(131, 20);
            lblNamaMember.TabIndex = 55;
            lblNamaMember.Text = "N/A";
            lblNamaMember.TextAlign = ContentAlignment.MiddleRight;
            // 
            // layoutPanelHistory
            // 
            layoutPanelHistory.BackColor = Color.Transparent;
            layoutPanelHistory.Location = new Point(245, 137);
            layoutPanelHistory.Name = "layoutPanelHistory";
            layoutPanelHistory.Size = new Size(934, 429);
            layoutPanelHistory.TabIndex = 56;
            // 
            // History
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1216, 588);
            Controls.Add(layoutPanelHistory);
            Controls.Add(lblNamaMember);
            Controls.Add(lblLogout);
            Controls.Add(lblProfile);
            Controls.Add(lblHistory);
            Controls.Add(lblMyBook);
            Controls.Add(lblBookCatalogue);
            Controls.Add(lblPageDashboard);
            DoubleBuffered = true;
            Name = "History";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "History";
            Load += History_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblLogout;
        private Label lblProfile;
        private Label lblHistory;
        private Label lblMyBook;
        private Label lblBookCatalogue;
        private Label lblPageDashboard;
        private Label lblNamaMember;
        private FlowLayoutPanel layoutPanelHistory;
    }
}