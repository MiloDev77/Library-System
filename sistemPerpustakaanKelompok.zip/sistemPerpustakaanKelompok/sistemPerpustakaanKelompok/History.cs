﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class History : Form
    {
        string usernameMember;
        public History(string username)
        {
            InitializeComponent();

            usernameMember = username;
        }

        private void History_Load(object sender, EventArgs e)
        {
            lblNamaMember.Text = usernameMember;
            layoutPanelHistory.AutoScroll = true;

            LoadHistory();
        }

        private void lblPageDashboard_Click(object sender, EventArgs e)
        {
            DashboardMember dashboardMember = new DashboardMember(usernameMember);
            dashboardMember.Show();
            this.Hide();
        }

        private void lblBookCatalogue_Click(object sender, EventArgs e)
        {
            BookCatalogue bookCatalogue = new BookCatalogue(usernameMember);
            bookCatalogue.Show();
            this.Hide();
        }

        private void lblMyBook_Click(object sender, EventArgs e)
        {
            MyBook myBook = new MyBook(usernameMember);
            myBook.Show();
            this.Hide();
        }

        private void lblHistory_Click(object sender, EventArgs e)
        {
            History history = new History(usernameMember);
            history.Show();
            this.Hide();
        }

        private void lblProfile_Click(object sender, EventArgs e)
        {
            Profile profile = new Profile(usernameMember);
            profile.Show();
            this.Hide();
        }

        private void lblLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void LoadHistory()
        {
            layoutPanelHistory.Controls.Clear();

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"SELECT 
                                p.id_peminjaman,
                                p.tanggal_pinjam,
                                p.tanggal_kembali,
                                p.tanggal_aktual_kembali,
                                p.status_peminjaman,
                                b.id_buku,
                                b.judul,
                                b.tahun_terbit,
                                b.stok,
                                b.gambar,
                                b.deskripsi_buku,              
                                pb.nama_penerbit,
                                pen.nama_penulis
                                FROM tblpeminjaman p
                                JOIN tblbuku b ON p.id_buku = b.id_buku
                                JOIN tblmember m ON p.id_member = m.id_member
                                JOIN tblpenulis pen ON b.penulis_id = pen.id_penulis
                                JOIN tblpenerbit pb ON b.penerbit_id = pb.id_penerbit
                                WHERE m.username = @user
                                ORDER BY p.id_peminjaman DESC";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@user", usernameMember);

                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    int idBuku = Convert.ToInt32(rd["id_buku"]);
                    string judul = rd["judul"].ToString();
                    string penulis = rd["nama_penulis"].ToString();
                    string penerbit = rd["nama_penerbit"].ToString();
                    string tahun = rd["tahun_terbit"].ToString();
                    string deskripsi = rd["deskripsi_buku"].ToString();
                    string stok = rd["stok"].ToString();

                    templateHistoryBook item = new templateHistoryBook();

                    item.BookName = judul;
                    item.Writer = penulis;
                    item.PublishYear = Convert.ToInt32(tahun);

                    Image img = null;
                    if (rd["gambar"] != DBNull.Value)
                    {
                        byte[] imgBytes = (byte[])rd["gambar"];
                        using (MemoryStream ms = new MemoryStream(imgBytes))
                        {
                            img = Image.FromStream(ms);
                            item.BookImage = img;
                        }
                    }

                    item.ReserveDate = rd["tanggal_pinjam"] != DBNull.Value
                        ? Convert.ToDateTime(rd["tanggal_pinjam"]).ToString("dd-MM-yyyy")
                        : "-";

                    string status = rd["status_peminjaman"].ToString().ToLower();

                    if (status == "returned")
                    {
                        item.ReturnDate = rd["tanggal_aktual_kembali"] != DBNull.Value
                            ? Convert.ToDateTime(rd["tanggal_aktual_kembali"]).ToString("dd-MM-yyyy")
                            : "Has Returned";
                    }
                    else
                    {
                        item.ReturnDate = rd["tanggal_kembali"] != DBNull.Value
                            ? Convert.ToDateTime(rd["tanggal_kembali"]).ToString("dd-MM-yyyy")
                            : "-";
                    }

                    item.BtnDetail.Click += (s, e) =>
                    {
                        BookDetail detail = new BookDetail();

                        detail.BookName = judul;
                        detail.Writer = penulis;
                        detail.PublisherName = penerbit;
                        detail.PublishYear = tahun;
                        detail.Description = deskripsi;
                        detail.Stock = stok;

                        if (img != null)
                            detail.BookImage = img;

                        detail.SetData(idBuku, usernameMember);

                        detail.Show();
                    };

                    layoutPanelHistory.Controls.Add(item);
                }
            }
        }
     }
}
