﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemPerpustakaanKelompok
{
    public partial class Inbox : Form
    {
        string usernameMember;
        public Inbox(string username)
        {
            InitializeComponent();
            usernameMember = username;
        }

        private void LoadInbox()
        {
            layoutPanelInbox.Controls.Clear();

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"SELECT r.id_request, r.keterangan
                                FROM tblrequest_pinjam r
                                JOIN tblmember m ON r.id_member = m.id_member
                                WHERE m.username=@u 
                                AND r.status_request='Rejected'
                                AND r.keterangan IS NOT NULL
                                AND r.is_read = 0
                                ORDER BY r.id_request DESC
                                ";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@u", usernameMember);

                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    templateInbox item = new templateInbox();
                    item.RejectionReason = rd["keterangan"].ToString();

                    string idReq = rd["id_request"].ToString();
                    item.ReserveNumber = $"Reserve Number {idReq} Has Been Rejected!";

                    layoutPanelInbox.Controls.Add(item);
                }
            }
        }

        private void Inbox_Load(object sender, EventArgs e)
        {
            LoadInbox();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            DashboardMember dashboardMember = new DashboardMember(usernameMember);
            dashboardMember.Show();
            this.Hide();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"UPDATE tblrequest_pinjam
                                SET is_read = 1
                                WHERE id_member = (SELECT id_member FROM tblmember WHERE username=@u)
                                AND status_request='Rejected'
                                ";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@u", usernameMember);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Inbox cleared!");
            LoadInbox();
        }
    }
}