﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public static class Koneksi
    {
        public static string ConnectionString =
            "server=localhost\\SQLEXPRESS;Initial Catalog=perpustakaan;Trusted_Connection=True;TrustServerCertificate=True";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }
    }
}
