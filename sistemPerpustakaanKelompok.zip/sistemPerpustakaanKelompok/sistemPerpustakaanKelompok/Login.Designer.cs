﻿namespace SistemPerpustakaanKelompok
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            txtUsername = new TextBox();
            txtPassword = new TextBox();
            lblLogin = new Label();
            chkLihatPassword = new CheckBox();
            lblRegister = new Label();
            SuspendLayout();
            // 
            // txtUsername
            // 
            txtUsername.BorderStyle = BorderStyle.None;
            txtUsername.Location = new Point(70, 278);
            txtUsername.Margin = new Padding(3, 2, 3, 2);
            txtUsername.Multiline = true;
            txtUsername.Name = "txtUsername";
            txtUsername.PlaceholderText = "Username";
            txtUsername.Size = new Size(346, 21);
            txtUsername.TabIndex = 0;
            // 
            // txtPassword
            // 
            txtPassword.BorderStyle = BorderStyle.None;
            txtPassword.Location = new Point(70, 328);
            txtPassword.Margin = new Padding(3, 2, 3, 2);
            txtPassword.Multiline = true;
            txtPassword.Name = "txtPassword";
            txtPassword.PlaceholderText = "Password";
            txtPassword.Size = new Size(346, 20);
            txtPassword.TabIndex = 1;
            // 
            // lblLogin
            // 
            lblLogin.AutoSize = true;
            lblLogin.BackColor = Color.White;
            lblLogin.Cursor = Cursors.Hand;
            lblLogin.Font = new Font("Cambria", 18F, FontStyle.Bold);
            lblLogin.Location = new Point(207, 394);
            lblLogin.Name = "lblLogin";
            lblLogin.Size = new Size(73, 28);
            lblLogin.TabIndex = 2;
            lblLogin.Text = "Login";
            lblLogin.Click += lblLogin_Click;
            // 
            // chkLihatPassword
            // 
            chkLihatPassword.AutoSize = true;
            chkLihatPassword.BackColor = Color.Transparent;
            chkLihatPassword.Cursor = Cursors.Hand;
            chkLihatPassword.Location = new Point(443, 332);
            chkLihatPassword.Margin = new Padding(3, 2, 3, 2);
            chkLihatPassword.Name = "chkLihatPassword";
            chkLihatPassword.Size = new Size(15, 14);
            chkLihatPassword.TabIndex = 3;
            chkLihatPassword.UseVisualStyleBackColor = false;
            chkLihatPassword.CheckedChanged += chkLihatPassword_CheckedChanged;
            // 
            // lblRegister
            // 
            lblRegister.AutoSize = true;
            lblRegister.BackColor = Color.FromArgb(64, 64, 64);
            lblRegister.Cursor = Cursors.Hand;
            lblRegister.Font = new Font("Cambria", 12F, FontStyle.Bold);
            lblRegister.ForeColor = SystemColors.ActiveCaption;
            lblRegister.Location = new Point(282, 443);
            lblRegister.Name = "lblRegister";
            lblRegister.Size = new Size(69, 19);
            lblRegister.TabIndex = 10;
            lblRegister.Text = "Register";
            lblRegister.Click += lblRegister_Click;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1216, 588);
            Controls.Add(lblRegister);
            Controls.Add(chkLihatPassword);
            Controls.Add(lblLogin);
            Controls.Add(txtPassword);
            Controls.Add(txtUsername);
            DoubleBuffered = true;
            Margin = new Padding(3, 2, 3, 2);
            Name = "Login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtUsername;
        private TextBox txtPassword;
        private Label lblLogin;
        private CheckBox chkLihatPassword;
        private Label lblRegister;
    }
}