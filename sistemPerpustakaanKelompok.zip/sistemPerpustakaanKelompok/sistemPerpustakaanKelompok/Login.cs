﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();

            txtPassword.PasswordChar = '●';
        }
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();

                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }

                return builder.ToString();
            }
        }

        private void lblLogin_Click(object sender, EventArgs e)
        {
            string HashedPassword = HashPassword(txtPassword.Text);

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string queryAdmin = "SELECT * FROM tbladmin WHERE username=@username AND password=@password";
                SqlCommand cmdAdmin = new SqlCommand(queryAdmin, conn);
                cmdAdmin.Parameters.AddWithValue("@username", txtUsername.Text);
                cmdAdmin.Parameters.AddWithValue("@password", txtPassword.Text);

                SqlDataReader rdAdmin = cmdAdmin.ExecuteReader();

                if (rdAdmin.HasRows)
                {
                    rdAdmin.Close();

                    DashboardAdmin admin = new DashboardAdmin(txtUsername.Text);
                    admin.Show();
                    this.Hide();
                    return;
                }

                rdAdmin.Close();

                string queryMember = "SELECT * FROM tblmember WHERE username=@username AND password=@password";
                SqlCommand cmdMember = new SqlCommand(queryMember, conn);
                cmdMember.Parameters.AddWithValue("@username", txtUsername.Text);
                cmdMember.Parameters.AddWithValue("@password", HashedPassword);

                SqlDataReader rdMember = cmdMember.ExecuteReader();

                if (rdMember.Read())
                {
                    bool isActive = Convert.ToBoolean(rdMember["is_active"]);

                    if (!isActive)
                    {
                        rdMember.Close();
                        MessageBox.Show("Your account is not active. Please contact the administrator.", "Account Inactive", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    string username = rdMember["username"].ToString();

                    rdMember.Close();

                    DashboardMember dashboardMember= new DashboardMember(txtUsername.Text);
                    dashboardMember.Show();
                    this.Hide();
                }
                else
                {
                    rdMember.Close();
                    MessageBox.Show("Make Sure To Check Your Username And Password Again!", "Login invalid!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void lblRegister_Click(object sender, EventArgs e)
        {
            Register register = new Register();
            register.Show();
            this.Hide();
        }

        private void chkLihatPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chkLihatPassword.Checked)
            {
                txtPassword.PasswordChar = '\0';
            }
            else
            {
                txtPassword.PasswordChar = '●';
            }
        }
    }
}
