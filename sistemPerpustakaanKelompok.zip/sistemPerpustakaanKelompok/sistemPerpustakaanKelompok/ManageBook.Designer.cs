﻿namespace SistemPerpustakaanKelompok
{
    partial class ManageBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManageBook));
            lblLogout = new Label();
            lblMonthReport = new Label();
            lblBooked = new Label();
            lblManageMember = new Label();
            lblManageBook = new Label();
            lblPageDashboard = new Label();
            txtSearchTitle = new TextBox();
            lblApply = new Label();
            tambahBuku = new Label();
            layoutPanelManage = new FlowLayoutPanel();
            cbKategori = new ComboBox();
            dtpTahunRelease = new DateTimePicker();
            lblNamaAdmin = new Label();
            SuspendLayout();
            // 
            // lblLogout
            // 
            lblLogout.AutoSize = true;
            lblLogout.BackColor = Color.Transparent;
            lblLogout.Cursor = Cursors.Hand;
            lblLogout.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblLogout.ForeColor = SystemColors.ControlLightLight;
            lblLogout.Location = new Point(66, 554);
            lblLogout.Name = "lblLogout";
            lblLogout.Size = new Size(43, 13);
            lblLogout.TabIndex = 17;
            lblLogout.Text = "Logout";
            lblLogout.Click += lblLogout_Click;
            // 
            // lblMonthReport
            // 
            lblMonthReport.AutoSize = true;
            lblMonthReport.BackColor = Color.Transparent;
            lblMonthReport.Cursor = Cursors.Hand;
            lblMonthReport.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblMonthReport.ForeColor = SystemColors.ControlLightLight;
            lblMonthReport.Location = new Point(66, 303);
            lblMonthReport.Name = "lblMonthReport";
            lblMonthReport.Size = new Size(87, 13);
            lblMonthReport.TabIndex = 16;
            lblMonthReport.Text = "Monthly Report";
            lblMonthReport.Click += lblMonthReport_Click;
            // 
            // lblBooked
            // 
            lblBooked.AutoSize = true;
            lblBooked.BackColor = Color.Transparent;
            lblBooked.Cursor = Cursors.Hand;
            lblBooked.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblBooked.ForeColor = SystemColors.ControlLightLight;
            lblBooked.Location = new Point(66, 256);
            lblBooked.Name = "lblBooked";
            lblBooked.Size = new Size(47, 13);
            lblBooked.TabIndex = 15;
            lblBooked.Text = "Booked";
            lblBooked.Click += lblBooked_Click;
            // 
            // lblManageMember
            // 
            lblManageMember.AutoSize = true;
            lblManageMember.BackColor = Color.Transparent;
            lblManageMember.Cursor = Cursors.Hand;
            lblManageMember.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblManageMember.ForeColor = SystemColors.ControlLightLight;
            lblManageMember.Location = new Point(66, 209);
            lblManageMember.Name = "lblManageMember";
            lblManageMember.Size = new Size(94, 13);
            lblManageMember.TabIndex = 14;
            lblManageMember.Text = "Manage Member";
            lblManageMember.Click += lblManageMember_Click;
            // 
            // lblManageBook
            // 
            lblManageBook.AutoSize = true;
            lblManageBook.BackColor = Color.Transparent;
            lblManageBook.Cursor = Cursors.Hand;
            lblManageBook.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblManageBook.ForeColor = SystemColors.ControlLightLight;
            lblManageBook.Location = new Point(66, 162);
            lblManageBook.Name = "lblManageBook";
            lblManageBook.Size = new Size(78, 13);
            lblManageBook.TabIndex = 13;
            lblManageBook.Text = "Manage Book";
            lblManageBook.Click += lblManageBook_Click;
            // 
            // lblPageDashboard
            // 
            lblPageDashboard.AutoSize = true;
            lblPageDashboard.BackColor = Color.Transparent;
            lblPageDashboard.Cursor = Cursors.Hand;
            lblPageDashboard.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblPageDashboard.ForeColor = SystemColors.ControlLightLight;
            lblPageDashboard.Location = new Point(66, 120);
            lblPageDashboard.Name = "lblPageDashboard";
            lblPageDashboard.Size = new Size(63, 13);
            lblPageDashboard.TabIndex = 12;
            lblPageDashboard.Text = "Dashboard";
            lblPageDashboard.Click += lblPageDashboard_Click;
            // 
            // txtSearchTitle
            // 
            txtSearchTitle.BorderStyle = BorderStyle.None;
            txtSearchTitle.Location = new Point(274, 90);
            txtSearchTitle.Name = "txtSearchTitle";
            txtSearchTitle.PlaceholderText = "Search title or writer...";
            txtSearchTitle.Size = new Size(266, 16);
            txtSearchTitle.TabIndex = 19;
            txtSearchTitle.TextChanged += txtSearchTitle_TextChanged;
            // 
            // lblApply
            // 
            lblApply.AutoSize = true;
            lblApply.BackColor = Color.Transparent;
            lblApply.Cursor = Cursors.Hand;
            lblApply.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblApply.ForeColor = SystemColors.ControlLightLight;
            lblApply.Location = new Point(1107, 94);
            lblApply.Name = "lblApply";
            lblApply.Size = new Size(43, 17);
            lblApply.TabIndex = 20;
            lblApply.Text = "Apply";
            lblApply.Click += lblApply_Click;
            // 
            // tambahBuku
            // 
            tambahBuku.AutoSize = true;
            tambahBuku.BackColor = Color.Transparent;
            tambahBuku.Cursor = Cursors.Hand;
            tambahBuku.Font = new Font("Segoe UI", 15F);
            tambahBuku.ForeColor = SystemColors.ControlLightLight;
            tambahBuku.Location = new Point(1139, 517);
            tambahBuku.Name = "tambahBuku";
            tambahBuku.Size = new Size(39, 28);
            tambahBuku.TabIndex = 21;
            tambahBuku.Text = "➕";
            tambahBuku.Click += tambahBuku_Click;
            // 
            // layoutPanelManage
            // 
            layoutPanelManage.BackColor = Color.Transparent;
            layoutPanelManage.Location = new Point(248, 125);
            layoutPanelManage.Name = "layoutPanelManage";
            layoutPanelManage.Size = new Size(909, 378);
            layoutPanelManage.TabIndex = 22;
            // 
            // cbKategori
            // 
            cbKategori.FormattingEnabled = true;
            cbKategori.Location = new Point(732, 93);
            cbKategori.Name = "cbKategori";
            cbKategori.Size = new Size(132, 23);
            cbKategori.TabIndex = 23;
            // 
            // dtpTahunRelease
            // 
            dtpTahunRelease.Location = new Point(910, 93);
            dtpTahunRelease.Name = "dtpTahunRelease";
            dtpTahunRelease.Size = new Size(130, 23);
            dtpTahunRelease.TabIndex = 24;
            // 
            // lblNamaAdmin
            // 
            lblNamaAdmin.BackColor = Color.Transparent;
            lblNamaAdmin.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNamaAdmin.ForeColor = SystemColors.ControlLightLight;
            lblNamaAdmin.Location = new Point(1048, 25);
            lblNamaAdmin.Name = "lblNamaAdmin";
            lblNamaAdmin.Size = new Size(131, 20);
            lblNamaAdmin.TabIndex = 25;
            lblNamaAdmin.Text = "N/A";
            lblNamaAdmin.TextAlign = ContentAlignment.MiddleRight;
            // 
            // ManageBook
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1216, 588);
            Controls.Add(lblNamaAdmin);
            Controls.Add(dtpTahunRelease);
            Controls.Add(cbKategori);
            Controls.Add(layoutPanelManage);
            Controls.Add(tambahBuku);
            Controls.Add(lblApply);
            Controls.Add(txtSearchTitle);
            Controls.Add(lblLogout);
            Controls.Add(lblMonthReport);
            Controls.Add(lblBooked);
            Controls.Add(lblManageMember);
            Controls.Add(lblManageBook);
            Controls.Add(lblPageDashboard);
            DoubleBuffered = true;
            Name = "ManageBook";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ManageBook";
            Load += ManageBook_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblLogout;
        private Label lblMonthReport;
        private Label lblBooked;
        private Label lblManageMember;
        private Label lblManageBook;
        private Label lblPageDashboard;
        private TextBox txtSearchTitle;
        private Label lblApply;
        private Label tambahBuku;
        private FlowLayoutPanel layoutPanelManage;
        private ComboBox cbKategori;
        private DateTimePicker dtpTahunRelease;
        private Label lblNamaAdmin;
    }
}