﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.IO;

namespace SistemPerpustakaanKelompok
{
    public partial class ManageBook : Form
    {
        string usernameAdmin;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string SearchBook
        {
            get => txtSearchTitle.Text;
            set => txtSearchTitle.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Category
        {
            get => cbKategori.Text;
            set => cbKategori.Text = value;
        }
        public ManageBook(string username)
        {
            InitializeComponent();
            usernameAdmin = username;
        }

        private void lblPageDashboard_Click(object sender, EventArgs e)
        {
            DashboardAdmin dashboard = new DashboardAdmin(usernameAdmin);
            dashboard.Show();
            this.Hide();
        }

        private void lblManageBook_Click(object sender, EventArgs e)
        {
            ManageBook mb = new ManageBook(usernameAdmin);
            mb.Show();
            this.Hide();
        }

        private void lblManageMember_Click(object sender, EventArgs e)
        {
            ManageMember mbr = new ManageMember(usernameAdmin);
            mbr.Show();
            this.Hide();
        }

        private void lblBooked_Click(object sender, EventArgs e)
        {
            Booked pinjam = new Booked(usernameAdmin);
            pinjam.Show();
            this.Hide();
        }

        private void lblMonthReport_Click(object sender, EventArgs e)
        {
            MonthlyReport report = new MonthlyReport(usernameAdmin);
            report.Show();
            this.Hide();
        }

        private void lblLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }


        private void lblNamaAdmin_Click(object sender, EventArgs e)
        {

        }
        private void ManageBook_Load(object sender, EventArgs e)
        {
            lblNamaAdmin.Text = usernameAdmin;
            dtpTahunRelease.Format = DateTimePickerFormat.Custom;
            dtpTahunRelease.CustomFormat = "yyyy";
            dtpTahunRelease.ShowUpDown = true;

            LoadData();
            LoadKategori();
        }

        public void LoadData(string search = "", string kategori = "", string tahun = "")
        {
            layoutPanelManage.Controls.Clear();

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"SELECT 
                                b.id_buku,
                                b.judul,
                                j.jenis,
                                p.nama_penulis,
                                pb.nama_penerbit,
                                b.tahun_terbit,
                                b.stok,
                                b.deskripsi_buku,
                                b.gambar
                                FROM tblbuku b
                                JOIN tbljenisbuku j ON b.jenisbuku_id = j.id_jenis
                                JOIN tblpenulis p ON b.penulis_id = p.id_penulis
                                JOIN tblpenerbit pb ON b.penerbit_id = pb.id_penerbit
                                WHERE 1=1";

                if (!string.IsNullOrEmpty(search))
                    query += " AND b.judul LIKE @search";

                if (!string.IsNullOrEmpty(kategori))
                    query += " AND j.jenis = @kategori";

                if (!string.IsNullOrEmpty(tahun))
                    query += " AND b.tahun_terbit = @tahun";

                SqlCommand cmd = new SqlCommand(query, conn);

                if (!string.IsNullOrEmpty(search))
                    cmd.Parameters.AddWithValue("@search", "%" + search + "%");

                if (!string.IsNullOrEmpty(kategori))
                    cmd.Parameters.AddWithValue("@kategori", kategori);

                if (!string.IsNullOrEmpty(tahun))
                    cmd.Parameters.AddWithValue("@tahun", tahun);

                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    templateManageBook item = new templateManageBook();

                    item.JudulBuku= rd["judul"].ToString();
                    item.JenisBuku = rd["jenis"].ToString();
                    item.Penulis = rd["nama_penulis"].ToString();
                    item.Penerbit = rd["nama_penerbit"].ToString();
                    item.TahunTerbit = rd["tahun_terbit"].ToString();
                    item.Deskripsi = rd["deskripsi_buku"].ToString();
                    item.Stok = rd["stok"].ToString();

                    item.idBuku = Convert.ToInt32(rd["id_buku"]);
                    //item.usernameAdmin = usernameAdmin;

                    if (rd["gambar"] != DBNull.Value)
                    {
                        byte[] imgBytes = (byte[])rd["gambar"];
                        using (MemoryStream ms = new MemoryStream(imgBytes))
                        {
                            item.GambarBuku = Image.FromStream(ms);
                        }
                    }

                    item.HapusClicked += (s, e) =>
                    {
                        DialogResult result = MessageBox.Show(
                            "Are you sure you want to delete this book?",
                            "Confirmation",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Warning);

                        if (result == DialogResult.Yes)
                        {
                            HapusData(item.idBuku);
                            LoadData();
                        }
                    };

                    layoutPanelManage.Controls.Add(item);
                }
            }
        }

        private void HapusData(int id)
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string getPeminjaman = "SELECT id_peminjaman FROM tblpeminjaman WHERE id_buku=@id";
                SqlCommand cmdGet = new SqlCommand(getPeminjaman, conn);
                cmdGet.Parameters.AddWithValue("@id", id);

                List<int> listPeminjaman = new List<int>();

                SqlDataReader rd = cmdGet.ExecuteReader();
                while (rd.Read())
                {
                    listPeminjaman.Add(Convert.ToInt32(rd["id_peminjaman"]));
                }
                rd.Close();

                foreach (int idPinjam in listPeminjaman)
                {
                    string delDenda = "DELETE FROM tbldenda WHERE id_peminjaman=@id";
                    SqlCommand cmdDenda = new SqlCommand(delDenda, conn);
                    cmdDenda.Parameters.AddWithValue("@id", idPinjam);
                    cmdDenda.ExecuteNonQuery();

                    string delKembali = "DELETE FROM tblrequest_kembali WHERE id_peminjaman=@id";
                    SqlCommand cmdKembali = new SqlCommand(delKembali, conn);
                    cmdKembali.Parameters.AddWithValue("@id", idPinjam);
                    cmdKembali.ExecuteNonQuery();
                }

                string delPeminjaman = "DELETE FROM tblpeminjaman WHERE id_buku=@id";
                SqlCommand cmdPinjam = new SqlCommand(delPeminjaman, conn);
                cmdPinjam.Parameters.AddWithValue("@id", id);
                cmdPinjam.ExecuteNonQuery();

                string delReq = "DELETE FROM tblrequest_pinjam WHERE id_buku=@id";
                SqlCommand cmdReq = new SqlCommand(delReq, conn);
                cmdReq.Parameters.AddWithValue("@id", id);
                cmdReq.ExecuteNonQuery();

                string delBuku = "DELETE FROM tblbuku WHERE id_buku=@id";
                SqlCommand cmdBuku = new SqlCommand(delBuku, conn);
                cmdBuku.Parameters.AddWithValue("@id", id);
                cmdBuku.ExecuteNonQuery();
            }

            MessageBox.Show("Book Successfully Deleted!");
        }

        private void txtSearchTitle_TextChanged(object sender, EventArgs e)
        {
            LoadData(txtSearchTitle.Text);
        }

        private void lblApply_Click(object sender, EventArgs e)
        {
            string tahun = dtpTahunRelease.Checked ? dtpTahunRelease.Value.Year.ToString() : "";

            LoadData(SearchBook, Category, tahun);
        }

        private void LoadKategori()
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = "SELECT jenis FROM tbljenisbuku";
                SqlCommand cmd = new SqlCommand(query, conn);

                SqlDataReader rd = cmd.ExecuteReader();

                cbKategori.Items.Clear();

                while (rd.Read())
                {
                    cbKategori.Items.Add(rd["jenis"].ToString());
                }
            }
        }

        private void tambahBuku_Click(object sender, EventArgs e)
        {
            TambahBuku formtambah = new TambahBuku(usernameAdmin);
            formtambah.Show();
            this.Hide();
        }
    }
}