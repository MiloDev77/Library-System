﻿namespace SistemPerpustakaanKelompok
{
    partial class ManageMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManageMember));
            lblLogout = new Label();
            lblMonthReport = new Label();
            lblBooked = new Label();
            lblManageMember = new Label();
            lblManageBook = new Label();
            lblPageDashboard = new Label();
            txtCariMembership = new TextBox();
            lblTotalMember = new Label();
            lblMemberAktif = new Label();
            lblMemberNonAktif = new Label();
            tambahMember = new Label();
            layoutPanelManageMember = new FlowLayoutPanel();
            lblNamaAdmin = new Label();
            SuspendLayout();
            // 
            // lblLogout
            // 
            lblLogout.AutoSize = true;
            lblLogout.BackColor = Color.Transparent;
            lblLogout.Cursor = Cursors.Hand;
            lblLogout.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblLogout.ForeColor = SystemColors.ControlLightLight;
            lblLogout.Location = new Point(63, 553);
            lblLogout.Name = "lblLogout";
            lblLogout.Size = new Size(43, 13);
            lblLogout.TabIndex = 24;
            lblLogout.Text = "Logout";
            lblLogout.Click += lblLogout_Click;
            // 
            // lblMonthReport
            // 
            lblMonthReport.AutoSize = true;
            lblMonthReport.BackColor = Color.Transparent;
            lblMonthReport.Cursor = Cursors.Hand;
            lblMonthReport.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblMonthReport.ForeColor = SystemColors.ControlLightLight;
            lblMonthReport.Location = new Point(63, 302);
            lblMonthReport.Name = "lblMonthReport";
            lblMonthReport.Size = new Size(87, 13);
            lblMonthReport.TabIndex = 23;
            lblMonthReport.Text = "Monthly Report";
            lblMonthReport.Click += lblMonthReport_Click;
            // 
            // lblBooked
            // 
            lblBooked.AutoSize = true;
            lblBooked.BackColor = Color.Transparent;
            lblBooked.Cursor = Cursors.Hand;
            lblBooked.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblBooked.ForeColor = SystemColors.ControlLightLight;
            lblBooked.Location = new Point(63, 255);
            lblBooked.Name = "lblBooked";
            lblBooked.Size = new Size(47, 13);
            lblBooked.TabIndex = 22;
            lblBooked.Text = "Booked";
            lblBooked.Click += lblBooked_Click;
            // 
            // lblManageMember
            // 
            lblManageMember.AutoSize = true;
            lblManageMember.BackColor = Color.Transparent;
            lblManageMember.Cursor = Cursors.Hand;
            lblManageMember.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblManageMember.ForeColor = SystemColors.ControlLightLight;
            lblManageMember.Location = new Point(63, 208);
            lblManageMember.Name = "lblManageMember";
            lblManageMember.Size = new Size(94, 13);
            lblManageMember.TabIndex = 21;
            lblManageMember.Text = "Manage Member";
            lblManageMember.Click += lblManageMember_Click;
            // 
            // lblManageBook
            // 
            lblManageBook.AutoSize = true;
            lblManageBook.BackColor = Color.Transparent;
            lblManageBook.Cursor = Cursors.Hand;
            lblManageBook.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblManageBook.ForeColor = SystemColors.ControlLightLight;
            lblManageBook.Location = new Point(63, 161);
            lblManageBook.Name = "lblManageBook";
            lblManageBook.Size = new Size(78, 13);
            lblManageBook.TabIndex = 20;
            lblManageBook.Text = "Manage Book";
            lblManageBook.Click += lblManageBook_Click;
            // 
            // lblPageDashboard
            // 
            lblPageDashboard.AutoSize = true;
            lblPageDashboard.BackColor = Color.Transparent;
            lblPageDashboard.Cursor = Cursors.Hand;
            lblPageDashboard.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblPageDashboard.ForeColor = SystemColors.ControlLightLight;
            lblPageDashboard.Location = new Point(63, 119);
            lblPageDashboard.Name = "lblPageDashboard";
            lblPageDashboard.Size = new Size(63, 13);
            lblPageDashboard.TabIndex = 19;
            lblPageDashboard.Text = "Dashboard";
            lblPageDashboard.Click += lblPageDashboard_Click;
            // 
            // txtCariMembership
            // 
            txtCariMembership.BorderStyle = BorderStyle.None;
            txtCariMembership.Location = new Point(997, 210);
            txtCariMembership.Name = "txtCariMembership";
            txtCariMembership.PlaceholderText = "Search Member...";
            txtCariMembership.Size = new Size(141, 16);
            txtCariMembership.TabIndex = 26;
            txtCariMembership.TextChanged += txtCariMembership_TextChanged;
            // 
            // lblTotalMember
            // 
            lblTotalMember.AutoSize = true;
            lblTotalMember.BackColor = Color.Transparent;
            lblTotalMember.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblTotalMember.ForeColor = SystemColors.ControlLightLight;
            lblTotalMember.Location = new Point(278, 136);
            lblTotalMember.Name = "lblTotalMember";
            lblTotalMember.Size = new Size(51, 28);
            lblTotalMember.TabIndex = 27;
            lblTotalMember.Text = "N/A";
            // 
            // lblMemberAktif
            // 
            lblMemberAktif.AutoSize = true;
            lblMemberAktif.BackColor = Color.Transparent;
            lblMemberAktif.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblMemberAktif.ForeColor = SystemColors.ControlLightLight;
            lblMemberAktif.Location = new Point(591, 136);
            lblMemberAktif.Name = "lblMemberAktif";
            lblMemberAktif.Size = new Size(51, 28);
            lblMemberAktif.TabIndex = 27;
            lblMemberAktif.Text = "N/A";
            // 
            // lblMemberNonAktif
            // 
            lblMemberNonAktif.AutoSize = true;
            lblMemberNonAktif.BackColor = Color.Transparent;
            lblMemberNonAktif.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblMemberNonAktif.ForeColor = SystemColors.ControlLightLight;
            lblMemberNonAktif.Location = new Point(904, 136);
            lblMemberNonAktif.Name = "lblMemberNonAktif";
            lblMemberNonAktif.Size = new Size(51, 28);
            lblMemberNonAktif.TabIndex = 27;
            lblMemberNonAktif.Text = "N/A";
            // 
            // tambahMember
            // 
            tambahMember.AutoSize = true;
            tambahMember.BackColor = Color.Transparent;
            tambahMember.Cursor = Cursors.Hand;
            tambahMember.Font = new Font("Segoe UI", 10F);
            tambahMember.ForeColor = SystemColors.ControlLightLight;
            tambahMember.Location = new Point(243, 211);
            tambahMember.Name = "tambahMember";
            tambahMember.Size = new Size(28, 19);
            tambahMember.TabIndex = 28;
            tambahMember.Text = "➕";
            tambahMember.Click += tambahMember_Click;
            // 
            // layoutPanelManageMember
            // 
            layoutPanelManageMember.BackColor = Color.Transparent;
            layoutPanelManageMember.Location = new Point(243, 255);
            layoutPanelManageMember.Name = "layoutPanelManageMember";
            layoutPanelManageMember.Size = new Size(917, 311);
            layoutPanelManageMember.TabIndex = 29;
            // 
            // lblNamaAdmin
            // 
            lblNamaAdmin.BackColor = Color.Transparent;
            lblNamaAdmin.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNamaAdmin.ForeColor = SystemColors.ControlLightLight;
            lblNamaAdmin.Location = new Point(1048, 25);
            lblNamaAdmin.Name = "lblNamaAdmin";
            lblNamaAdmin.Size = new Size(131, 20);
            lblNamaAdmin.TabIndex = 30;
            lblNamaAdmin.Text = "N/A";
            lblNamaAdmin.TextAlign = ContentAlignment.MiddleRight;
            // 
            // ManageMember
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1216, 588);
            Controls.Add(lblNamaAdmin);
            Controls.Add(layoutPanelManageMember);
            Controls.Add(tambahMember);
            Controls.Add(lblMemberNonAktif);
            Controls.Add(lblMemberAktif);
            Controls.Add(lblTotalMember);
            Controls.Add(txtCariMembership);
            Controls.Add(lblLogout);
            Controls.Add(lblMonthReport);
            Controls.Add(lblBooked);
            Controls.Add(lblManageMember);
            Controls.Add(lblManageBook);
            Controls.Add(lblPageDashboard);
            DoubleBuffered = true;
            Name = "ManageMember";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ManageMember";
            Load += ManageMember_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblLogout;
        private Label lblMonthReport;
        private Label lblBooked;
        private Label lblManageMember;
        private Label lblManageBook;
        private Label lblPageDashboard;
        private TextBox txtCariMembership;
        private Label lblTotalMember;
        private Label lblMemberAktif;
        private Label lblMemberNonAktif;
        private Label tambahMember;
        private FlowLayoutPanel layoutPanelManageMember;
        private Label lblNamaAdmin;
    }
}