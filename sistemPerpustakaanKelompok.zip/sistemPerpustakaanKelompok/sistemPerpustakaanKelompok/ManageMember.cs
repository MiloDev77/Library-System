﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class ManageMember : Form
    {
        string usernameAdmin;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TotalMember
        {
            get => lblTotalMember.Text;
            set => lblTotalMember.Text = value;
        }   

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TotalActiveMember
        {
            get => lblMemberAktif.Text;
            set => lblMemberAktif.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TotalInactiveMember
        {
            get => lblMemberNonAktif.Text;
            set => lblMemberNonAktif.Text = value;
        }
        public ManageMember(string username)
        {
            InitializeComponent();
            usernameAdmin = username;
        }

        private void lblPageDashboard_Click(object sender, EventArgs e)
        {
            DashboardAdmin dashboard = new DashboardAdmin(usernameAdmin);
            dashboard.Show();
            this.Hide();
        }

        private void lblManageBook_Click(object sender, EventArgs e)
        {
            ManageBook mb = new ManageBook(usernameAdmin);
            mb.Show();
            this.Hide();
        }

        private void lblManageMember_Click(object sender, EventArgs e)
        {
            ManageMember mbr = new ManageMember(usernameAdmin);
            mbr.Show();
            this.Hide();
        }

        private void lblBooked_Click(object sender, EventArgs e)
        {
            Booked pinjam = new Booked(usernameAdmin);
            pinjam.Show();
            this.Hide();
        }

        private void lblMonthReport_Click(object sender, EventArgs e)
        {
            MonthlyReport report = new MonthlyReport(usernameAdmin);
            report.Show();
            this.Hide();
        }

        private void lblLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void ManageMember_Load(object sender, EventArgs e)
        {
            layoutPanelManageMember.AutoScroll = true;
            layoutPanelManageMember.WrapContents = false;
            layoutPanelManageMember.FlowDirection = FlowDirection.TopDown;

            lblNamaAdmin.Text = usernameAdmin;

            LoadMember();
            LoadStats();
        }

        private void LoadMember(string keyword = "")
        {
            layoutPanelManageMember.Controls.Clear();

            templateJudulMBR judul = new templateJudulMBR();
            layoutPanelManageMember.Controls.Add(judul);

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"SELECT * FROM tblmember
                         WHERE username LIKE @search 
                         OR id_card LIKE @search";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@search", "%" + keyword + "%");

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    templateManageMember item = new templateManageMember();

                    item.IdCard = reader["id_card"].ToString();
                    item.Username = reader["username"].ToString();
                    item.Password = "********";
                    item.Alamat = reader["alamat"].ToString();
                    item.NoHp = reader["no_hp"].ToString();
                    item.IsActive = Convert.ToBoolean(reader["is_active"]);

                    item.StatusChanged += (s, e) =>
                    {
                        LoadMember(txtCariMembership.Text);
                        LoadStats();
                    };

                    layoutPanelManageMember.Controls.Add(item);
                }
            }
        }

        private void txtCariMembership_TextChanged(object sender, EventArgs e)
        {
            LoadMember(txtCariMembership.Text);
        }

        private void tambahMember_Click(object sender, EventArgs e)
        {
            TambahMember tambah = new TambahMember();
            tambah.FormClosed += (s, args) => LoadMember();
            tambah.Show();
        }

        private void LoadStats()
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                SqlCommand total = new SqlCommand("SELECT COUNT(*) FROM tblmember", conn);
                TotalMember = total.ExecuteScalar().ToString();

                SqlCommand aktif = new SqlCommand("SELECT COUNT(*) FROM tblmember WHERE is_active=1", conn);
                TotalActiveMember = aktif.ExecuteScalar().ToString();

                SqlCommand nonaktif = new SqlCommand("SELECT COUNT(*) FROM tblmember WHERE is_active=0", conn);
                TotalInactiveMember = nonaktif.ExecuteScalar().ToString();
            }
        }
    }
}