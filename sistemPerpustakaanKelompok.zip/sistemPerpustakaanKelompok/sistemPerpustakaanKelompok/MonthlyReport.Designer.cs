﻿namespace SistemPerpustakaanKelompok
{
    partial class MonthlyReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MonthlyReport));
            lblLogout = new Label();
            lblMonthReport = new Label();
            lblBooked = new Label();
            lblManageMember = new Label();
            lblManageBook = new Label();
            lblPageDashboard = new Label();
            lblTotalMemberBaru = new Label();
            lblTotalPeminjaman = new Label();
            lblTotalPengembalian = new Label();
            lblTotalBukuBaru = new Label();
            lblTotalDenda = new Label();
            lblNamaAdmin = new Label();
            SuspendLayout();
            // 
            // lblLogout
            // 
            lblLogout.AutoSize = true;
            lblLogout.BackColor = Color.Transparent;
            lblLogout.Cursor = Cursors.Hand;
            lblLogout.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblLogout.ForeColor = SystemColors.ControlLightLight;
            lblLogout.Location = new Point(63, 553);
            lblLogout.Name = "lblLogout";
            lblLogout.Size = new Size(43, 13);
            lblLogout.TabIndex = 31;
            lblLogout.Text = "Logout";
            lblLogout.Click += lblLogout_Click;
            // 
            // lblMonthReport
            // 
            lblMonthReport.AutoSize = true;
            lblMonthReport.BackColor = Color.Transparent;
            lblMonthReport.Cursor = Cursors.Hand;
            lblMonthReport.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblMonthReport.ForeColor = SystemColors.ControlLightLight;
            lblMonthReport.Location = new Point(63, 302);
            lblMonthReport.Name = "lblMonthReport";
            lblMonthReport.Size = new Size(87, 13);
            lblMonthReport.TabIndex = 30;
            lblMonthReport.Text = "Monthly Report";
            lblMonthReport.Click += lblMonthReport_Click;
            // 
            // lblBooked
            // 
            lblBooked.AutoSize = true;
            lblBooked.BackColor = Color.Transparent;
            lblBooked.Cursor = Cursors.Hand;
            lblBooked.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblBooked.ForeColor = SystemColors.ControlLightLight;
            lblBooked.Location = new Point(63, 255);
            lblBooked.Name = "lblBooked";
            lblBooked.Size = new Size(47, 13);
            lblBooked.TabIndex = 29;
            lblBooked.Text = "Booked";
            lblBooked.Click += lblBooked_Click;
            // 
            // lblManageMember
            // 
            lblManageMember.AutoSize = true;
            lblManageMember.BackColor = Color.Transparent;
            lblManageMember.Cursor = Cursors.Hand;
            lblManageMember.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblManageMember.ForeColor = SystemColors.ControlLightLight;
            lblManageMember.Location = new Point(63, 208);
            lblManageMember.Name = "lblManageMember";
            lblManageMember.Size = new Size(94, 13);
            lblManageMember.TabIndex = 28;
            lblManageMember.Text = "Manage Member";
            lblManageMember.Click += lblManageMember_Click;
            // 
            // lblManageBook
            // 
            lblManageBook.AutoSize = true;
            lblManageBook.BackColor = Color.Transparent;
            lblManageBook.Cursor = Cursors.Hand;
            lblManageBook.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblManageBook.ForeColor = SystemColors.ControlLightLight;
            lblManageBook.Location = new Point(63, 161);
            lblManageBook.Name = "lblManageBook";
            lblManageBook.Size = new Size(78, 13);
            lblManageBook.TabIndex = 27;
            lblManageBook.Text = "Manage Book";
            lblManageBook.Click += lblManageBook_Click;
            // 
            // lblPageDashboard
            // 
            lblPageDashboard.AutoSize = true;
            lblPageDashboard.BackColor = Color.Transparent;
            lblPageDashboard.Cursor = Cursors.Hand;
            lblPageDashboard.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblPageDashboard.ForeColor = SystemColors.ControlLightLight;
            lblPageDashboard.Location = new Point(63, 119);
            lblPageDashboard.Name = "lblPageDashboard";
            lblPageDashboard.Size = new Size(63, 13);
            lblPageDashboard.TabIndex = 26;
            lblPageDashboard.Text = "Dashboard";
            lblPageDashboard.Click += lblPageDashboard_Click;
            // 
            // lblTotalMemberBaru
            // 
            lblTotalMemberBaru.AutoSize = true;
            lblTotalMemberBaru.BackColor = Color.Transparent;
            lblTotalMemberBaru.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblTotalMemberBaru.ForeColor = SystemColors.ControlLightLight;
            lblTotalMemberBaru.Location = new Point(285, 180);
            lblTotalMemberBaru.Name = "lblTotalMemberBaru";
            lblTotalMemberBaru.Size = new Size(51, 28);
            lblTotalMemberBaru.TabIndex = 33;
            lblTotalMemberBaru.Text = "N/A";
            // 
            // lblTotalPeminjaman
            // 
            lblTotalPeminjaman.AutoSize = true;
            lblTotalPeminjaman.BackColor = Color.Transparent;
            lblTotalPeminjaman.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblTotalPeminjaman.ForeColor = SystemColors.ControlLightLight;
            lblTotalPeminjaman.Location = new Point(603, 180);
            lblTotalPeminjaman.Name = "lblTotalPeminjaman";
            lblTotalPeminjaman.Size = new Size(51, 28);
            lblTotalPeminjaman.TabIndex = 33;
            lblTotalPeminjaman.Text = "N/A";
            // 
            // lblTotalPengembalian
            // 
            lblTotalPengembalian.AutoSize = true;
            lblTotalPengembalian.BackColor = Color.Transparent;
            lblTotalPengembalian.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblTotalPengembalian.ForeColor = SystemColors.ControlLightLight;
            lblTotalPengembalian.Location = new Point(921, 180);
            lblTotalPengembalian.Name = "lblTotalPengembalian";
            lblTotalPengembalian.Size = new Size(51, 28);
            lblTotalPengembalian.TabIndex = 33;
            lblTotalPengembalian.Text = "N/A";
            // 
            // lblTotalBukuBaru
            // 
            lblTotalBukuBaru.AutoSize = true;
            lblTotalBukuBaru.BackColor = Color.Transparent;
            lblTotalBukuBaru.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblTotalBukuBaru.ForeColor = SystemColors.ControlLightLight;
            lblTotalBukuBaru.Location = new Point(765, 278);
            lblTotalBukuBaru.Name = "lblTotalBukuBaru";
            lblTotalBukuBaru.Size = new Size(51, 28);
            lblTotalBukuBaru.TabIndex = 33;
            lblTotalBukuBaru.Text = "N/A";
            // 
            // lblTotalDenda
            // 
            lblTotalDenda.AutoSize = true;
            lblTotalDenda.BackColor = Color.Transparent;
            lblTotalDenda.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblTotalDenda.ForeColor = SystemColors.ControlLightLight;
            lblTotalDenda.Location = new Point(446, 278);
            lblTotalDenda.Name = "lblTotalDenda";
            lblTotalDenda.Size = new Size(51, 28);
            lblTotalDenda.TabIndex = 33;
            lblTotalDenda.Text = "N/A";
            // 
            // lblNamaAdmin
            // 
            lblNamaAdmin.BackColor = Color.Transparent;
            lblNamaAdmin.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNamaAdmin.ForeColor = SystemColors.ControlLightLight;
            lblNamaAdmin.Location = new Point(1048, 25);
            lblNamaAdmin.Name = "lblNamaAdmin";
            lblNamaAdmin.Size = new Size(131, 20);
            lblNamaAdmin.TabIndex = 40;
            lblNamaAdmin.Text = "N/A";
            lblNamaAdmin.TextAlign = ContentAlignment.MiddleRight;
            // 
            // MonthlyReport
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1216, 588);
            Controls.Add(lblNamaAdmin);
            Controls.Add(lblTotalDenda);
            Controls.Add(lblTotalBukuBaru);
            Controls.Add(lblTotalPengembalian);
            Controls.Add(lblTotalPeminjaman);
            Controls.Add(lblTotalMemberBaru);
            Controls.Add(lblLogout);
            Controls.Add(lblMonthReport);
            Controls.Add(lblBooked);
            Controls.Add(lblManageMember);
            Controls.Add(lblManageBook);
            Controls.Add(lblPageDashboard);
            DoubleBuffered = true;
            Name = "MonthlyReport";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MonthlyReport";
            Load += MonthlyReport_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblLogout;
        private Label lblMonthReport;
        private Label lblBooked;
        private Label lblManageMember;
        private Label lblManageBook;
        private Label lblPageDashboard;
        private Label lblTotalMemberBaru;
        private Label lblTotalPeminjaman;
        private Label lblTotalPengembalian;
        private Label lblTotalBukuBaru;
        private Label lblTotalDenda;
        private Label lblNamaAdmin;
    }
}