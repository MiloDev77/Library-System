﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class MonthlyReport : Form
    {
        string usernameAdmin;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TotalNewMember
        {
            get => lblTotalMemberBaru.Text;
            set => lblTotalMemberBaru.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TotalReserved
        {
            get => lblTotalPeminjaman.Text;
            set => lblTotalPeminjaman.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TotalReturned
        {
            get => lblTotalPengembalian.Text;
            set => lblTotalPengembalian.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TotalFines
        {
            get => lblTotalDenda.Text;
            set => lblTotalDenda.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TotalNewBooks
        {
            get => lblTotalBukuBaru.Text;
            set => lblTotalBukuBaru.Text = value;
        }
        public MonthlyReport(string username)
        {
            InitializeComponent();
            usernameAdmin = username;
        }

        private void lblPageDashboard_Click(object sender, EventArgs e)
        {
            DashboardAdmin dashboard = new DashboardAdmin(usernameAdmin);
            dashboard.Show();
            this.Hide();
        }

        private void lblManageBook_Click(object sender, EventArgs e)
        {
            ManageBook mb = new ManageBook(usernameAdmin);
            mb.Show();
            this.Hide();
        }

        private void lblManageMember_Click(object sender, EventArgs e)
        {
            ManageMember mbr = new ManageMember(usernameAdmin);
            mbr.Show();
            this.Hide();
        }

        private void lblBooked_Click(object sender, EventArgs e)
        {
            Booked pinjam = new Booked(usernameAdmin);
            pinjam.Show();
            this.Hide();
        }

        private void lblMonthReport_Click(object sender, EventArgs e)
        {
            MonthlyReport report = new MonthlyReport(usernameAdmin);
            report.Show();
            this.Hide();
        }

        private void lblLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void MonthlyReport_Load(object sender, EventArgs e)
        {
            lblNamaAdmin.Text = usernameAdmin;

            LoadMonthlyReport();
        }

        private void LoadMonthlyReport()
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                TotalNewMember = new SqlCommand(
                    "SELECT COUNT(*) FROM tblmember", conn
                ).ExecuteScalar().ToString();

                TotalReserved = new SqlCommand(
                    "SELECT COUNT(*) FROM tblpeminjaman WHERE status_peminjaman='active'", conn
                ).ExecuteScalar().ToString();

                TotalReturned = new SqlCommand(
                    "SELECT COUNT(*) FROM tblpeminjaman WHERE status_peminjaman='returned'", conn
                ).ExecuteScalar().ToString();

                object denda = new SqlCommand(
                    "SELECT ISNULL(SUM(jumlah_denda),0) FROM tbldenda", conn
                ).ExecuteScalar();

                TotalFines = "Rp " + denda.ToString();

                TotalNewBooks = new SqlCommand(
                    "SELECT COUNT(*) FROM tblbuku", conn
                ).ExecuteScalar().ToString();
            }
        }
    }
}
