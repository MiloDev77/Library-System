﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class MyBook : Form
    {
        string usernameMember;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string SearchBook
        {
            get => txtSearchBar.Text;
            set => txtSearchBar.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Category
        {
            get => cbKategori.Text;
            set => cbKategori.Text = value;
        }
        public MyBook(string username)
        {
            InitializeComponent();

            usernameMember = username;
        }

        private void MyBook_Load(object sender, EventArgs e)
        {
            lblNamaMember.Text = usernameMember;
            dtpTanggalPinjam.Format = DateTimePickerFormat.Custom;
            dtpTanggalPinjam.CustomFormat = "dddd, dd MMMM yyyy";

            LoadMyBooks();
            LoadKategori();
        }

        private void lblPageDashboard_Click(object sender, EventArgs e)
        {
            DashboardMember dashboardMember = new DashboardMember(usernameMember);
            dashboardMember.Show();
            this.Hide();
        }

        private void lblBookCatalogue_Click(object sender, EventArgs e)
        {
            BookCatalogue bookCatalogue = new BookCatalogue(usernameMember);
            bookCatalogue.Show();
            this.Hide();
        }

        private void lblMyBook_Click(object sender, EventArgs e)
        {
            MyBook myBook = new MyBook(usernameMember);
            myBook.Show();
            this.Hide();
        }

        private void lblHistory_Click(object sender, EventArgs e)
        {
            History history = new History(usernameMember);
            history.Show();
            this.Hide();
        }

        private void lblProfile_Click(object sender, EventArgs e)
        {
            Profile profile = new Profile(usernameMember);
            profile.Show();
            this.Hide();
        }

        private void lblLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void LoadKategori()
        {
            cbKategori.Items.Clear();
            cbKategori.Items.Add("");

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = "SELECT jenis FROM tbljenisbuku";
                SqlCommand cmd = new SqlCommand(query, conn);

                SqlDataReader rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    cbKategori.Items.Add(rd["jenis"].ToString());
                }
            }
        }

        private void LoadMyBooks(string search = "", string kategori = "", string tanggal = "")
        {
            layoutPanelBuku.Controls.Clear();

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"SELECT p.*, b.judul, b.tahun_terbit, b.gambar,
                                pen.nama_penulis, j.jenis
                                FROM tblpeminjaman p
                                JOIN tblbuku b ON p.id_buku = b.id_buku
                                JOIN tblmember m ON p.id_member = m.id_member
                                JOIN tblpenulis pen ON b.penulis_id = pen.id_penulis
                                JOIN tbljenisbuku j ON b.jenisbuku_id = j.id_jenis
                                WHERE m.username=@user AND p.status_peminjaman='Active'";

                if (!string.IsNullOrEmpty(search))
                    query += " AND LOWER(b.judul) LIKE @search";

                if (!string.IsNullOrEmpty(kategori))
                    query += " AND j.jenis = @kategori";

                if (!string.IsNullOrEmpty(tanggal))
                    query += " AND CONVERT(date, p.tanggal_pinjam) = @tanggal";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@user", usernameMember);

                if (!string.IsNullOrEmpty(search))
                    cmd.Parameters.AddWithValue("@search", "%" + search.ToLower() + "%");

                if (!string.IsNullOrEmpty(kategori))
                    cmd.Parameters.AddWithValue("@kategori", kategori);

                if (!string.IsNullOrEmpty(tanggal))
                    cmd.Parameters.AddWithValue("@tanggal", tanggal);

                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    templateDipinjamBook item = new templateDipinjamBook();

                    item.ReserveId = Convert.ToInt32(rd["id_peminjaman"]);
                    item.BookId = Convert.ToInt32(rd["id_buku"]);
                    item.BookName = rd["judul"].ToString();
                    item.Writer = rd["nama_penulis"].ToString();
                    item.PublishYear = Convert.ToInt32(rd["tahun_terbit"]);

                    item.ReserveDate = Convert.ToDateTime(rd["tanggal_pinjam"]).ToString("dd-MM-yyyy");
                    item.ReturnDate = Convert.ToDateTime(rd["tanggal_kembali"]).ToString("dd-MM-yyyy");

                    if (rd["gambar"] != DBNull.Value)
                    {
                        byte[] imgBytes = (byte[])rd["gambar"];
                        using (MemoryStream ms = new MemoryStream(imgBytes))
                        {
                            item.BookImage = Image.FromStream(ms);
                        }
                    }

                    int idPeminjaman = Convert.ToInt32(rd["id_peminjaman"]);
                    DateTime tglKembali = Convert.ToDateTime(rd["tanggal_kembali"]);

                    item.BtnReturn.Click += (s, e) =>
                    {
                        DateTime now = DateTime.Now;

                        if (now.Date > tglKembali.Date)
                        {
                            FinesPayment fines = new FinesPayment(usernameMember);

                            fines.IdPeminjaman = idPeminjaman;
                            fines.ShowDialog();

                            LoadMyBooks();
                        }
                        else
                        {
                            RequestKembali(idPeminjaman);
                            LoadMyBooks();
                        }
                    };

                    layoutPanelBuku.Controls.Add(item);
                }
            }
        }

        private void RequestKembali(int idPeminjaman)
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"INSERT INTO tblrequest_kembali
                         (id_peminjaman, status_request)
                         VALUES (@id, 'Pending')";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", idPeminjaman);

                cmd.ExecuteNonQuery();
            }
        }

        private void txtSearchBar_TextChanged(object sender, EventArgs e)
        {
            LoadMyBooks(SearchBook, Category, "");
        }

        private void cbKategori_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadMyBooks(SearchBook, Category, "");
        }

        private void dtpMyBook_ValueChanged(object sender, EventArgs e)
        {
            string tgl = dtpTanggalPinjam.Value.ToString("yyyy-MM-dd");
            LoadMyBooks(SearchBook, Category, tgl);
        }
    }
}
