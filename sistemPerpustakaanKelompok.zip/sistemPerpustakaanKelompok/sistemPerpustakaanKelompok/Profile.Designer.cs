﻿namespace SistemPerpustakaanKelompok
{
    partial class Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Profile));
            lblLogout = new Label();
            lblProfile = new Label();
            lblHistory = new Label();
            lblMyBook = new Label();
            lblBookCatalogue = new Label();
            lblPageDashboard = new Label();
            lblUsername = new Label();
            lblIdMember = new Label();
            lblAlamat = new Label();
            lblNoHp = new Label();
            EditProfile = new Label();
            lblPassword = new Label();
            SuspendLayout();
            // 
            // lblLogout
            // 
            lblLogout.AutoSize = true;
            lblLogout.BackColor = Color.Transparent;
            lblLogout.Cursor = Cursors.Hand;
            lblLogout.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblLogout.ForeColor = SystemColors.ControlLightLight;
            lblLogout.Location = new Point(63, 553);
            lblLogout.Name = "lblLogout";
            lblLogout.Size = new Size(43, 13);
            lblLogout.TabIndex = 54;
            lblLogout.Text = "Logout";
            lblLogout.Click += lblLogout_Click;
            // 
            // lblProfile
            // 
            lblProfile.AutoSize = true;
            lblProfile.BackColor = Color.Transparent;
            lblProfile.Cursor = Cursors.Hand;
            lblProfile.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblProfile.ForeColor = SystemColors.ControlLightLight;
            lblProfile.Location = new Point(63, 312);
            lblProfile.Name = "lblProfile";
            lblProfile.Size = new Size(40, 13);
            lblProfile.TabIndex = 53;
            lblProfile.Text = "Profile";
            lblProfile.Click += lblProfile_Click;
            // 
            // lblHistory
            // 
            lblHistory.AutoSize = true;
            lblHistory.BackColor = Color.Transparent;
            lblHistory.Cursor = Cursors.Hand;
            lblHistory.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblHistory.ForeColor = SystemColors.ControlLightLight;
            lblHistory.Location = new Point(63, 264);
            lblHistory.Name = "lblHistory";
            lblHistory.Size = new Size(44, 13);
            lblHistory.TabIndex = 52;
            lblHistory.Text = "History";
            lblHistory.Click += lblHistory_Click;
            // 
            // lblMyBook
            // 
            lblMyBook.AutoSize = true;
            lblMyBook.BackColor = Color.Transparent;
            lblMyBook.Cursor = Cursors.Hand;
            lblMyBook.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblMyBook.ForeColor = SystemColors.ControlLightLight;
            lblMyBook.Location = new Point(63, 218);
            lblMyBook.Name = "lblMyBook";
            lblMyBook.Size = new Size(53, 13);
            lblMyBook.TabIndex = 51;
            lblMyBook.Text = "My Book";
            lblMyBook.Click += lblMyBook_Click;
            // 
            // lblBookCatalogue
            // 
            lblBookCatalogue.AutoSize = true;
            lblBookCatalogue.BackColor = Color.Transparent;
            lblBookCatalogue.Cursor = Cursors.Hand;
            lblBookCatalogue.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblBookCatalogue.ForeColor = SystemColors.ControlLightLight;
            lblBookCatalogue.Location = new Point(63, 172);
            lblBookCatalogue.Name = "lblBookCatalogue";
            lblBookCatalogue.Size = new Size(89, 13);
            lblBookCatalogue.TabIndex = 50;
            lblBookCatalogue.Text = "Book Catalogue";
            lblBookCatalogue.Click += lblBookCatalogue_Click;
            // 
            // lblPageDashboard
            // 
            lblPageDashboard.AutoSize = true;
            lblPageDashboard.BackColor = Color.Transparent;
            lblPageDashboard.Cursor = Cursors.Hand;
            lblPageDashboard.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblPageDashboard.ForeColor = SystemColors.ControlLightLight;
            lblPageDashboard.Location = new Point(63, 124);
            lblPageDashboard.Name = "lblPageDashboard";
            lblPageDashboard.Size = new Size(63, 13);
            lblPageDashboard.TabIndex = 49;
            lblPageDashboard.Text = "Dashboard";
            lblPageDashboard.Click += lblPageDashboard_Click;
            // 
            // lblUsername
            // 
            lblUsername.BackColor = Color.Transparent;
            lblUsername.Font = new Font("Segoe UI", 21F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblUsername.ForeColor = SystemColors.ControlLightLight;
            lblUsername.Location = new Point(215, 449);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(313, 39);
            lblUsername.TabIndex = 55;
            lblUsername.Text = "N/A";
            lblUsername.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblIdMember
            // 
            lblIdMember.BackColor = Color.Transparent;
            lblIdMember.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblIdMember.ForeColor = SystemColors.ControlLightLight;
            lblIdMember.Location = new Point(761, 175);
            lblIdMember.Name = "lblIdMember";
            lblIdMember.Size = new Size(307, 31);
            lblIdMember.TabIndex = 56;
            lblIdMember.Text = "N/A";
            lblIdMember.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblAlamat
            // 
            lblAlamat.BackColor = Color.Transparent;
            lblAlamat.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAlamat.ForeColor = SystemColors.ControlLightLight;
            lblAlamat.Location = new Point(761, 248);
            lblAlamat.Name = "lblAlamat";
            lblAlamat.Size = new Size(307, 31);
            lblAlamat.TabIndex = 56;
            lblAlamat.Text = "N/A";
            lblAlamat.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblNoHp
            // 
            lblNoHp.BackColor = Color.Transparent;
            lblNoHp.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblNoHp.ForeColor = SystemColors.ControlLightLight;
            lblNoHp.Location = new Point(761, 323);
            lblNoHp.Name = "lblNoHp";
            lblNoHp.Size = new Size(307, 31);
            lblNoHp.TabIndex = 56;
            lblNoHp.Text = "N/A";
            lblNoHp.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // EditProfile
            // 
            EditProfile.AutoSize = true;
            EditProfile.BackColor = Color.Transparent;
            EditProfile.Cursor = Cursors.Hand;
            EditProfile.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            EditProfile.ForeColor = SystemColors.ControlLightLight;
            EditProfile.Location = new Point(224, 428);
            EditProfile.Name = "EditProfile";
            EditProfile.Size = new Size(32, 21);
            EditProfile.TabIndex = 57;
            EditProfile.Text = "✏️";
            EditProfile.Click += EditProfile_Click;
            // 
            // lblPassword
            // 
            lblPassword.BackColor = Color.Transparent;
            lblPassword.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPassword.ForeColor = SystemColors.ControlLightLight;
            lblPassword.Location = new Point(761, 395);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(307, 31);
            lblPassword.TabIndex = 56;
            lblPassword.Text = "N/A";
            lblPassword.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // Profile
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1216, 588);
            Controls.Add(EditProfile);
            Controls.Add(lblPassword);
            Controls.Add(lblNoHp);
            Controls.Add(lblAlamat);
            Controls.Add(lblIdMember);
            Controls.Add(lblUsername);
            Controls.Add(lblLogout);
            Controls.Add(lblProfile);
            Controls.Add(lblHistory);
            Controls.Add(lblMyBook);
            Controls.Add(lblBookCatalogue);
            Controls.Add(lblPageDashboard);
            DoubleBuffered = true;
            Name = "Profile";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Profile";
            Load += Profile_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblLogout;
        private Label lblProfile;
        private Label lblHistory;
        private Label lblMyBook;
        private Label lblBookCatalogue;
        private Label lblPageDashboard;
        private Label lblUsername;
        private Label lblIdMember;
        private Label lblAlamat;
        private Label lblNoHp;
        private Label EditProfile;
        private Label lblPassword;
    }
}