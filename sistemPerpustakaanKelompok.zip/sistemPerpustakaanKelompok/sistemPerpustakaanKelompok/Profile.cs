﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class Profile : Form
    {
        string usernameMember;
        long IdMember;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Username
        {
            get => lblUsername.Text;
            set => lblUsername.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Address
        {
            get => lblAlamat.Text;
            set => lblAlamat.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string HandphoneNumber
        {
            get => lblNoHp.Text;
            set => lblNoHp.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Password
        {
            get => lblPassword.Text;
            set => lblPassword.Text = value;
        }
        public Profile(string username)
        {
            InitializeComponent();
            usernameMember = username;
        }

        private void lblPageDashboard_Click(object sender, EventArgs e)
        {
            DashboardMember dashboardMember = new DashboardMember(usernameMember);
            dashboardMember.Show();
            this.Hide();
        }

        private void lblBookCatalogue_Click(object sender, EventArgs e)
        {
            BookCatalogue bookCatalogue = new BookCatalogue(usernameMember);
            bookCatalogue.Show();
            this.Hide();
        }

        private void lblMyBook_Click(object sender, EventArgs e)
        {
            MyBook myBook = new MyBook(usernameMember);
            myBook.Show();
            this.Hide();
        }

        private void lblHistory_Click(object sender, EventArgs e)
        {
            History history = new History(usernameMember);
            history.Show();
            this.Hide();
        }

        private void lblProfile_Click(object sender, EventArgs e)
        {
            Profile profile = new Profile(usernameMember);
            profile.Show();
            this.Hide();
        }

        private void lblLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void Profile_Load(object sender, EventArgs e)
        {
            LoadProfile();
        }

        private void LoadProfile()
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = "SELECT * FROM tblmember WHERE username = @username";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@username", usernameMember);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    IdMember = Convert.ToInt64(reader["id_member"]);
                    TampilProfile(
                        IdMember,
                        reader["username"].ToString(),
                        reader["alamat"].ToString(),
                        reader["no_hp"].ToString()
                    );
                }
            }
        }

        private void TampilProfile(long id, string username, string alamat, string noHp)
        {
            lblIdMember.Text = id.ToString();
            Username = username;
            Address = alamat;
            HandphoneNumber = noHp;
            Password = "●●●●●●●●●●●●";
        }

        private void EditProfile_Click(object sender, EventArgs e)
        {
            EditProfile editProfile = new EditProfile(usernameMember);
            editProfile.Show();
            this.Hide();
        }
    }
}