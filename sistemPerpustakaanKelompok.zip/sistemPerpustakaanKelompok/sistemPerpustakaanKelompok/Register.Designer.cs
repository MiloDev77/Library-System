﻿namespace SistemPerpustakaanKelompok
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Register));
            lblRegister = new Label();
            txtPassword = new TextBox();
            txtAlamat = new TextBox();
            txtTelpNumber = new TextBox();
            txtIdNumber = new TextBox();
            lblLogin = new Label();
            txtUsername = new TextBox();
            SuspendLayout();
            // 
            // lblRegister
            // 
            lblRegister.AutoSize = true;
            lblRegister.BackColor = Color.White;
            lblRegister.Cursor = Cursors.Hand;
            lblRegister.Font = new Font("Cambria", 18F, FontStyle.Bold);
            lblRegister.Location = new Point(851, 452);
            lblRegister.Name = "lblRegister";
            lblRegister.Size = new Size(105, 28);
            lblRegister.TabIndex = 5;
            lblRegister.Text = "Register";
            lblRegister.Click += lblRegister_Click;
            // 
            // txtPassword
            // 
            txtPassword.BorderStyle = BorderStyle.None;
            txtPassword.Location = new Point(683, 343);
            txtPassword.Margin = new Padding(3, 2, 3, 2);
            txtPassword.Multiline = true;
            txtPassword.Name = "txtPassword";
            txtPassword.PlaceholderText = "Password";
            txtPassword.Size = new Size(201, 20);
            txtPassword.TabIndex = 4;
            // 
            // txtAlamat
            // 
            txtAlamat.BorderStyle = BorderStyle.None;
            txtAlamat.Location = new Point(913, 292);
            txtAlamat.Margin = new Padding(3, 2, 3, 2);
            txtAlamat.Multiline = true;
            txtAlamat.Name = "txtAlamat";
            txtAlamat.PlaceholderText = "Jalan xxx";
            txtAlamat.Size = new Size(204, 20);
            txtAlamat.TabIndex = 6;
            // 
            // txtTelpNumber
            // 
            txtTelpNumber.BorderStyle = BorderStyle.None;
            txtTelpNumber.Location = new Point(913, 343);
            txtTelpNumber.Margin = new Padding(3, 2, 3, 2);
            txtTelpNumber.Multiline = true;
            txtTelpNumber.Name = "txtTelpNumber";
            txtTelpNumber.PlaceholderText = "62+";
            txtTelpNumber.Size = new Size(204, 20);
            txtTelpNumber.TabIndex = 7;
            // 
            // txtIdNumber
            // 
            txtIdNumber.BorderStyle = BorderStyle.None;
            txtIdNumber.Location = new Point(683, 395);
            txtIdNumber.Margin = new Padding(3, 2, 3, 2);
            txtIdNumber.Multiline = true;
            txtIdNumber.Name = "txtIdNumber";
            txtIdNumber.PlaceholderText = "Id Number";
            txtIdNumber.Size = new Size(201, 20);
            txtIdNumber.TabIndex = 8;
            // 
            // lblLogin
            // 
            lblLogin.AutoSize = true;
            lblLogin.BackColor = Color.FromArgb(64, 64, 64);
            lblLogin.Cursor = Cursors.Hand;
            lblLogin.Font = new Font("Cambria", 12F, FontStyle.Bold);
            lblLogin.ForeColor = SystemColors.ActiveCaption;
            lblLogin.Location = new Point(959, 499);
            lblLogin.Name = "lblLogin";
            lblLogin.Size = new Size(50, 19);
            lblLogin.TabIndex = 9;
            lblLogin.Text = "Login";
            lblLogin.Click += lblLogin_Click;
            // 
            // txtUsername
            // 
            txtUsername.BorderStyle = BorderStyle.None;
            txtUsername.Location = new Point(683, 292);
            txtUsername.Margin = new Padding(3, 2, 3, 2);
            txtUsername.Multiline = true;
            txtUsername.Name = "txtUsername";
            txtUsername.PlaceholderText = "Username";
            txtUsername.Size = new Size(201, 20);
            txtUsername.TabIndex = 3;
            // 
            // Register
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1216, 588);
            Controls.Add(lblLogin);
            Controls.Add(txtIdNumber);
            Controls.Add(txtTelpNumber);
            Controls.Add(txtAlamat);
            Controls.Add(lblRegister);
            Controls.Add(txtPassword);
            Controls.Add(txtUsername);
            DoubleBuffered = true;
            Margin = new Padding(3, 2, 3, 2);
            Name = "Register";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Register";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblRegister;
        private TextBox txtPassword;
        private TextBox txtAlamat;
        private TextBox txtTelpNumber;
        private TextBox txtIdNumber;
        private Label lblLogin;
        private TextBox txtUsername;
    }
}