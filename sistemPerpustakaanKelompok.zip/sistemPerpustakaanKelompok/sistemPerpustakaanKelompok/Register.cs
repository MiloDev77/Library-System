﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();

                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }

                return builder.ToString();
            }
        }

        private void lblRegister_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "" || txtPassword.Text == "" ||
                txtIdNumber.Text == "" || txtAlamat.Text == "" ||
                txtTelpNumber.Text == "")
            {
                MessageBox.Show("All Data Must Be Filled!", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                using (SqlConnection conn = Koneksi.GetConnection())
                {
                    conn.Open();

                    string CheckUser = "SELECT COUNT(*) FROM tblmember WHERE username=@u";
                    SqlCommand checkCmd = new SqlCommand(CheckUser, conn);
                    checkCmd.Parameters.AddWithValue("@u", txtUsername.Text);

                    int count = (int)checkCmd.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("Username Already Exists!", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    string HashedPassword = HashPassword(txtPassword.Text);

                    string query = "INSERT INTO tblmember (id_card, username, password, alamat, no_hp, is_active) " +
                                   "VALUES (@id_card, @username, @password, @alamat, @no_hp, 1)";

                    SqlCommand cmd = new SqlCommand(query, conn);

                    cmd.Parameters.AddWithValue("@id_card", txtIdNumber.Text);
                    cmd.Parameters.AddWithValue("@username", txtUsername.Text);
                    cmd.Parameters.AddWithValue("@password", HashedPassword);
                    cmd.Parameters.AddWithValue("@alamat", txtAlamat.Text);
                    cmd.Parameters.AddWithValue("@no_hp", txtTelpNumber.Text);

                    cmd.ExecuteNonQuery();
                }

                txtUsername.Clear();
                txtPassword.Clear();
                txtAlamat.Clear();
                txtTelpNumber.Clear();
                txtIdNumber.Clear();

                Login login = new Login();
                login.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error At: " + ex.Message, "There Is Something Wrong!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lblLogin_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }
    }
}