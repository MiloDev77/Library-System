﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class rejectReason : Form
    {
        string usernameAdmin;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string RejectBox
        {
            get => txtAlasan.Text;
            set => txtAlasan.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int IdRequest
        {
            get;
            set;
        }
        public rejectReason(string username)
        {
            InitializeComponent();
            usernameAdmin = username;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Booked pinjam = new Booked(usernameAdmin);
            pinjam.Show();
            this.Hide();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"UPDATE tblrequest_pinjam 
                         SET status_request='Rejected', 
                             keterangan=@ket
                         WHERE id_request=@id";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ket", RejectBox);
                cmd.Parameters.AddWithValue("@id", IdRequest);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Reason Has Been Sent!");
            this.Close();
        }
    }
}
