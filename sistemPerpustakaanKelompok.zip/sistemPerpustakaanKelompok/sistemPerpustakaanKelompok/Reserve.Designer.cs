﻿namespace SistemPerpustakaanKelompok
{
    partial class Reserve
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Reserve));
            gambarBuku = new PictureBox();
            lblNamaPeminjam = new Label();
            lblNamaBuku = new Label();
            lblJenisBuku = new Label();
            lblPenulis = new Label();
            lblTahunTerbit = new Label();
            label1 = new Label();
            dtpTanggalPinjam = new DateTimePicker();
            label2 = new Label();
            dtpTanggalKembali = new DateTimePicker();
            btnRequest = new Button();
            ((System.ComponentModel.ISupportInitialize)gambarBuku).BeginInit();
            SuspendLayout();
            // 
            // gambarBuku
            // 
            gambarBuku.BackColor = Color.Transparent;
            gambarBuku.BackgroundImageLayout = ImageLayout.Stretch;
            gambarBuku.Location = new Point(115, 35);
            gambarBuku.Name = "gambarBuku";
            gambarBuku.Size = new Size(108, 163);
            gambarBuku.TabIndex = 0;
            gambarBuku.TabStop = false;
            // 
            // lblNamaPeminjam
            // 
            lblNamaPeminjam.BackColor = Color.Transparent;
            lblNamaPeminjam.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNamaPeminjam.ForeColor = SystemColors.ControlLightLight;
            lblNamaPeminjam.Location = new Point(12, 214);
            lblNamaPeminjam.Name = "lblNamaPeminjam";
            lblNamaPeminjam.Size = new Size(324, 23);
            lblNamaPeminjam.TabIndex = 1;
            lblNamaPeminjam.Text = "N/A";
            // 
            // lblNamaBuku
            // 
            lblNamaBuku.BackColor = Color.Transparent;
            lblNamaBuku.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNamaBuku.ForeColor = SystemColors.ControlLightLight;
            lblNamaBuku.Location = new Point(12, 241);
            lblNamaBuku.Name = "lblNamaBuku";
            lblNamaBuku.Size = new Size(324, 21);
            lblNamaBuku.TabIndex = 1;
            lblNamaBuku.Text = "N/A";
            // 
            // lblJenisBuku
            // 
            lblJenisBuku.BackColor = Color.Transparent;
            lblJenisBuku.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblJenisBuku.ForeColor = SystemColors.ControlLightLight;
            lblJenisBuku.Location = new Point(12, 269);
            lblJenisBuku.Name = "lblJenisBuku";
            lblJenisBuku.Size = new Size(324, 21);
            lblJenisBuku.TabIndex = 1;
            lblJenisBuku.Text = "N/A";
            // 
            // lblPenulis
            // 
            lblPenulis.BackColor = Color.Transparent;
            lblPenulis.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPenulis.ForeColor = SystemColors.ControlLightLight;
            lblPenulis.Location = new Point(12, 297);
            lblPenulis.Name = "lblPenulis";
            lblPenulis.Size = new Size(324, 21);
            lblPenulis.TabIndex = 1;
            lblPenulis.Text = "N/A";
            // 
            // lblTahunTerbit
            // 
            lblTahunTerbit.BackColor = Color.Transparent;
            lblTahunTerbit.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTahunTerbit.ForeColor = SystemColors.ControlLightLight;
            lblTahunTerbit.Location = new Point(12, 327);
            lblTahunTerbit.Name = "lblTahunTerbit";
            lblTahunTerbit.Size = new Size(324, 21);
            lblTahunTerbit.TabIndex = 1;
            lblTahunTerbit.Text = "N/A";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(117, 356);
            label1.Name = "label1";
            label1.Size = new Size(101, 21);
            label1.TabIndex = 2;
            label1.Text = "Reserve Date";
            // 
            // dtpTanggalPinjam
            // 
            dtpTanggalPinjam.Location = new Point(12, 380);
            dtpTanggalPinjam.Name = "dtpTanggalPinjam";
            dtpTanggalPinjam.Size = new Size(324, 23);
            dtpTanggalPinjam.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ControlLightLight;
            label2.Location = new Point(121, 413);
            label2.Name = "label2";
            label2.Size = new Size(93, 21);
            label2.TabIndex = 2;
            label2.Text = "Return Date";
            // 
            // dtpTanggalKembali
            // 
            dtpTanggalKembali.Location = new Point(12, 437);
            dtpTanggalKembali.Name = "dtpTanggalKembali";
            dtpTanggalKembali.Size = new Size(324, 23);
            dtpTanggalKembali.TabIndex = 3;
            // 
            // btnRequest
            // 
            btnRequest.BackColor = Color.Lime;
            btnRequest.Cursor = Cursors.Hand;
            btnRequest.FlatStyle = FlatStyle.Popup;
            btnRequest.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRequest.Location = new Point(12, 480);
            btnRequest.Name = "btnRequest";
            btnRequest.Size = new Size(324, 45);
            btnRequest.TabIndex = 4;
            btnRequest.Text = "Send Request";
            btnRequest.UseVisualStyleBackColor = false;
            btnRequest.Click += btnRequest_Click;
            // 
            // Reserve
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(348, 561);
            Controls.Add(btnRequest);
            Controls.Add(dtpTanggalKembali);
            Controls.Add(label2);
            Controls.Add(dtpTanggalPinjam);
            Controls.Add(label1);
            Controls.Add(lblTahunTerbit);
            Controls.Add(lblPenulis);
            Controls.Add(lblJenisBuku);
            Controls.Add(lblNamaBuku);
            Controls.Add(lblNamaPeminjam);
            Controls.Add(gambarBuku);
            DoubleBuffered = true;
            Name = "Reserve";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Reserve";
            Load += Reserve_Load;
            ((System.ComponentModel.ISupportInitialize)gambarBuku).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox gambarBuku;
        private Label lblNamaPeminjam;
        private Label lblNamaBuku;
        private Label lblJenisBuku;
        private Label lblPenulis;
        private Label lblTahunTerbit;
        private Label label1;
        private DateTimePicker dtpTanggalPinjam;
        private Label label2;
        private DateTimePicker dtpTanggalKembali;
        private Button btnRequest;
    }
}