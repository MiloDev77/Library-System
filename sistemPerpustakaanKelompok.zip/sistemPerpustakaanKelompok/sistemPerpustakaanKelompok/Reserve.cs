﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class Reserve : Form
    {
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Image BookImageReserve
        {
            set
            {
                gambarBuku.Image = value;
                gambarBuku.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ReserveName
        {
            get => lblNamaPeminjam.Text;
            set => lblNamaPeminjam.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string BookName
        {
            get => lblNamaBuku.Text;
            set => lblNamaBuku.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string BookGenre
        {
            get => lblJenisBuku.Text;
            set => lblJenisBuku.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Writer
        {
            get => lblPenulis.Text;
            set => lblPenulis.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PublishYear
        {
            get => lblTahunTerbit.Text;
            set => lblTahunTerbit.Text = value;
        }

        private int idBuku;
        private string usernameMember;

        public Reserve()
        {
            InitializeComponent();
        }

        public void SetData(int id, string username)
        {
            idBuku = id;
            usernameMember = username;
        }
        private void Reserve_Load(object sender, EventArgs e)
        {
            dtpTanggalPinjam.Value = DateTime.Now;
            dtpTanggalPinjam.MinDate = DateTime.Now;
            dtpTanggalPinjam.MaxDate = DateTime.Now;

            dtpTanggalKembali.MinDate = DateTime.Now.AddDays(7);
            dtpTanggalKembali.Value = DateTime.Now.AddDays(7);
        }

        private void btnRequest_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string getMember = "SELECT id_member FROM tblmember WHERE username=@u";
                SqlCommand cmdM = new SqlCommand(getMember, conn);
                cmdM.Parameters.AddWithValue("@u", ReserveName);

                long idMember = Convert.ToInt64(cmdM.ExecuteScalar());
                long idBuku = Convert.ToInt64(this.Tag);

                string query = @"INSERT INTO tblrequest_pinjam
                        (id_member, id_buku, tanggal_request, tanggal_kembali, status_request)
                        VALUES (@m, @b, @tgl, @kembali, 'Pending')";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@m", idMember);
                cmd.Parameters.AddWithValue("@b", idBuku);
                cmd.Parameters.AddWithValue("@tgl", dtpTanggalPinjam.Value);
                cmd.Parameters.AddWithValue("@kembali", dtpTanggalKembali.Value);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Request Has Been Sent!");  
            this.Close();
        }
    }
}
