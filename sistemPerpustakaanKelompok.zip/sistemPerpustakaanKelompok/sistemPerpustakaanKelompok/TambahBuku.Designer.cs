﻿namespace SistemPerpustakaanKelompok
{
    partial class TambahBuku
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TambahBuku));
            txtStock = new TextBox();
            txtTahunTerbit = new TextBox();
            txtPenerbit = new TextBox();
            txtPenulis = new TextBox();
            txtJudul = new TextBox();
            btnTambah = new Button();
            gambarBuku = new PictureBox();
            txtJenisBuku = new TextBox();
            label1 = new Label();
            txtDeskripsi = new RichTextBox();
            ((System.ComponentModel.ISupportInitialize)gambarBuku).BeginInit();
            SuspendLayout();
            // 
            // txtStock
            // 
            txtStock.BorderStyle = BorderStyle.None;
            txtStock.Location = new Point(221, 137);
            txtStock.Name = "txtStock";
            txtStock.PlaceholderText = "Stock";
            txtStock.Size = new Size(414, 16);
            txtStock.TabIndex = 19;
            txtStock.TextAlign = HorizontalAlignment.Center;
            // 
            // txtTahunTerbit
            // 
            txtTahunTerbit.BorderStyle = BorderStyle.None;
            txtTahunTerbit.Location = new Point(221, 115);
            txtTahunTerbit.Name = "txtTahunTerbit";
            txtTahunTerbit.PlaceholderText = "Publication Year";
            txtTahunTerbit.Size = new Size(414, 16);
            txtTahunTerbit.TabIndex = 20;
            txtTahunTerbit.TextAlign = HorizontalAlignment.Center;
            // 
            // txtPenerbit
            // 
            txtPenerbit.BorderStyle = BorderStyle.None;
            txtPenerbit.Location = new Point(221, 93);
            txtPenerbit.Name = "txtPenerbit";
            txtPenerbit.PlaceholderText = "Publisher Name";
            txtPenerbit.Size = new Size(414, 16);
            txtPenerbit.TabIndex = 21;
            txtPenerbit.TextAlign = HorizontalAlignment.Center;
            // 
            // txtPenulis
            // 
            txtPenulis.BorderStyle = BorderStyle.None;
            txtPenulis.Location = new Point(221, 71);
            txtPenulis.Name = "txtPenulis";
            txtPenulis.PlaceholderText = "Writer Name";
            txtPenulis.Size = new Size(414, 16);
            txtPenulis.TabIndex = 22;
            txtPenulis.TextAlign = HorizontalAlignment.Center;
            // 
            // txtJudul
            // 
            txtJudul.BorderStyle = BorderStyle.None;
            txtJudul.Location = new Point(221, 27);
            txtJudul.Name = "txtJudul";
            txtJudul.PlaceholderText = "Title";
            txtJudul.Size = new Size(414, 16);
            txtJudul.TabIndex = 23;
            txtJudul.TextAlign = HorizontalAlignment.Center;
            // 
            // btnTambah
            // 
            btnTambah.BackColor = Color.Lime;
            btnTambah.Cursor = Cursors.Hand;
            btnTambah.FlatStyle = FlatStyle.Popup;
            btnTambah.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnTambah.ForeColor = SystemColors.ControlText;
            btnTambah.Location = new Point(221, 310);
            btnTambah.Name = "btnTambah";
            btnTambah.Size = new Size(414, 31);
            btnTambah.TabIndex = 18;
            btnTambah.Text = "Add";
            btnTambah.UseVisualStyleBackColor = false;
            btnTambah.Click += btnTambah_Click;
            // 
            // gambarBuku
            // 
            gambarBuku.BackColor = Color.Transparent;
            gambarBuku.Cursor = Cursors.Hand;
            gambarBuku.Location = new Point(12, 12);
            gambarBuku.Name = "gambarBuku";
            gambarBuku.Size = new Size(203, 345);
            gambarBuku.TabIndex = 17;
            gambarBuku.TabStop = false;
            gambarBuku.Click += gambarBuku_Click;
            // 
            // txtJenisBuku
            // 
            txtJenisBuku.BorderStyle = BorderStyle.None;
            txtJenisBuku.Location = new Point(221, 49);
            txtJenisBuku.Name = "txtJenisBuku";
            txtJenisBuku.PlaceholderText = "Book Type";
            txtJenisBuku.Size = new Size(414, 16);
            txtJenisBuku.TabIndex = 23;
            txtJenisBuku.TextAlign = HorizontalAlignment.Center;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Black;
            label1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label1.ForeColor = SystemColors.AppWorkspace;
            label1.Location = new Point(69, 176);
            label1.Name = "label1";
            label1.Size = new Size(88, 19);
            label1.TabIndex = 24;
            label1.Text = "Add Picture";
            // 
            // txtDeskripsi
            // 
            txtDeskripsi.Location = new Point(221, 160);
            txtDeskripsi.Name = "txtDeskripsi";
            txtDeskripsi.Size = new Size(414, 144);
            txtDeskripsi.TabIndex = 8;
            txtDeskripsi.Text = "";
            // 
            // TambahBuku
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(668, 372);
            Controls.Add(txtDeskripsi);
            Controls.Add(label1);
            Controls.Add(txtStock);
            Controls.Add(txtTahunTerbit);
            Controls.Add(txtPenerbit);
            Controls.Add(txtPenulis);
            Controls.Add(txtJenisBuku);
            Controls.Add(txtJudul);
            Controls.Add(btnTambah);
            Controls.Add(gambarBuku);
            DoubleBuffered = true;
            Name = "TambahBuku";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "TambahBuku";
            Load += TambahBuku_Load;
            ((System.ComponentModel.ISupportInitialize)gambarBuku).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtStock;
        private TextBox txtTahunTerbit;
        private TextBox txtPenerbit;
        private TextBox txtPenulis;
        private TextBox txtJudul;
        private Button btnTambah;
        private PictureBox gambarBuku;
        private TextBox txtJenisBuku;
        private Label label1;
        private RichTextBox txtDeskripsi;
    }
}