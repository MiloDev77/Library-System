﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class TambahBuku : Form
    {
        string usernameAdmin;
        byte[] imageBytes;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Judul
        {
            get => txtJudul.Text;
            set => txtJudul.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string JenisBuku
        {
            get => txtJenisBuku.Text;
            set => txtJenisBuku.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Penulis
        {
            get => txtPenulis.Text;
            set => txtPenulis.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Penerbit
        {
            get => txtPenerbit.Text;
            set => txtPenerbit.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TahunTerbit
        {
            get => txtTahunTerbit.Text;
            set => txtTahunTerbit.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Stok
        {
            get => txtStock.Text;
            set => txtStock.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Deskripsi
        {
            get => txtDeskripsi.Text;
            set => txtDeskripsi.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Image GambarBuku
        {
            set
            {
                gambarBuku.Image = value;
                gambarBuku.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }
        public TambahBuku(string username)
        {
            InitializeComponent();
            usernameAdmin = username;
        }
        private void gambarBuku_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.jpg;*.png;*.jpeg";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                GambarBuku = Image.FromFile(ofd.FileName);
                imageBytes = File.ReadAllBytes(ofd.FileName);
            }
        }
        private long GetJenisId(string jenis)
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string cek = "SELECT id_jenis FROM tbljenisbuku WHERE jenis=@jenis";
                SqlCommand cmd = new SqlCommand(cek, conn);
                cmd.Parameters.AddWithValue("@jenis", jenis);

                object result = cmd.ExecuteScalar();

                if (result != null)
                    return Convert.ToInt64(result);

                string insert = "INSERT INTO tbljenisbuku (jenis) OUTPUT INSERTED.id_jenis VALUES (@jenis)";
                SqlCommand cmdInsert = new SqlCommand(insert, conn);
                cmdInsert.Parameters.AddWithValue("@jenis", jenis);

                return Convert.ToInt64(cmdInsert.ExecuteScalar());
            }
        }
        private long GetPenulisId(string penulis)
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string cek = "SELECT id_penulis FROM tblpenulis WHERE nama_penulis=@nama";
                SqlCommand cmd = new SqlCommand(cek, conn);
                cmd.Parameters.AddWithValue("@nama", penulis);

                object result = cmd.ExecuteScalar();

                if (result != null)
                    return Convert.ToInt64(result);

                string insert = "INSERT INTO tblpenulis (nama_penulis) OUTPUT INSERTED.id_penulis VALUES (@nama)";
                SqlCommand cmdInsert = new SqlCommand(insert, conn);
                cmdInsert.Parameters.AddWithValue("@nama", penulis);

                return Convert.ToInt64(cmdInsert.ExecuteScalar());
            }
        }

        private long GetPenerbitId(string penerbit)
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string cek = "SELECT id_penerbit FROM tblpenerbit WHERE nama_penerbit=@nama";
                SqlCommand cmd = new SqlCommand(cek, conn);
                cmd.Parameters.AddWithValue("@nama", penerbit);

                object result = cmd.ExecuteScalar();

                if (result != null)
                    return Convert.ToInt64(result);

                string insert = "INSERT INTO tblpenerbit (nama_penerbit) OUTPUT INSERTED.id_penerbit VALUES (@nama)";
                SqlCommand cmdInsert = new SqlCommand(insert, conn);
                cmdInsert.Parameters.AddWithValue("@nama", penerbit);

                return Convert.ToInt64(cmdInsert.ExecuteScalar());
            }
        }

        private void btnTambah_Click(object sender, EventArgs e)
        {
            if (Judul == "" ||
                JenisBuku == "" ||
                Penulis == "" ||
                Penerbit == "" ||
                TahunTerbit == "" ||
                Deskripsi == "" ||
                Stok == "")
            {
                MessageBox.Show("All Fields Must Be Filled!");
                return;
            }

            long jenisId = GetJenisId(JenisBuku);
            long penulisId = GetPenulisId(Penulis);
            long penerbitId = GetPenerbitId(Penerbit);

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"INSERT INTO tblbuku
                (judul, jenisbuku_id, penulis_id, penerbit_id, tahun_terbit, stok, gambar, deskripsi_buku)
                VALUES
                (@judul, @jenis, @penulis, @penerbit, @tahun, @stok, @gambar, @deskripsi)";

                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@judul", Judul);
                cmd.Parameters.AddWithValue("@jenis", jenisId);
                cmd.Parameters.AddWithValue("@penulis", penulisId);
                cmd.Parameters.AddWithValue("@penerbit", penerbitId);
                cmd.Parameters.AddWithValue("@tahun", int.Parse(TahunTerbit));
                cmd.Parameters.AddWithValue("@stok", int.Parse(Stok));
                cmd.Parameters.AddWithValue("@deskripsi", Deskripsi);
                cmd.Parameters.AddWithValue("@gambar", imageBytes ?? (object)DBNull.Value);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Book Successfully Added!");

            ManageBook mb = new ManageBook(usernameAdmin);
            mb.Show();
            this.Hide();
        }

        private void TambahBuku_Load(object sender, EventArgs e)
        {
            
        }
    }
}