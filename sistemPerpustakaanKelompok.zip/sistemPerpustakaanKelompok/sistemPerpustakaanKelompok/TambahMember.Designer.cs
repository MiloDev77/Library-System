﻿namespace SistemPerpustakaanKelompok
{
    partial class TambahMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TambahMember));
            label1 = new Label();
            txtIdCard = new TextBox();
            txtUsername = new TextBox();
            txtPassword = new TextBox();
            txtAlamat = new TextBox();
            txtNoHp = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            btnSimpan = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(45, 9);
            label1.Name = "label1";
            label1.Size = new Size(165, 28);
            label1.TabIndex = 0;
            label1.Text = "Adding Member";
            // 
            // txtIdCard
            // 
            txtIdCard.Location = new Point(12, 68);
            txtIdCard.Name = "txtIdCard";
            txtIdCard.PlaceholderText = "Id Card";
            txtIdCard.Size = new Size(226, 23);
            txtIdCard.TabIndex = 1;
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(12, 118);
            txtUsername.Name = "txtUsername";
            txtUsername.PlaceholderText = "Username";
            txtUsername.Size = new Size(226, 23);
            txtUsername.TabIndex = 1;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(12, 162);
            txtPassword.Name = "txtPassword";
            txtPassword.PlaceholderText = "Password";
            txtPassword.Size = new Size(226, 23);
            txtPassword.TabIndex = 1;
            // 
            // txtAlamat
            // 
            txtAlamat.Location = new Point(12, 206);
            txtAlamat.Name = "txtAlamat";
            txtAlamat.PlaceholderText = "Address";
            txtAlamat.Size = new Size(226, 23);
            txtAlamat.TabIndex = 1;
            // 
            // txtNoHp
            // 
            txtNoHp.Location = new Point(12, 250);
            txtNoHp.Name = "txtNoHp";
            txtNoHp.PlaceholderText = "62+";
            txtNoHp.Size = new Size(226, 23);
            txtNoHp.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ControlLightLight;
            label2.Location = new Point(12, 232);
            label2.Name = "label2";
            label2.Size = new Size(42, 15);
            label2.TabIndex = 2;
            label2.Text = "No Hp";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ControlLightLight;
            label3.Location = new Point(12, 188);
            label3.Name = "label3";
            label3.Size = new Size(49, 15);
            label3.TabIndex = 2;
            label3.Text = "Address";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ControlLightLight;
            label4.Location = new Point(12, 144);
            label4.Name = "label4";
            label4.Size = new Size(57, 15);
            label4.TabIndex = 2;
            label4.Text = "Password";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ControlLightLight;
            label5.Location = new Point(12, 100);
            label5.Name = "label5";
            label5.Size = new Size(60, 15);
            label5.TabIndex = 2;
            label5.Text = "Username";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ControlLightLight;
            label6.Location = new Point(12, 50);
            label6.Name = "label6";
            label6.Size = new Size(45, 15);
            label6.TabIndex = 2;
            label6.Text = "Id Card";
            // 
            // btnSimpan
            // 
            btnSimpan.BackColor = Color.Lime;
            btnSimpan.Cursor = Cursors.Hand;
            btnSimpan.FlatStyle = FlatStyle.Popup;
            btnSimpan.Location = new Point(12, 289);
            btnSimpan.Name = "btnSimpan";
            btnSimpan.Size = new Size(226, 41);
            btnSimpan.TabIndex = 3;
            btnSimpan.Text = "Add Member";
            btnSimpan.UseVisualStyleBackColor = false;
            btnSimpan.Click += btnSimpan_Click;
            // 
            // TambahMember
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(250, 348);
            Controls.Add(btnSimpan);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtNoHp);
            Controls.Add(txtAlamat);
            Controls.Add(txtPassword);
            Controls.Add(txtUsername);
            Controls.Add(txtIdCard);
            Controls.Add(label1);
            Name = "TambahMember";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "TambahMember";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtIdCard;
        private TextBox txtUsername;
        private TextBox txtPassword;
        private TextBox txtAlamat;
        private TextBox txtNoHp;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Button btnSimpan;
    }
}