﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemPerpustakaanKelompok
{
    public partial class TambahMember : Form
    {
        public TambahMember()
        {
            InitializeComponent();
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = @"INSERT INTO tblmember 
                        (id_card, username, password, alamat, no_hp, is_active)
                        VALUES (@id, @user, @pass, @alamat, @hp, 1)";

                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@id", txtIdCard.Text);
                cmd.Parameters.AddWithValue("@user", txtUsername.Text);
                cmd.Parameters.AddWithValue("@pass", txtPassword.Text);
                cmd.Parameters.AddWithValue("@alamat", txtAlamat.Text);
                cmd.Parameters.AddWithValue("@hp", txtNoHp.Text);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("New Data Successfully Added!");
            this.Close();
        }
    }  
}