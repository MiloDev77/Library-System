﻿namespace SistemPerpustakaanKelompok
{
    partial class borrowRequestData
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(borrowRequestData));
            lblIdBuku = new Label();
            lblNamaBuku = new Label();
            gambarBuku = new PictureBox();
            lblNamaPeminjam = new Label();
            lblTanggalPinjam = new Label();
            lblTanggalKembali = new Label();
            btnReject = new Button();
            btnApprove = new Button();
            ((System.ComponentModel.ISupportInitialize)gambarBuku).BeginInit();
            SuspendLayout();
            // 
            // lblIdBuku
            // 
            lblIdBuku.AutoSize = true;
            lblIdBuku.Font = new Font("Segoe UI Semibold", 5F, FontStyle.Bold);
            lblIdBuku.ForeColor = SystemColors.ControlLightLight;
            lblIdBuku.Location = new Point(86, 30);
            lblIdBuku.Name = "lblIdBuku";
            lblIdBuku.Size = new Size(18, 10);
            lblIdBuku.TabIndex = 12;
            lblIdBuku.Text = "N/A";
            // 
            // lblNamaBuku
            // 
            lblNamaBuku.AutoSize = true;
            lblNamaBuku.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblNamaBuku.ForeColor = SystemColors.ControlLightLight;
            lblNamaBuku.Location = new Point(83, 6);
            lblNamaBuku.Name = "lblNamaBuku";
            lblNamaBuku.Size = new Size(29, 15);
            lblNamaBuku.TabIndex = 11;
            lblNamaBuku.Text = "N/A";
            // 
            // gambarBuku
            // 
            gambarBuku.BackgroundImageLayout = ImageLayout.Stretch;
            gambarBuku.Location = new Point(39, 2);
            gambarBuku.Margin = new Padding(3, 2, 3, 2);
            gambarBuku.Name = "gambarBuku";
            gambarBuku.Size = new Size(32, 40);
            gambarBuku.TabIndex = 10;
            gambarBuku.TabStop = false;
            // 
            // lblNamaPeminjam
            // 
            lblNamaPeminjam.AutoSize = true;
            lblNamaPeminjam.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblNamaPeminjam.ForeColor = SystemColors.ControlLightLight;
            lblNamaPeminjam.Location = new Point(224, 19);
            lblNamaPeminjam.Name = "lblNamaPeminjam";
            lblNamaPeminjam.Size = new Size(29, 15);
            lblNamaPeminjam.TabIndex = 13;
            lblNamaPeminjam.Text = "N/A";
            // 
            // lblTanggalPinjam
            // 
            lblTanggalPinjam.AutoSize = true;
            lblTanggalPinjam.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblTanggalPinjam.ForeColor = SystemColors.ControlLightLight;
            lblTanggalPinjam.Location = new Point(436, 19);
            lblTanggalPinjam.Name = "lblTanggalPinjam";
            lblTanggalPinjam.Size = new Size(29, 15);
            lblTanggalPinjam.TabIndex = 14;
            lblTanggalPinjam.Text = "N/A";
            // 
            // lblTanggalKembali
            // 
            lblTanggalKembali.AutoSize = true;
            lblTanggalKembali.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblTanggalKembali.ForeColor = SystemColors.ControlLightLight;
            lblTanggalKembali.Location = new Point(660, 19);
            lblTanggalKembali.Name = "lblTanggalKembali";
            lblTanggalKembali.Size = new Size(29, 15);
            lblTanggalKembali.TabIndex = 15;
            lblTanggalKembali.Text = "N/A";
            // 
            // btnReject
            // 
            btnReject.BackColor = Color.Red;
            btnReject.Cursor = Cursors.Hand;
            btnReject.FlatStyle = FlatStyle.Popup;
            btnReject.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            btnReject.ForeColor = SystemColors.ControlText;
            btnReject.Location = new Point(873, 22);
            btnReject.Name = "btnReject";
            btnReject.Size = new Size(62, 23);
            btnReject.TabIndex = 17;
            btnReject.Text = "Reject";
            btnReject.UseVisualStyleBackColor = false;
            // 
            // btnApprove
            // 
            btnApprove.BackColor = Color.Lime;
            btnApprove.Cursor = Cursors.Hand;
            btnApprove.FlatStyle = FlatStyle.Popup;
            btnApprove.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            btnApprove.ForeColor = SystemColors.ControlText;
            btnApprove.Location = new Point(873, -3);
            btnApprove.Name = "btnApprove";
            btnApprove.Size = new Size(62, 23);
            btnApprove.TabIndex = 18;
            btnApprove.Text = "Approve";
            btnApprove.UseVisualStyleBackColor = false;
            btnApprove.Click += btnApprove_Click;
            // 
            // borrowRequestData
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Transparent;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            Controls.Add(btnReject);
            Controls.Add(btnApprove);
            Controls.Add(lblTanggalKembali);
            Controls.Add(lblTanggalPinjam);
            Controls.Add(lblNamaPeminjam);
            Controls.Add(lblIdBuku);
            Controls.Add(lblNamaBuku);
            Controls.Add(gambarBuku);
            DoubleBuffered = true;
            Name = "borrowRequestData";
            Size = new Size(945, 43);
            ((System.ComponentModel.ISupportInitialize)gambarBuku).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblIdBuku;
        private Label lblNamaBuku;
        private PictureBox gambarBuku;
        private Label lblNamaPeminjam;
        private Label lblTanggalPinjam;
        private Label lblTanggalKembali;
        private Button btnReject;
        private Button btnApprove;
    }
}
