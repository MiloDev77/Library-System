﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class borrowRequestData : UserControl
    {
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Image GambarBuku
        {
            set
            {
                gambarBuku.Image = value;
                gambarBuku.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string idBuku
        {
            get { return lblIdBuku.Text; }
            set { lblIdBuku.Text = value; }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string NamaBuku
        {
            get { return lblNamaBuku.Text; }
            set { lblNamaBuku.Text = value; }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string NamaPeminjam
        {
            get { return lblNamaPeminjam.Text; }
            set { lblNamaPeminjam.Text = value; }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TanggalPinjam
        {
            get { return lblTanggalPinjam.Text; }
            set { lblTanggalPinjam.Text = value; }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TanggalKembali
        {
            get { return lblTanggalKembali.Text; }
            set { lblTanggalKembali.Text = value; }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Button BtnApprove
        {
            get { return btnApprove; }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Button BtnReject
        {
            get { return btnReject; }
        }
        public borrowRequestData()
        {
            InitializeComponent();
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {

        }
    }
}
