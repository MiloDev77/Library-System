﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemPerpustakaanKelompok
{
    public partial class borrowRequestTitle : UserControl
    {
        public borrowRequestTitle()
        {
            InitializeComponent();
        }
    }
}
