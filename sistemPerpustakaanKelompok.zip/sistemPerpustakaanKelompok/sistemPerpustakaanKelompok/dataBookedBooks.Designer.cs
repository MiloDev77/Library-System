﻿namespace SistemPerpustakaanKelompok
{
    partial class dataBookedBooks
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dataBookedBooks));
            gambarBuku = new PictureBox();
            lblNamaBuku = new Label();
            lblIdBuku = new Label();
            lblNamaPeminjam = new Label();
            lblTanggalPinjam = new Label();
            lblTanggalKembali = new Label();
            lblDenda = new Label();
            btnStatus = new Button();
            ((System.ComponentModel.ISupportInitialize)gambarBuku).BeginInit();
            SuspendLayout();
            // 
            // gambarBuku
            // 
            gambarBuku.BackgroundImageLayout = ImageLayout.Stretch;
            gambarBuku.Location = new Point(39, 1);
            gambarBuku.Margin = new Padding(3, 2, 3, 2);
            gambarBuku.Name = "gambarBuku";
            gambarBuku.Size = new Size(32, 40);
            gambarBuku.TabIndex = 0;
            gambarBuku.TabStop = false;
            // 
            // lblNamaBuku
            // 
            lblNamaBuku.AutoSize = true;
            lblNamaBuku.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblNamaBuku.ForeColor = SystemColors.ControlLightLight;
            lblNamaBuku.Location = new Point(83, 5);
            lblNamaBuku.Name = "lblNamaBuku";
            lblNamaBuku.Size = new Size(29, 15);
            lblNamaBuku.TabIndex = 1;
            lblNamaBuku.Text = "N/A";
            // 
            // lblIdBuku
            // 
            lblIdBuku.AutoSize = true;
            lblIdBuku.Font = new Font("Segoe UI Semibold", 5F, FontStyle.Bold);
            lblIdBuku.ForeColor = SystemColors.ControlLightLight;
            lblIdBuku.Location = new Point(86, 29);
            lblIdBuku.Name = "lblIdBuku";
            lblIdBuku.Size = new Size(18, 10);
            lblIdBuku.TabIndex = 2;
            lblIdBuku.Text = "N/A";
            // 
            // lblNamaPeminjam
            // 
            lblNamaPeminjam.AutoSize = true;
            lblNamaPeminjam.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblNamaPeminjam.ForeColor = SystemColors.ControlLightLight;
            lblNamaPeminjam.Location = new Point(219, 16);
            lblNamaPeminjam.Name = "lblNamaPeminjam";
            lblNamaPeminjam.Size = new Size(29, 15);
            lblNamaPeminjam.TabIndex = 3;
            lblNamaPeminjam.Text = "N/A";
            // 
            // lblTanggalPinjam
            // 
            lblTanggalPinjam.AutoSize = true;
            lblTanggalPinjam.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblTanggalPinjam.ForeColor = SystemColors.ControlLightLight;
            lblTanggalPinjam.Location = new Point(367, 16);
            lblTanggalPinjam.Name = "lblTanggalPinjam";
            lblTanggalPinjam.Size = new Size(29, 15);
            lblTanggalPinjam.TabIndex = 4;
            lblTanggalPinjam.Text = "N/A";
            // 
            // lblTanggalKembali
            // 
            lblTanggalKembali.AutoSize = true;
            lblTanggalKembali.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblTanggalKembali.ForeColor = SystemColors.ControlLightLight;
            lblTanggalKembali.Location = new Point(547, 16);
            lblTanggalKembali.Name = "lblTanggalKembali";
            lblTanggalKembali.Size = new Size(29, 15);
            lblTanggalKembali.TabIndex = 5;
            lblTanggalKembali.Text = "N/A";
            // 
            // lblDenda
            // 
            lblDenda.AutoSize = true;
            lblDenda.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblDenda.ForeColor = SystemColors.ControlLightLight;
            lblDenda.Location = new Point(723, 16);
            lblDenda.Name = "lblDenda";
            lblDenda.Size = new Size(29, 15);
            lblDenda.TabIndex = 5;
            lblDenda.Text = "N/A";
            // 
            // btnStatus
            // 
            btnStatus.BackColor = Color.Transparent;
            btnStatus.Cursor = Cursors.Hand;
            btnStatus.FlatStyle = FlatStyle.Popup;
            btnStatus.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnStatus.ForeColor = SystemColors.ControlLightLight;
            btnStatus.Location = new Point(857, 9);
            btnStatus.Name = "btnStatus";
            btnStatus.Size = new Size(75, 28);
            btnStatus.TabIndex = 6;
            btnStatus.Text = "Status";
            btnStatus.UseVisualStyleBackColor = false;
            // 
            // dataBookedBooks
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Transparent;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            Controls.Add(btnStatus);
            Controls.Add(lblDenda);
            Controls.Add(lblTanggalKembali);
            Controls.Add(lblTanggalPinjam);
            Controls.Add(lblNamaPeminjam);
            Controls.Add(lblIdBuku);
            Controls.Add(lblNamaBuku);
            Controls.Add(gambarBuku);
            DoubleBuffered = true;
            Name = "dataBookedBooks";
            Size = new Size(945, 43);
            ((System.ComponentModel.ISupportInitialize)gambarBuku).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox gambarBuku;
        private Label lblNamaBuku;
        private Label lblIdBuku;
        private Label lblNamaPeminjam;
        private Label lblTanggalPinjam;
        private Label lblTanggalKembali;
        private Label lblDenda;
        private Button btnStatus;
    }
}
