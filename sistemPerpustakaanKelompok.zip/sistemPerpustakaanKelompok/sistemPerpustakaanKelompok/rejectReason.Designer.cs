﻿namespace SistemPerpustakaanKelompok
{
    partial class rejectReason
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(rejectReason));
            label1 = new Label();
            txtAlasan = new TextBox();
            btnSend = new Button();
            btnClose = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Semibold", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(12, 25);
            label1.Name = "label1";
            label1.Size = new Size(112, 37);
            label1.TabIndex = 0;
            label1.Text = "Reason:";
            // 
            // txtAlasan
            // 
            txtAlasan.BorderStyle = BorderStyle.None;
            txtAlasan.Location = new Point(130, 39);
            txtAlasan.Name = "txtAlasan";
            txtAlasan.PlaceholderText = "Example: xxxx";
            txtAlasan.Size = new Size(483, 16);
            txtAlasan.TabIndex = 1;
            // 
            // btnSend
            // 
            btnSend.BackColor = Color.Lime;
            btnSend.Cursor = Cursors.Hand;
            btnSend.FlatStyle = FlatStyle.Popup;
            btnSend.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            btnSend.Location = new Point(544, 61);
            btnSend.Name = "btnSend";
            btnSend.Size = new Size(69, 29);
            btnSend.TabIndex = 2;
            btnSend.Text = "Send";
            btnSend.UseVisualStyleBackColor = false;
            btnSend.Click += btnSend_Click;
            // 
            // btnClose
            // 
            btnClose.BackColor = Color.Red;
            btnClose.Cursor = Cursors.Hand;
            btnClose.FlatStyle = FlatStyle.Popup;
            btnClose.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            btnClose.Location = new Point(469, 61);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(69, 29);
            btnClose.TabIndex = 2;
            btnClose.Text = "Close";
            btnClose.UseVisualStyleBackColor = false;
            btnClose.Click += btnClose_Click;
            // 
            // rejectReason
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(628, 113);
            Controls.Add(btnClose);
            Controls.Add(btnSend);
            Controls.Add(txtAlasan);
            Controls.Add(label1);
            DoubleBuffered = true;
            Name = "rejectReason";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "rejectReason";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtAlasan;
        private Button btnSend;
        private Button btnClose;
    }
}