﻿namespace SistemPerpustakaanKelompok
{
    partial class returnRequestData
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(returnRequestData));
            lblDenda = new Label();
            lblTanggalKembali = new Label();
            lblTanggalPinjam = new Label();
            lblNamaPeminjam = new Label();
            lblIdBuku = new Label();
            lblNamaBuku = new Label();
            gambarBuku = new PictureBox();
            btnApprove = new Button();
            ((System.ComponentModel.ISupportInitialize)gambarBuku).BeginInit();
            SuspendLayout();
            // 
            // lblDenda
            // 
            lblDenda.AutoSize = true;
            lblDenda.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblDenda.ForeColor = SystemColors.ControlLightLight;
            lblDenda.Location = new Point(710, 16);
            lblDenda.Name = "lblDenda";
            lblDenda.Size = new Size(29, 15);
            lblDenda.TabIndex = 12;
            lblDenda.Text = "N/A";
            // 
            // lblTanggalKembali
            // 
            lblTanggalKembali.AutoSize = true;
            lblTanggalKembali.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblTanggalKembali.ForeColor = SystemColors.ControlLightLight;
            lblTanggalKembali.Location = new Point(534, 16);
            lblTanggalKembali.Name = "lblTanggalKembali";
            lblTanggalKembali.Size = new Size(29, 15);
            lblTanggalKembali.TabIndex = 13;
            lblTanggalKembali.Text = "N/A";
            // 
            // lblTanggalPinjam
            // 
            lblTanggalPinjam.AutoSize = true;
            lblTanggalPinjam.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblTanggalPinjam.ForeColor = SystemColors.ControlLightLight;
            lblTanggalPinjam.Location = new Point(354, 16);
            lblTanggalPinjam.Name = "lblTanggalPinjam";
            lblTanggalPinjam.Size = new Size(29, 15);
            lblTanggalPinjam.TabIndex = 11;
            lblTanggalPinjam.Text = "N/A";
            // 
            // lblNamaPeminjam
            // 
            lblNamaPeminjam.AutoSize = true;
            lblNamaPeminjam.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblNamaPeminjam.ForeColor = SystemColors.ControlLightLight;
            lblNamaPeminjam.Location = new Point(206, 16);
            lblNamaPeminjam.Name = "lblNamaPeminjam";
            lblNamaPeminjam.Size = new Size(29, 15);
            lblNamaPeminjam.TabIndex = 10;
            lblNamaPeminjam.Text = "N/A";
            // 
            // lblIdBuku
            // 
            lblIdBuku.AutoSize = true;
            lblIdBuku.Font = new Font("Segoe UI Semibold", 5F, FontStyle.Bold);
            lblIdBuku.ForeColor = SystemColors.ControlLightLight;
            lblIdBuku.Location = new Point(73, 29);
            lblIdBuku.Name = "lblIdBuku";
            lblIdBuku.Size = new Size(18, 10);
            lblIdBuku.TabIndex = 9;
            lblIdBuku.Text = "N/A";
            // 
            // lblNamaBuku
            // 
            lblNamaBuku.AutoSize = true;
            lblNamaBuku.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblNamaBuku.ForeColor = SystemColors.ControlLightLight;
            lblNamaBuku.Location = new Point(70, 5);
            lblNamaBuku.Name = "lblNamaBuku";
            lblNamaBuku.Size = new Size(29, 15);
            lblNamaBuku.TabIndex = 8;
            lblNamaBuku.Text = "N/A";
            // 
            // gambarBuku
            // 
            gambarBuku.BackgroundImageLayout = ImageLayout.Stretch;
            gambarBuku.Location = new Point(26, 1);
            gambarBuku.Margin = new Padding(3, 2, 3, 2);
            gambarBuku.Name = "gambarBuku";
            gambarBuku.Size = new Size(32, 40);
            gambarBuku.TabIndex = 7;
            gambarBuku.TabStop = false;
            // 
            // btnApprove
            // 
            btnApprove.BackColor = Color.Lime;
            btnApprove.Cursor = Cursors.Hand;
            btnApprove.FlatStyle = FlatStyle.Popup;
            btnApprove.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnApprove.ForeColor = SystemColors.ControlText;
            btnApprove.Location = new Point(851, 11);
            btnApprove.Name = "btnApprove";
            btnApprove.Size = new Size(75, 28);
            btnApprove.TabIndex = 17;
            btnApprove.Text = "Approve";
            btnApprove.UseVisualStyleBackColor = false;
            btnApprove.Click += btnApprove_Click;
            // 
            // returnRequestData
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Transparent;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            Controls.Add(btnApprove);
            Controls.Add(lblDenda);
            Controls.Add(lblTanggalKembali);
            Controls.Add(lblTanggalPinjam);
            Controls.Add(lblNamaPeminjam);
            Controls.Add(lblIdBuku);
            Controls.Add(lblNamaBuku);
            Controls.Add(gambarBuku);
            DoubleBuffered = true;
            Name = "returnRequestData";
            Size = new Size(945, 48);
            ((System.ComponentModel.ISupportInitialize)gambarBuku).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblDenda;
        private Label lblTanggalKembali;
        private Label lblTanggalPinjam;
        private Label lblNamaPeminjam;
        private Label lblIdBuku;
        private Label lblNamaBuku;
        private PictureBox gambarBuku;
        private Button btnApprove;
    }
}
