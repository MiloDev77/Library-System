﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class returnRequestData : UserControl
    {
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Image GambarBuku
        {
            set
            {
                gambarBuku.Image = value;
                gambarBuku.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string IdBuku
        {
            get => lblIdBuku.Text;
            set => lblIdBuku.Text = value;

        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string NamaBuku
        {
            get => lblNamaBuku.Text;
            set => lblNamaBuku.Text = value;

        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string NamaPeminjam
        {
            get => lblNamaPeminjam.Text;
            set => lblNamaPeminjam.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TanggalPinjam
        {
            get => lblTanggalPinjam.Text;
            set => lblTanggalPinjam.Text = value;

        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TanggalKembali
        {
            get => lblTanggalKembali.Text;
            set => lblTanggalKembali.Text = value;

        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Denda
        {
            get => lblDenda.Text;
            set => lblDenda.Text = value;

        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Button BtnStatus => btnApprove;
        public returnRequestData()
        {
            InitializeComponent();
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {

        }
    }
}
