﻿namespace SistemPerpustakaanKelompok
{
    partial class templateBook
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(templateBook));
            btnDetail = new Button();
            lblJenisBuku = new Label();
            lblPenulis = new Label();
            lblJudul = new Label();
            gambarBuku = new PictureBox();
            lblTahunTerbit = new Label();
            ((System.ComponentModel.ISupportInitialize)gambarBuku).BeginInit();
            SuspendLayout();
            // 
            // btnDetail
            // 
            btnDetail.BackColor = Color.Cyan;
            btnDetail.Cursor = Cursors.Hand;
            btnDetail.FlatStyle = FlatStyle.Popup;
            btnDetail.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnDetail.ForeColor = SystemColors.ControlText;
            btnDetail.Location = new Point(43, 268);
            btnDetail.Name = "btnDetail";
            btnDetail.Size = new Size(108, 31);
            btnDetail.TabIndex = 7;
            btnDetail.Text = "Detail";
            btnDetail.UseVisualStyleBackColor = false;
            btnDetail.Click += btnDetail_Click;
            // 
            // lblJenisBuku
            // 
            lblJenisBuku.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblJenisBuku.ForeColor = SystemColors.ControlLightLight;
            lblJenisBuku.Location = new Point(26, 221);
            lblJenisBuku.Name = "lblJenisBuku";
            lblJenisBuku.Size = new Size(125, 21);
            lblJenisBuku.TabIndex = 4;
            lblJenisBuku.Text = "N/A";
            // 
            // lblPenulis
            // 
            lblPenulis.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblPenulis.ForeColor = SystemColors.ControlLightLight;
            lblPenulis.Location = new Point(26, 201);
            lblPenulis.Name = "lblPenulis";
            lblPenulis.Size = new Size(125, 20);
            lblPenulis.TabIndex = 5;
            lblPenulis.Text = "N/A";
            // 
            // lblJudul
            // 
            lblJudul.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblJudul.ForeColor = SystemColors.ControlLightLight;
            lblJudul.Location = new Point(22, 177);
            lblJudul.Name = "lblJudul";
            lblJudul.Size = new Size(129, 21);
            lblJudul.TabIndex = 6;
            lblJudul.Text = "N/A";
            // 
            // gambarBuku
            // 
            gambarBuku.BackColor = Color.Transparent;
            gambarBuku.Location = new Point(43, 11);
            gambarBuku.Name = "gambarBuku";
            gambarBuku.Size = new Size(108, 163);
            gambarBuku.TabIndex = 3;
            gambarBuku.TabStop = false;
            // 
            // lblTahunTerbit
            // 
            lblTahunTerbit.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblTahunTerbit.ForeColor = SystemColors.ControlLightLight;
            lblTahunTerbit.Location = new Point(26, 242);
            lblTahunTerbit.Name = "lblTahunTerbit";
            lblTahunTerbit.Size = new Size(125, 23);
            lblTahunTerbit.TabIndex = 4;
            lblTahunTerbit.Text = "N/A";
            // 
            // templateBook
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Transparent;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            Controls.Add(btnDetail);
            Controls.Add(lblTahunTerbit);
            Controls.Add(lblJenisBuku);
            Controls.Add(lblPenulis);
            Controls.Add(lblJudul);
            Controls.Add(gambarBuku);
            DoubleBuffered = true;
            Name = "templateBook";
            Size = new Size(195, 310);
            Load += testingPinjamTemplate_Load;
            ((System.ComponentModel.ISupportInitialize)gambarBuku).EndInit();
            ResumeLayout(false);
        }

        #endregion

        public Button btnDetail;
        public Label lblTahunTerbit;
        public Label lblPenulis;
        public Label lblJudul;
        public PictureBox gambarBuku;
        public Label lblJenisBuku;
    }
}
