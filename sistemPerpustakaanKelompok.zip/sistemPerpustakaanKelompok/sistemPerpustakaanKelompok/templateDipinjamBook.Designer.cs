﻿namespace SistemPerpustakaanKelompok
{
    partial class templateDipinjamBook
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(templateDipinjamBook));
            btnKembali = new Button();
            lblTahunTerbit = new Label();
            lblPenulis = new Label();
            lblJudul = new Label();
            gambarBuku = new PictureBox();
            lblTanggalPinjam = new Label();
            lblTanggalKembali = new Label();
            ((System.ComponentModel.ISupportInitialize)gambarBuku).BeginInit();
            SuspendLayout();
            // 
            // btnKembali
            // 
            btnKembali.BackColor = Color.FromArgb(255, 128, 0);
            btnKembali.Cursor = Cursors.Hand;
            btnKembali.FlatStyle = FlatStyle.Popup;
            btnKembali.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnKembali.ForeColor = SystemColors.ControlText;
            btnKembali.Location = new Point(47, 277);
            btnKembali.Name = "btnKembali";
            btnKembali.Size = new Size(108, 31);
            btnKembali.TabIndex = 12;
            btnKembali.Text = "Return";
            btnKembali.UseVisualStyleBackColor = false;
            btnKembali.Click += btnKembali_Click;
            // 
            // lblTahunTerbit
            // 
            lblTahunTerbit.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblTahunTerbit.ForeColor = SystemColors.ControlLightLight;
            lblTahunTerbit.Location = new Point(30, 221);
            lblTahunTerbit.Name = "lblTahunTerbit";
            lblTahunTerbit.Size = new Size(125, 11);
            lblTahunTerbit.TabIndex = 9;
            lblTahunTerbit.Text = "N/A";
            // 
            // lblPenulis
            // 
            lblPenulis.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblPenulis.ForeColor = SystemColors.ControlLightLight;
            lblPenulis.Location = new Point(30, 203);
            lblPenulis.Name = "lblPenulis";
            lblPenulis.Size = new Size(125, 11);
            lblPenulis.TabIndex = 10;
            lblPenulis.Text = "N/A";
            // 
            // lblJudul
            // 
            lblJudul.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblJudul.ForeColor = SystemColors.ControlLightLight;
            lblJudul.Location = new Point(26, 179);
            lblJudul.Name = "lblJudul";
            lblJudul.Size = new Size(129, 21);
            lblJudul.TabIndex = 11;
            lblJudul.Text = "N/A";
            // 
            // gambarBuku
            // 
            gambarBuku.BackColor = Color.Transparent;
            gambarBuku.Location = new Point(47, 13);
            gambarBuku.Name = "gambarBuku";
            gambarBuku.Size = new Size(108, 163);
            gambarBuku.TabIndex = 8;
            gambarBuku.TabStop = false;
            // 
            // lblTanggalPinjam
            // 
            lblTanggalPinjam.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblTanggalPinjam.ForeColor = SystemColors.ControlLightLight;
            lblTanggalPinjam.Location = new Point(30, 239);
            lblTanggalPinjam.Name = "lblTanggalPinjam";
            lblTanggalPinjam.Size = new Size(125, 11);
            lblTanggalPinjam.TabIndex = 9;
            lblTanggalPinjam.Text = "N/A";
            // 
            // lblTanggalKembali
            // 
            lblTanggalKembali.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblTanggalKembali.ForeColor = SystemColors.ControlLightLight;
            lblTanggalKembali.Location = new Point(30, 257);
            lblTanggalKembali.Name = "lblTanggalKembali";
            lblTanggalKembali.Size = new Size(125, 11);
            lblTanggalKembali.TabIndex = 9;
            lblTanggalKembali.Text = "N/A";
            // 
            // templateDipinjamBook
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Transparent;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            Controls.Add(btnKembali);
            Controls.Add(lblTanggalKembali);
            Controls.Add(lblTanggalPinjam);
            Controls.Add(lblTahunTerbit);
            Controls.Add(lblPenulis);
            Controls.Add(lblJudul);
            Controls.Add(gambarBuku);
            DoubleBuffered = true;
            Name = "templateDipinjamBook";
            Size = new Size(195, 321);
            Load += testingDipinjamTemplate_Load;
            ((System.ComponentModel.ISupportInitialize)gambarBuku).EndInit();
            ResumeLayout(false);
        }

        #endregion

        public Button btnKembali;
        public Label lblTahunTerbit;
        public Label lblPenulis;
        public Label lblJudul;
        public PictureBox gambarBuku;
        public Label lblTanggalPinjam;
        public Label lblTanggalKembali;
    }
}
