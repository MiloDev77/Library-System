﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class templateDipinjamBook : UserControl
    {
        private int idPeminjaman;
        private int idBuku;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Image BookImage
        {
            set
            {
                gambarBuku.Image = value;
                gambarBuku.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int ReserveId
        {
            get { return idPeminjaman; }
            set { idPeminjaman = value; }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int BookId
        {
            get { return idBuku; }
            set { idBuku = value; }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string BookName
        {
            get => lblJudul.Text;
            set => lblJudul.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Writer
        {
            get => lblPenulis.Text;
            set => lblPenulis.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int PublishYear
        {
            get => int.Parse(lblTahunTerbit.Text);
            set => lblTahunTerbit.Text = value.ToString();
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ReserveDate
        {
            get => lblTanggalPinjam.Text;
            set => lblTanggalPinjam.Text = "Reserve: " + value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ReturnDate
        {
            get => lblTanggalKembali.Text;
            set => lblTanggalKembali.Text = "Return: " + value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Button BtnReturn
        {
            get { return btnKembali; }
        }

        public templateDipinjamBook()
        {
            InitializeComponent();
        }

        private void btnKembali_Click(object sender, EventArgs e)
        {
            btnKembali.Enabled = false;

            gambarBuku.SizeMode = PictureBoxSizeMode.StretchImage;

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string cek = "SELECT COUNT(*) FROM tblrequest_kembali WHERE id_peminjaman=@id AND status_request='Pending'";
                SqlCommand cmdCek = new SqlCommand(cek, conn);
                cmdCek.Parameters.AddWithValue("@id", idPeminjaman);

                int exist = (int)cmdCek.ExecuteScalar();
                if (exist > 0)
                {
                    MessageBox.Show("Request Has Been Sent!");
                    return;
                }

                string query = @"INSERT INTO tblrequest_kembali
                        (id_peminjaman, tanggal_requestkembali, status_request)
                        VALUES (@id, GETDATE(), 'Pending')";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", idPeminjaman);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Request Has Been Sent!");

            this.Parent.Controls.Remove(this);
            this.Dispose();
        }

        private void testingDipinjamTemplate_Load(object sender, EventArgs e)
        {
            
        }
    }
}
