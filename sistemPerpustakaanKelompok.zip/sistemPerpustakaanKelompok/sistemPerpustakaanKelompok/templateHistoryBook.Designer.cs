﻿namespace SistemPerpustakaanKelompok
{
    partial class templateHistoryBook
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(templateHistoryBook));
            lblTanggalKembali = new Label();
            lblTanggalPinjam = new Label();
            lblTahunTerbit = new Label();
            lblPenulis = new Label();
            lblJudul = new Label();
            gambarBuku = new PictureBox();
            btnDetail = new Button();
            ((System.ComponentModel.ISupportInitialize)gambarBuku).BeginInit();
            SuspendLayout();
            // 
            // lblTanggalKembali
            // 
            lblTanggalKembali.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblTanggalKembali.ForeColor = SystemColors.ControlLightLight;
            lblTanggalKembali.Location = new Point(30, 257);
            lblTanggalKembali.Name = "lblTanggalKembali";
            lblTanggalKembali.Size = new Size(125, 11);
            lblTanggalKembali.TabIndex = 13;
            lblTanggalKembali.Text = "N/A";
            // 
            // lblTanggalPinjam
            // 
            lblTanggalPinjam.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblTanggalPinjam.ForeColor = SystemColors.ControlLightLight;
            lblTanggalPinjam.Location = new Point(30, 239);
            lblTanggalPinjam.Name = "lblTanggalPinjam";
            lblTanggalPinjam.Size = new Size(125, 11);
            lblTanggalPinjam.TabIndex = 14;
            lblTanggalPinjam.Text = "N/A";
            // 
            // lblTahunTerbit
            // 
            lblTahunTerbit.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblTahunTerbit.ForeColor = SystemColors.ControlLightLight;
            lblTahunTerbit.Location = new Point(30, 221);
            lblTahunTerbit.Name = "lblTahunTerbit";
            lblTahunTerbit.Size = new Size(125, 11);
            lblTahunTerbit.TabIndex = 15;
            lblTahunTerbit.Text = "N/A";
            // 
            // lblPenulis
            // 
            lblPenulis.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblPenulis.ForeColor = SystemColors.ControlLightLight;
            lblPenulis.Location = new Point(30, 203);
            lblPenulis.Name = "lblPenulis";
            lblPenulis.Size = new Size(125, 11);
            lblPenulis.TabIndex = 16;
            lblPenulis.Text = "N/A";
            // 
            // lblJudul
            // 
            lblJudul.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblJudul.ForeColor = SystemColors.ControlLightLight;
            lblJudul.Location = new Point(26, 179);
            lblJudul.Name = "lblJudul";
            lblJudul.Size = new Size(129, 21);
            lblJudul.TabIndex = 17;
            lblJudul.Text = "N/A";
            // 
            // gambarBuku
            // 
            gambarBuku.BackColor = Color.Transparent;
            gambarBuku.Location = new Point(47, 13);
            gambarBuku.Name = "gambarBuku";
            gambarBuku.Size = new Size(108, 163);
            gambarBuku.TabIndex = 12;
            gambarBuku.TabStop = false;
            // 
            // btnDetail
            // 
            btnDetail.BackColor = Color.Cyan;
            btnDetail.Cursor = Cursors.Hand;
            btnDetail.FlatStyle = FlatStyle.Popup;
            btnDetail.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDetail.ForeColor = SystemColors.ControlText;
            btnDetail.Location = new Point(47, 277);
            btnDetail.Name = "btnDetail";
            btnDetail.Size = new Size(108, 31);
            btnDetail.TabIndex = 18;
            btnDetail.Text = "Detail";
            btnDetail.UseVisualStyleBackColor = false;
            // 
            // templateHistoryBook
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Transparent;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            Controls.Add(btnDetail);
            Controls.Add(lblTanggalKembali);
            Controls.Add(lblTanggalPinjam);
            Controls.Add(lblTahunTerbit);
            Controls.Add(lblPenulis);
            Controls.Add(lblJudul);
            Controls.Add(gambarBuku);
            DoubleBuffered = true;
            Name = "templateHistoryBook";
            Size = new Size(195, 321);
            ((System.ComponentModel.ISupportInitialize)gambarBuku).EndInit();
            ResumeLayout(false);
        }

        #endregion

        public Label lblTanggalKembali;
        public Label lblTanggalPinjam;
        public Label lblTahunTerbit;
        public Label lblPenulis;
        public Label lblJudul;
        public PictureBox gambarBuku;
        public Button btnDetail;
    }
}
