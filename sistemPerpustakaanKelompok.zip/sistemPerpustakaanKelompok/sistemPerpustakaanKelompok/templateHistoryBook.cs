﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class templateHistoryBook : UserControl
    {
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Image BookImage
        {
            get => gambarBuku.Image;
            set
            {
                gambarBuku.Image = value;
                gambarBuku.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string BookName
        {
            get => lblJudul.Text;
            set => lblJudul.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Writer
        {
            get => lblPenulis.Text;
            set => lblPenulis.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int PublishYear
        {
            get => int.Parse(lblTahunTerbit.Text);
            set => lblTahunTerbit.Text = value.ToString();
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ReserveDate
        {
            get => lblTanggalPinjam.Text;
            set => lblTanggalPinjam.Text = "Reserve: " + value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ReturnDate
        {
            get => lblTanggalKembali.Text;
            set => lblTanggalKembali.Text = "Return: " + value;
        }

        public Button BtnDetail
        {
            get { return btnDetail; }
        }
        public templateHistoryBook()
        {
            InitializeComponent();
        }
    }
}
