﻿namespace SistemPerpustakaanKelompok
{
    partial class templateInbox
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(templateInbox));
            lblReserveNumber = new Label();
            lblAlasan = new Label();
            SuspendLayout();
            // 
            // lblReserveNumber
            // 
            lblReserveNumber.AutoSize = true;
            lblReserveNumber.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblReserveNumber.ForeColor = SystemColors.ControlLightLight;
            lblReserveNumber.Location = new Point(3, 13);
            lblReserveNumber.Name = "lblReserveNumber";
            lblReserveNumber.Size = new Size(313, 21);
            lblReserveNumber.TabIndex = 0;
            lblReserveNumber.Text = "Reserve Number N/A Has Been Rejected!";
            // 
            // lblAlasan
            // 
            lblAlasan.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAlasan.ForeColor = SystemColors.ControlLightLight;
            lblAlasan.Location = new Point(3, 43);
            lblAlasan.Name = "lblAlasan";
            lblAlasan.Size = new Size(939, 54);
            lblAlasan.TabIndex = 0;
            lblAlasan.Text = "N/A";
            // 
            // templateInbox
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Transparent;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            Controls.Add(lblAlasan);
            Controls.Add(lblReserveNumber);
            Name = "templateInbox";
            Size = new Size(945, 97);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblReserveNumber;
        private Label lblAlasan;
    }
}
