﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class templateInbox : UserControl
    {
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string RejectionReason
        {
            get => lblAlasan.Text;
            set => lblAlasan.Text = value;

        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ReserveNumber
        {
            get => lblReserveNumber.Text;
            set => lblReserveNumber.Text = value;

        }

        public templateInbox()
        {
            InitializeComponent();
        }
    }
}
