﻿namespace SistemPerpustakaanKelompok
{
    partial class templateManageBook
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(templateManageBook));
            gambarBuku = new PictureBox();
            lblTitle = new Label();
            lblPenulis = new Label();
            lblPenerbit = new Label();
            lblTahunTerbit = new Label();
            lblStock = new Label();
            btnEdit = new Button();
            lblJenisBuku = new Label();
            btnHapus = new Button();
            layoutPanelDeskripsi = new FlowLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)gambarBuku).BeginInit();
            SuspendLayout();
            // 
            // gambarBuku
            // 
            gambarBuku.BackColor = Color.Transparent;
            gambarBuku.Location = new Point(44, 13);
            gambarBuku.Name = "gambarBuku";
            gambarBuku.Size = new Size(108, 163);
            gambarBuku.TabIndex = 0;
            gambarBuku.TabStop = false;
            // 
            // lblTitle
            // 
            lblTitle.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitle.ForeColor = SystemColors.ControlLightLight;
            lblTitle.Location = new Point(18, 179);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(147, 21);
            lblTitle.TabIndex = 1;
            lblTitle.Text = "N/A";
            lblTitle.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblPenulis
            // 
            lblPenulis.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblPenulis.ForeColor = SystemColors.ControlLightLight;
            lblPenulis.Location = new Point(20, 214);
            lblPenulis.Name = "lblPenulis";
            lblPenulis.Size = new Size(139, 13);
            lblPenulis.TabIndex = 1;
            lblPenulis.Text = "N/A";
            lblPenulis.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblPenerbit
            // 
            lblPenerbit.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblPenerbit.ForeColor = SystemColors.ControlLightLight;
            lblPenerbit.Location = new Point(20, 229);
            lblPenerbit.Name = "lblPenerbit";
            lblPenerbit.Size = new Size(139, 13);
            lblPenerbit.TabIndex = 1;
            lblPenerbit.Text = "N/A";
            lblPenerbit.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblTahunTerbit
            // 
            lblTahunTerbit.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblTahunTerbit.ForeColor = SystemColors.ControlLightLight;
            lblTahunTerbit.Location = new Point(20, 244);
            lblTahunTerbit.Name = "lblTahunTerbit";
            lblTahunTerbit.Size = new Size(139, 13);
            lblTahunTerbit.TabIndex = 1;
            lblTahunTerbit.Text = "N/A";
            lblTahunTerbit.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblStock
            // 
            lblStock.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            lblStock.ForeColor = SystemColors.ControlLightLight;
            lblStock.Location = new Point(18, 257);
            lblStock.Name = "lblStock";
            lblStock.Size = new Size(144, 19);
            lblStock.TabIndex = 1;
            lblStock.Text = "N/A";
            lblStock.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // btnEdit
            // 
            btnEdit.BackColor = Color.FromArgb(255, 128, 0);
            btnEdit.Cursor = Cursors.Hand;
            btnEdit.FlatStyle = FlatStyle.Popup;
            btnEdit.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnEdit.ForeColor = SystemColors.ControlText;
            btnEdit.Location = new Point(20, 339);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(69, 31);
            btnEdit.TabIndex = 2;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = false;
            btnEdit.Click += btnEdit_Click;
            // 
            // lblJenisBuku
            // 
            lblJenisBuku.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            lblJenisBuku.ForeColor = SystemColors.ControlLightLight;
            lblJenisBuku.Location = new Point(20, 200);
            lblJenisBuku.Name = "lblJenisBuku";
            lblJenisBuku.Size = new Size(139, 13);
            lblJenisBuku.TabIndex = 1;
            lblJenisBuku.Text = "N/A";
            lblJenisBuku.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // btnHapus
            // 
            btnHapus.BackColor = Color.Red;
            btnHapus.Cursor = Cursors.Hand;
            btnHapus.FlatStyle = FlatStyle.Popup;
            btnHapus.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnHapus.ForeColor = SystemColors.ControlText;
            btnHapus.Location = new Point(95, 339);
            btnHapus.Name = "btnHapus";
            btnHapus.Size = new Size(69, 31);
            btnHapus.TabIndex = 2;
            btnHapus.Text = "Hapus";
            btnHapus.UseVisualStyleBackColor = false;
            btnHapus.Click += btnHapus_Click;
            // 
            // layoutPanelDeskripsi
            // 
            layoutPanelDeskripsi.ForeColor = SystemColors.ControlLightLight;
            layoutPanelDeskripsi.Location = new Point(23, 278);
            layoutPanelDeskripsi.Name = "layoutPanelDeskripsi";
            layoutPanelDeskripsi.Size = new Size(139, 55);
            layoutPanelDeskripsi.TabIndex = 3;
            // 
            // templateManageBook
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Transparent;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            Controls.Add(layoutPanelDeskripsi);
            Controls.Add(btnHapus);
            Controls.Add(btnEdit);
            Controls.Add(lblStock);
            Controls.Add(lblTahunTerbit);
            Controls.Add(lblPenerbit);
            Controls.Add(lblJenisBuku);
            Controls.Add(lblPenulis);
            Controls.Add(lblTitle);
            Controls.Add(gambarBuku);
            DoubleBuffered = true;
            Name = "templateManageBook";
            Size = new Size(195, 394);
            Load += templateManageBook_Load;
            ((System.ComponentModel.ISupportInitialize)gambarBuku).EndInit();
            ResumeLayout(false);
        }

        #endregion

        public PictureBox gambarBuku;
        public Label lblTitle;
        public Label lblPenulis;
        public Label lblPenerbit;
        public Label lblTahunTerbit;
        public Label lblStock;
        public Button btnEdit;
        public Label lblJenisBuku;
        public Button btnHapus;
        private FlowLayoutPanel layoutPanelDeskripsi;
    }
}
