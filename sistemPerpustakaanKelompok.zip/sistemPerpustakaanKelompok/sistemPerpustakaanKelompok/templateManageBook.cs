﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class templateManageBook : UserControl
    {
        public int idBuku;
        public string usernameAdmin;
        public event EventHandler HapusClicked;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Image GambarBuku
        {
            set
            {
                gambarBuku.Image = value;
                gambarBuku.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string JudulBuku
        {
            get => lblTitle.Text;
            set => lblTitle.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string JenisBuku
        {
            get => lblJenisBuku.Text;
            set => lblJenisBuku.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Penulis
        {
            get => lblPenulis.Text;
            set => lblPenulis.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Penerbit
        {
            get => lblPenerbit.Text;
            set => lblPenerbit.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string TahunTerbit
        {
            get => lblTahunTerbit.Text;
            set => lblTahunTerbit.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Stok
        {
            get => lblStock.Text;
            set => lblStock.Text = value;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Deskripsi
        {
            get => layoutPanelDeskripsi.Controls.Count > 0
                ? layoutPanelDeskripsi.Controls[0].Text
                : "";
            set
            {
                layoutPanelDeskripsi.Controls.Clear();

                Label lbl = new Label();
                lbl.Text = value;
                lbl.AutoSize = true;
                lbl.MaximumSize = new Size(layoutPanelDeskripsi.Width - 10, 0);

                layoutPanelDeskripsi.Controls.Add(lbl);
            }
        }
        public templateManageBook()
        {
            InitializeComponent();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            Form parent = this.FindForm();

            EditBuku edit = new EditBuku(idBuku, usernameAdmin);
            edit.ShowDialog();

            parent.Hide();
            (parent as ManageBook)?.LoadData();
        }

        private void templateManageBook_Load(object sender, EventArgs e)
        {
            layoutPanelDeskripsi.AutoScroll = true;
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            HapusClicked?.Invoke(this, EventArgs.Empty);
        }
    }
}