﻿namespace SistemPerpustakaanKelompok
{
    partial class templateManageMember
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(templateManageMember));
            lblIdMember = new Label();
            lblUsername = new Label();
            lblPassword = new Label();
            lblAlamat = new Label();
            lblNoHp = new Label();
            btnActive = new Button();
            btnInactive = new Button();
            hideOpenText = new ToolTip(components);
            SuspendLayout();
            // 
            // lblIdMember
            // 
            lblIdMember.AutoSize = true;
            lblIdMember.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblIdMember.ForeColor = SystemColors.ControlLightLight;
            lblIdMember.Location = new Point(28, 17);
            lblIdMember.Name = "lblIdMember";
            lblIdMember.Size = new Size(41, 21);
            lblIdMember.TabIndex = 0;
            lblIdMember.Text = "N/A";
            // 
            // lblUsername
            // 
            lblUsername.AutoSize = true;
            lblUsername.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblUsername.ForeColor = SystemColors.ControlLightLight;
            lblUsername.Location = new Point(187, 17);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(41, 21);
            lblUsername.TabIndex = 0;
            lblUsername.Text = "N/A";
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPassword.ForeColor = SystemColors.ControlLightLight;
            lblPassword.Location = new Point(354, 17);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(41, 21);
            lblPassword.TabIndex = 0;
            lblPassword.Text = "N/A";
            // 
            // lblAlamat
            // 
            lblAlamat.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAlamat.ForeColor = SystemColors.ControlLightLight;
            lblAlamat.Location = new Point(522, 17);
            lblAlamat.Name = "lblAlamat";
            lblAlamat.Size = new Size(41, 21);
            lblAlamat.TabIndex = 0;
            lblAlamat.Text = "N/A";
            // 
            // lblNoHp
            // 
            lblNoHp.AutoSize = true;
            lblNoHp.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNoHp.ForeColor = SystemColors.ControlLightLight;
            lblNoHp.Location = new Point(680, 17);
            lblNoHp.Name = "lblNoHp";
            lblNoHp.Size = new Size(41, 21);
            lblNoHp.TabIndex = 0;
            lblNoHp.Text = "N/A";
            // 
            // btnActive
            // 
            btnActive.BackColor = Color.Lime;
            btnActive.Cursor = Cursors.Hand;
            btnActive.FlatStyle = FlatStyle.Popup;
            btnActive.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold);
            btnActive.Location = new Point(829, 3);
            btnActive.Name = "btnActive";
            btnActive.Size = new Size(75, 23);
            btnActive.TabIndex = 1;
            btnActive.Text = "Active";
            btnActive.UseVisualStyleBackColor = false;
            btnActive.Click += btnActive_Click;
            // 
            // btnInactive
            // 
            btnInactive.BackColor = Color.Red;
            btnInactive.Cursor = Cursors.Hand;
            btnInactive.FlatStyle = FlatStyle.Popup;
            btnInactive.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold);
            btnInactive.Location = new Point(829, 33);
            btnInactive.Name = "btnInactive";
            btnInactive.Size = new Size(75, 23);
            btnInactive.TabIndex = 1;
            btnInactive.Text = "Inactive";
            btnInactive.UseVisualStyleBackColor = false;
            btnInactive.Click += btnInactive_Click;
            // 
            // templateManageMember
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Transparent;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            Controls.Add(btnInactive);
            Controls.Add(btnActive);
            Controls.Add(lblNoHp);
            Controls.Add(lblAlamat);
            Controls.Add(lblPassword);
            Controls.Add(lblUsername);
            Controls.Add(lblIdMember);
            DoubleBuffered = true;
            Name = "templateManageMember";
            Size = new Size(917, 61);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblIdMember;
        private Label lblUsername;
        private Label lblPassword;
        private Label lblAlamat;
        private Label lblNoHp;
        private Button btnActive;
        private Button btnInactive;
        private ToolTip hideOpenText;
    }
}
