﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SistemPerpustakaanKelompok
{
    public partial class templateManageMember : UserControl
    {
        private string idCardValue;
        public event EventHandler StatusChanged;
        private bool isActiveValue;
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string IdCard
        {
            get { return lblIdMember.Text; }
            set
            {
                lblIdMember.Text = value;
                idCardValue = value;
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Username
        {
            get { return lblUsername.Text; }
            set { lblUsername.Text = value; }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Password
        {
            get { return lblPassword.Text; }
            set { lblPassword.Text = value; }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Alamat
        {
            get { return lblAlamat.Text; }
            set 
            {
                lblAlamat.AutoSize = false;
                lblAlamat.Size = new Size(150, 21);
                lblAlamat.AutoEllipsis = true;

                lblAlamat.Text = value;

                hideOpenText.SetToolTip(lblAlamat, value);
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string NoHp
        {
            get { return lblNoHp.Text; }
            set { lblNoHp.Text = value; }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsActive
        {
            get { return isActiveValue; }
            set
            {
                isActiveValue = value;

                if (value)
                {
                    btnActive.BackColor = Color.Green;
                    btnInactive.BackColor = Color.Gray;
                }
                else
                {
                    btnActive.BackColor = Color.Gray;
                    btnInactive.BackColor = Color.Red;
                }
            }
        }
        public templateManageMember()
        {
            InitializeComponent();

            btnActive.BackColor = Color.DarkGray;
            btnInactive.BackColor = Color.DarkGray;

            btnActive.Click += btnActive_Click;
            btnInactive.Click += btnInactive_Click;

            hideOpenText.SetToolTip(lblAlamat, lblAlamat.Text);
        }

        private void btnActive_Click(object sender, EventArgs e)
        {
            UpdateStatus(true);
        }

        private void btnInactive_Click(object sender, EventArgs e)
        {
            UpdateStatus(false);
        }

        private void UpdateStatus(bool status)
        {
            if (string.IsNullOrEmpty(idCardValue))
            {
                MessageBox.Show("ID tidak ditemukan!");
                return;
            }

            using (SqlConnection conn = Koneksi.GetConnection())
            {
                conn.Open();

                string query = "UPDATE tblmember SET is_active = @status WHERE id_card = @id";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@status", status);
                cmd.Parameters.AddWithValue("@id", idCardValue);

                cmd.ExecuteNonQuery();
            }
            IsActive = status;

            StatusChanged?.Invoke(this, EventArgs.Empty);
        }
    }
}
